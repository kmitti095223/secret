﻿Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic

Friend Class CleanClipboard
    Inherits System.Windows.Forms.Form

    '==============================================================================
    '
    '  関数名   : CleanClipboard_Layout
    '  返却値   : 無し
    '  機能説明 :
    '
    '==============================================================================
    Private Sub CleanClipboard_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        On Error Resume Next
        Dim str_Renamed As String

        ' クリップボードのデータがテキスト以外の場合は何もしない。
        If Not (My.Computer.Clipboard.ContainsText()) Then
            Me.Close()
        End If

        'クリップボードよりテキストを取得
        str_Renamed = My.Computer.Clipboard.GetText
        Debug.Print("★クリップボードの文字列↓★")
        Debug.Print(str_Renamed)
        Debug.Print("★クリップボードの文字列↑★")

        Me.TopMost = True ' 念のため

        My.Computer.Clipboard.Clear()
        Err.Clear()
        My.Computer.Clipboard.SetText(str_Renamed)
        If Err.Number <> 0 Then
            Exit Sub
        End If
        Timer1.Enabled = True

    End Sub

    '==============================================================================
    '
    '  関数名   : Timer1_Timer
    '  返却値   : 無し
    '  機能説明 : ｢書式を削除しました。｣の画面を閉じて、終了する。
    '
    '==============================================================================
    Private Sub Timer1_Tick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Timer1.Tick
        Close()
    End Sub

End Class