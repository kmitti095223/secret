﻿Public Class Mario

    Private m_Keys As New PushedKeys
    Private m_Timer As New Timer
    Private m_Parent As Control

    Const 重力加速度 As Double = 10
    Const ジャンプ速度 As Double = -400
    Const 速度LOW As Double = 3
    Const 速度HIGH As Double = 6

    Const IMAGE_COUNT = 10
    Private m_MarioR(IMAGE_COUNT) As Bitmap
    Private m_MarioL(IMAGE_COUNT) As Bitmap
    Private m_Mario As Bitmap

    Private m_ImgIndex As Integer = 0

    Private m_CurPos As Point

    Private m_bAction As Boolean = False
    Private m_dtActionStart As DateTime = Nothing
    Private m_d速度Y As Double
    Private m_nJumpCount As Integer

    Private m_ShowFireBall As Boolean = False
    Private m_FireBall As Bitmap
    Private m_FireBallPos As Point
    Private m_FireBall向き As Boolean = True
    Private m_FireBall向き2 As Boolean = True
    Private m_bFireBallState As Integer = False
    Private m_Mariol向き As Boolean = True
    Private m_dFireBall速度Y As Double

    Public Sub Initialize(ByRef ctrl As Control, ByVal bMode As Boolean)

        m_Parent = ctrl

        Dim tmpBmp = My.Resources.Mario

        For i = 0 To IMAGE_COUNT
            'If i < 4 Then
            m_MarioR(i) = tmpBmp.Clone(New Rectangle((i Mod 4) * 32, 0, 32, 32), Imaging.PixelFormat.Format8bppIndexed)
            'Else
            '    m_MarioR(i) = tmpBmp.Clone(New Rectangle((i - 4) * 32, 32, 32, 32), Imaging.PixelFormat.Format8bppIndexed)
            'End If

            ' ルイージ用にパレットを変更する。
            If Not bMode Then
                Dim palette As Imaging.ColorPalette = m_MarioR(i).Palette
                For j As Integer = 0 To palette.Entries.Length - 1
                    Dim c As Object = palette.Entries(j)
                    If c = Color.FromArgb(255, 0, 0) Then
                        palette.Entries(j) = Color.Green
                    End If
                Next
                m_MarioR(i).Palette = palette
            End If

            'For y As Integer = 0 To m_MarioR(i).Height - 1
            '    For x As Integer = 0 To m_MarioR(i).Width - 1
            '        Debug.Print(m_MarioR(i).GetPixel(x, y).ToString)
            '        If m_MarioR(i).GetPixel(x, y) = System.Drawing.Color.FromArgb(255, 0, 0) Then

            '            m_MarioR(i).SetPixel(x, y, Color.FromArgb(255, 0, 0))
            '        End If
            '    Next
            'Next

            m_MarioR(i).MakeTransparent(Color.Black)
            m_MarioL(i) = m_MarioR(i).Clone
            m_MarioL(i).RotateFlip(RotateFlipType.RotateNoneFlipX)
        Next

        m_Mario = m_MarioR(0)

        m_CurPos = New Point(0, 0)

        m_FireBall = My.Resources.fireball
        m_FireBall.MakeTransparent(Color.Black)

        m_Timer.Interval = 50
        m_Timer.Enabled = True
        AddHandler m_Timer.Tick, New EventHandler(AddressOf m_Timer_Tick)

    End Sub

    Public Sub Paint(ByRef g As Graphics)
        g.DrawImage(m_Mario, m_CurPos)

        If m_ShowFireBall Then
            g.DrawImage(m_FireBall, m_FireBallPos)
        End If
    End Sub

    Public Sub KeyDown(ByVal KeyCode As Keys)
        Debug.Print(KeyCode)
        m_Keys.Add(KeyCode)
    End Sub

    Public Sub KeyUp(ByVal KeyCode As Keys)
        m_Keys.Remove(KeyCode)
    End Sub

    Private Sub m_Timer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs)

        MarioMove(0, m_d速度Y * 50 / 1000)
        m_d速度Y = m_d速度Y + 50 * 重力加速度 / 10
        m_dtActionStart = DateTime.Now

        MoveFireBall()

        Redraw()

        KeyAction()

    End Sub


    Private Sub KeyAction()

        If m_Keys.Check(Keys.F5) Then
            m_CurPos = New Point(0, m_Parent.ClientRectangle.Height - m_Mario.Height)
            m_bAction = False

        End If

        If m_Keys.Check(Keys.Up) Then

            Debug.Print(m_d速度Y)
            m_nJumpCount += 1
            If m_nJumpCount <= 2 Then
                m_d速度Y = ジャンプ速度
            End If

        End If

        If m_Keys.Check(Keys.Left) Then

            m_ImgIndex += 1
            If m_ImgIndex >= IMAGE_COUNT Then m_ImgIndex = 0
            m_Mario = m_MarioL(m_ImgIndex)
            MarioMove(-IIf(m_Keys.Check(Keys.B), 速度HIGH, 速度LOW), 0)
            m_Mariol向き = False

        End If
        If m_Keys.Check(Keys.Right) Then

            m_ImgIndex += 1
            If m_ImgIndex >= IMAGE_COUNT Then m_ImgIndex = 0
            m_Mario = m_MarioR(m_ImgIndex)
            MarioMove(IIf(m_Keys.Check(Keys.B), 速度HIGH, 速度LOW), 0)
            m_Mariol向き = True
        End If


        If m_Keys.Check(Keys.A) Then
            m_FireBall向き = m_Mariol向き
            m_bFireBallState = False
            If m_FireBall向き Then
                m_FireBallPos = (m_CurPos + New Size(30, 4))
            Else
                m_FireBallPos = (m_CurPos + New Size(0, 4))
            End If
            m_ShowFireBall = True
        End If

        Redraw()

    End Sub

    Private Function MarioMove(ByVal x As Double, ByVal y As Double) As Boolean
        m_CurPos += New Size(x, y)

        If m_CurPos.X < 0 Then
            m_CurPos.X = 0
        End If
        If m_CurPos.Y < 0 Then
            m_CurPos.Y = 0
        End If
        If m_CurPos.X > (m_Parent.ClientRectangle.Width - m_Mario.Width) Then
            m_CurPos.X = m_Parent.ClientRectangle.Width - m_Mario.Width
        End If
        If m_CurPos.Y > (m_Parent.ClientRectangle.Height - m_Mario.Height) Then
            m_CurPos.Y = m_Parent.ClientRectangle.Height - m_Mario.Height
            m_d速度Y = 0
            m_nJumpCount = 0
        End If

    End Function

    Private Sub MoveFireBall()

        '  m_FireBallPos.Y += y
        If m_FireBall向き Then
            m_FireBallPos.X += 8
        Else
            m_FireBallPos.X -= 8
        End If

        If Not m_bFireBallState Then
            m_FireBallPos.Y += 15
        Else
            'm_dFireBall速度Y = m_dFireBall速度Y + 100
            m_dFireBall速度Y = m_dFireBall速度Y + 重力加速度 * 5
            m_FireBallPos.Y += m_dFireBall速度Y / 8
        End If

        'If m_FireBall向き2 Then
        '    m_FireBallPos.Y += 10
        'Else
        '    m_FireBallPos.Y -= 10
        'End If
        If m_FireBallPos.Y < 0 Then
            m_FireBallPos.Y = 0
        End If

        If (m_FireBall向き2 = False) And
            (m_FireBallPos.Y < (m_Parent.ClientRectangle.Height - m_FireBall.Height - 10)) Then
            m_FireBall向き2 = True
            ' m_FireBallState = 3
        End If

        If m_FireBallPos.Y > (m_Parent.ClientRectangle.Height - m_FireBall.Height) Then
            m_FireBallPos.Y = m_Parent.ClientRectangle.Height - m_FireBall.Height
            m_dFireBall速度Y = -130
            m_bFireBallState = True
            m_FireBall向き2 = False
        End If

    End Sub


    Private Sub Redraw()
        'Refresh()
        m_Parent.Invalidate()
        '     Invalidate(New Rectangle(m_CurPos.X, m_CurPos.Y - m_Mario.Height, m_Mario.Width, m_Mario.Height))
    End Sub

    Public Sub LostFocus()
        m_Keys.clear()
    End Sub
End Class
