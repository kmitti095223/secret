﻿Public Class Mario

    Private m_Keys As New PushedKeys
    Private m_Timer As New Timer
    Private m_Parent As Control

    Const 重力加速度 As Double = 15
    Const ジャンプ速度 As Double = -300
    Const 速度LOW As Double = 5
    Const 速度HIGH As Double = 10

    Const IMAGE_COUNT = 5                       ' 〇リオイメージの数
    Private m_MarioR(IMAGE_COUNT) As Bitmap     ' 〇リオ(右向き)のイメージ
    Private m_MarioL(IMAGE_COUNT) As Bitmap     ' 〇リオ(左向き)のイメージ

    Private m_pic As PictureBoxEx


    Private m_ImgIndex As Integer = 0           ' 表示中の〇リオ(または〇イージ)のインデックス
    Private m_Mario As Bitmap                   ' 表示中の〇リオ(または〇イージ)のイメージ

    Private m_MarioPos As Point                 ' 〇リオの現在位置

    Private m_d速度Y As Double                    ' 〇リオの速度
    Private m_nJumpCount As Integer

    Private m_Mariol向き As Boolean = True
    Private m_Marioは床の上 As Boolean = False


    Private m_FireBall As Bitmap
    Private Class FIRE_BALL
        Public m_Pos As Point
        Public m_向きX As Boolean = True
        Public m_向きY As Boolean = True
        Public m_bState As Integer = False
        Public m_d速度Y As Double
    End Class

    Private m_lstFireBall As New List(Of FIRE_BALL)


    Public Sub Initialize(ByRef ctrl As Control, ByVal bMode As Boolean, ByRef pic As PictureBoxEx)

        m_Parent = ctrl
        m_pic = pic

        Dim tmpBmp = My.Resources.mario

        For i = 0 To IMAGE_COUNT

            m_MarioR(i) = tmpBmp.Clone(New Rectangle(i * 32, 0, 32, 32), Imaging.PixelFormat.Format8bppIndexed)

            ' 〇イージ用にパレットを変更する。
            If Not bMode Then
                Dim palette As Imaging.ColorPalette = m_MarioR(i).Palette
                For j As Integer = 0 To palette.Entries.Length - 1
                    Dim c As Object = palette.Entries(j)
                    If c = Color.FromArgb(255, 0, 0) Then
                        palette.Entries(j) = Color.Green
                    End If
                Next
                m_MarioR(i).Palette = palette
            End If

            m_MarioR(i).MakeTransparent(Color.Black)
            m_MarioL(i) = m_MarioR(i).Clone
            m_MarioL(i).RotateFlip(RotateFlipType.RotateNoneFlipX)
        Next

        m_Mario = m_MarioR(0)

        m_MarioPos = New Point(0, 0)

        m_FireBall = My.Resources.fireball
        m_FireBall.MakeTransparent(Color.Black)

        m_Timer.Interval = 50
        m_Timer.Enabled = True
        AddHandler m_Timer.Tick, New EventHandler(AddressOf m_Timer_Tick)

    End Sub

    Public Sub Terminate()
        m_Timer.Enabled = False
    End Sub

    Public Sub Paint(ByRef g As Graphics)

        'if m_MarioPos.Y = (m_Parent.ClientRectangle.Height - m_Mario.Height) Then
        If m_Marioは床の上 Then
            If m_Mariol向き Then
                m_Mario = m_MarioR(m_ImgIndex)
            Else
                m_Mario = m_MarioL(m_ImgIndex)
            End If
        Else
            If m_Mariol向き Then
                m_Mario = m_MarioR(IMAGE_COUNT - 1)
            Else
                m_Mario = m_MarioL(IMAGE_COUNT - 1)
            End If
        End If

        g.DrawImage(m_Mario, m_MarioPos)

        For i As Integer = 0 To (m_lstFireBall.Count - 1)
            g.DrawImage(m_FireBall, m_lstFireBall(i).m_Pos)
        Next

    End Sub

    Public Sub KeyDown(ByVal KeyCode As Keys)

        'm_Keys.DebugPrintKeys()
        Debug.Print(KeyCode)
        m_Keys.Add(KeyCode)

    End Sub

    Public Sub KeyUp(ByVal KeyCode As Keys)
        m_Keys.Remove(KeyCode)
    End Sub

    Private Sub m_Timer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs)

        MarioMove(0, m_d速度Y * 50 / 1000)
        m_d速度Y = m_d速度Y + 50 * 重力加速度 / 10

        For i As Integer = (m_lstFireBall.Count - 1) To 0 Step -1
            If Not MoveFireBall(i) Then
                m_lstFireBall.RemoveAt(i)
            End If
        Next

        Redraw()

        KeyAction()

    End Sub


    Private Sub KeyAction()

        If m_Keys.Check(Keys.F5) Then
            m_MarioPos = New Point(0, m_Parent.ClientRectangle.Height - m_Mario.Height)
        End If

        If m_Keys.Check(Keys.Up) Then

            'Debug.Print(m_d速度Y)
            m_nJumpCount += 1
            If m_nJumpCount <= 6 Then
                m_d速度Y = ジャンプ速度
            End If

        End If

        If m_Keys.Check(Keys.Left) Then

            m_ImgIndex += 1
            If m_ImgIndex >= (IMAGE_COUNT - 1) Then m_ImgIndex = 0
            m_Mario = m_MarioL(m_ImgIndex)
            MarioMove(-IIf(m_Keys.Check(Keys.B), 速度HIGH, 速度LOW), 0)
            m_Mariol向き = False

        End If
        If m_Keys.Check(Keys.Right) Then

            m_ImgIndex += 1
            If m_ImgIndex >= (IMAGE_COUNT - 1) Then m_ImgIndex = 0
            m_Mario = m_MarioR(m_ImgIndex)
            MarioMove(IIf(m_Keys.Check(Keys.B), 速度HIGH, 速度LOW), 0)
            m_Mariol向き = True
        End If


        If m_Keys.Check(Keys.A) Then
            Static tPrev As DateTime = DateTime.Now.AddSeconds(-1)
            Dim tNow As DateTime = Now
            If (tNow - tPrev).Milliseconds > 200 Then

                Dim f As New FIRE_BALL
                f.m_向きX = m_Mariol向き
                f.m_bState = False
                If f.m_向きX Then
                    f.m_Pos = (m_MarioPos + New Size(30, 4))
                Else
                    f.m_Pos = (m_MarioPos + New Size(0, 4))
                End If
                m_lstFireBall.Add(f)

                tPrev = tNow
            End If

        End If

        Redraw()

    End Sub

    Private Function MarioMove(ByVal x As Double, ByVal y As Double) As Boolean
        On Error Resume Next

        m_Marioは床の上 = False

        m_MarioPos += New Size(x, y)

        If m_MarioPos.X < 0 Then
            m_MarioPos.X = 0
        End If
        If m_MarioPos.Y < 0 Then
            m_MarioPos.Y = 0
        End If
        If m_MarioPos.X > (m_Parent.ClientRectangle.Width - m_Mario.Width) Then
            m_MarioPos.X = m_Parent.ClientRectangle.Width - m_Mario.Width
        End If

        If m_MarioPos.Y > (m_Parent.ClientRectangle.Height - m_Mario.Height) Then
            m_MarioPos.Y = m_Parent.ClientRectangle.Height - m_Mario.Height
            m_d速度Y = 0
            m_nJumpCount = 0
        End If

        If m_MarioPos.Y = (m_Parent.ClientRectangle.Height - m_Mario.Height) Then
            m_Marioは床の上 = True
        End If

        For i As Integer = 0 To m_pic.GetTrackerCount - 1
            Dim rect As Rectangle = m_pic.ImageRectToScreenRect(m_pic.GetTracker(i).GetRect())
            If ((m_MarioPos.X + m_Mario.Width) > rect.Left) And
                (m_MarioPos.X < rect.Right) Then
                If m_MarioPos.Y >= (rect.Top - m_Mario.Height) Then
                    m_Marioは床の上 = True
                End If
                If m_MarioPos.Y > (rect.Top - m_Mario.Height) Then
                    m_MarioPos.Y = rect.Top - m_Mario.Height
                    m_d速度Y = 0
                    m_nJumpCount = 0
                    Exit For
                End If
            End If
        Next

    End Function

    Private Function MoveFireBall(ByVal nIndex As Integer) As Boolean

        '  m_Pos.Y += y
        If m_lstFireBall(nIndex).m_向きX Then
            m_lstFireBall(nIndex).m_Pos.X += 8
        Else
            m_lstFireBall(nIndex).m_Pos.X -= 8
        End If

        If Not m_lstFireBall(nIndex).m_bState Then
            m_lstFireBall(nIndex).m_Pos.Y += 15
        Else
            'm_d速度Y = m_d速度Y + 100
            m_lstFireBall(nIndex).m_d速度Y = m_lstFireBall(nIndex).m_d速度Y + 重力加速度 * 5
            m_lstFireBall(nIndex).m_Pos.Y += m_lstFireBall(nIndex).m_d速度Y / 8
        End If

        If m_lstFireBall(nIndex).m_Pos.Y < 0 Then
            m_lstFireBall(nIndex).m_Pos.Y = 0
        End If

        If (m_lstFireBall(nIndex).m_向きY = False) And
            (m_lstFireBall(nIndex).m_Pos.Y < (m_Parent.ClientRectangle.Height - m_FireBall.Height - 10)) Then
            m_lstFireBall(nIndex).m_向きY = True
            ' m_FireBallState = 3
        End If

        If m_lstFireBall(nIndex).m_Pos.Y > (m_Parent.ClientRectangle.Height - m_FireBall.Height) Then
            m_lstFireBall(nIndex).m_Pos.Y = m_Parent.ClientRectangle.Height - m_FireBall.Height
            m_lstFireBall(nIndex).m_d速度Y = -130
            m_lstFireBall(nIndex).m_bState = True
            m_lstFireBall(nIndex).m_向きY = False
        End If

        ' ファイアーボールが画面の外に出たらFalseを返却する。
        Return (m_lstFireBall(nIndex).m_Pos.X >= -m_FireBall.Width) And
                (m_lstFireBall(nIndex).m_Pos.X <= m_Parent.ClientRectangle.Width)


    End Function


    Private Sub Redraw()
        m_Parent.Invalidate()
    End Sub

    Public Sub LostFocus()
        m_Keys.clear()
    End Sub
End Class
