﻿Public Class PushedKeys

    Private m_listKeys As New List(Of Keys)

    Public Sub Add(ByRef key As Keys)
        If Not Check(key) Then
            m_listKeys.Add(key)
        End If
    End Sub

    Public Sub Remove(ByRef key As Keys)
        m_listKeys.Remove(key)
    End Sub

    Public Sub clear()
        m_listKeys.Clear()
    End Sub

    Public Function Check(ByRef key As Keys) As Boolean
        Return m_listKeys.IndexOf(key) >= 0
    End Function

    Public Sub DebugPrintKeys()

        Dim s As String = ""
        For Each k As Keys In m_listKeys
            s &= (New KeysConverter()).ConvertToString(k) & "+"
        Next
        Debug.Print("DebugPrintKeys .. " & s)

    End Sub

End Class
