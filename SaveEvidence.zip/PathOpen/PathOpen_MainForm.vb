Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class PathOpen_MainForm
	Inherits System.Windows.Forms.Form

	'==============================================================================
	' Win32API��`
	'==============================================================================
	Private Declare Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" (ByVal hwnd As Integer, ByVal lpOperation As String, ByVal lpFile As String, ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd As Integer) As Integer
	Private Const SW_SHOWNORMAL As Short = 1


	'==============================================================================
	'
	'  �֐���   : Form_Load
	'  �ԋp�l   : ����
	'  �@�\���� :
	'
	'==============================================================================
	Private Sub MainForm_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

		'--------------------------------------------------------------------------
		' ��`
		'--------------------------------------------------------------------------
		Dim str As String

		'--------------------------------------------------------------------------
		' ��������
		'--------------------------------------------------------------------------
		'�N���b�v�{�[�h���e�L�X�g���擾
		str = GetClipboardText()
		Debug.Print("���N���b�v�{�[�h�̕����񁫁�")
		Debug.Print(str)
		Debug.Print("���N���b�v�{�[�h�̕����񁪁�")

		str = MyReplace(str, "\\PCY5501", "\\PCX2529")

		'--------------------------------------------------------------------------
		' �p�X�\�����[�h�F�w�肳�ꂽ�p�X�^�t�@�C���^URL��\������
		'--------------------------------------------------------------------------
		While ShowPath(str) = True
		End While

		Me.Close()

	End Sub

	'==============================================================================
	'
	'  �֐���   : ShowPath
	'  �ԋp�l   :
	'  �@�\���� : �p�X�\�����[�h�̏���
	'
	'==============================================================================
	Function ShowPath(ByRef sOrg As String) As Boolean

		'--------------------------------------------------------------------------
		' ��`
		'--------------------------------------------------------------------------
		Dim i As Short ' ���[�v�J�E���^
		Dim j As Short ' ���[�v�J�E���^
		Dim arrStr As Object
		Dim nRc As Short
		Dim sPath As String
		Dim sHalfPath As String
		Dim bComplete As Boolean
		Dim arrPath() As String
		ReDim arrPath(0)

		' ��) �ŏ��͍s��؂��\��Ƃ��Ĉ����B2��ڂ͢\��͂��Ȃ��B
		sPath = sOrg

		'--------------------------------------------------------------------------
		' ���s���ꂽ�p�X���Y��ɂ���B
		'--------------------------------------------------------------------------
        ' �s����trim���s�v�������폜
        sPath = Replace(sPath, vbCrLf, vbLf)
        arrStr = Split(sPath, vbLf)
		For i = LBound(arrStr) To UBound(arrStr)
			arrStr(i) = MyTrim(arrStr(i))
		Next

		' ��s���폜
		For i = LBound(arrStr) To UBound(arrStr)
			If arrStr(i) = "" Then
				For j = i To UBound(arrStr) - 1
					arrStr(j) = arrStr(j + 1)
				Next
				ReDim Preserve arrStr(UBound(arrStr) - 1)
			End If
			If i >= UBound(arrStr) Then
				Exit For
			End If
		Next

		'--------------------------------------------------------------------------
		' �p�X��u������
		'--------------------------------------------------------------------------
		Call ShowPath2(arrStr, 1, arrStr(0), arrPath)

		'--------------------------------------------------------------------------
		' �w�肳�ꂽ�p�X��\������B
		'--------------------------------------------------------------------------
		Dim IE As Object
		If (VB.Left(sPath, 7) = "https:/") Or (VB.Left(sPath, 6) = "http:/") Then

			'----------------------------------------------------------------------
			' URL
			'----------------------------------------------------------------------
			IE = CreateObject("InternetExplorer.application")
			IE.navigate(sPath)
			IE.Visible = True

		Else

			'----------------------------------------------------------------------
			' �t�H���_ or �t�@�C��
			'----------------------------------------------------------------------
			For i = LBound(arrPath) To UBound(arrPath)

				If System.IO.Directory.Exists(arrPath(i)) Or System.IO.File.Exists(arrPath(i)) Then
					ShellExecute(0, "open", arrPath(i), vbNullString, vbNullString, SW_SHOWNORMAL)
					GoTo FUNC_END
				End If

			Next

			' ���r���܂ł̃p�X���J����Ȃ�J��
			sPath = arrPath(1)

			If VB.Left(sPath, 1) = "\" And Mid(sPath, 2, 1) <> "\" Then
				sPath = "\" & sPath
			End If

			sHalfPath = CheckPath(sPath, bComplete)
			If bComplete Then
				ShellExecute(0, "open", sHalfPath, vbNullString, vbNullString, SW_SHOWNORMAL)
				GoTo FUNC_END
			End If
			If sHalfPath <> "" Then
				nRc = MsgBox("�w�肳�ꂽ�p�X�͑��݂��܂���B" & vbCrLf & "�J����Ƃ���܂ł̃p�X���J���܂����H" & vbCrLf & vbCrLf & "    �" & sPath & "�" & vbCrLf & "�� �" & sHalfPath & "�", MsgBoxStyle.Exclamation Or MsgBoxStyle.YesNo)
				If nRc = MsgBoxResult.Yes Then
					ShellExecute(0, "open", sHalfPath, vbNullString, vbNullString, SW_SHOWNORMAL)
					GoTo FUNC_END
				End If
			End If


			'----------------------------------------------------------------------
			' ���̑�
			'----------------------------------------------------------------------
			nRc = MsgBox("�w�肳�ꂽ�p�X�͑��݂��܂���B" & vbCrLf & "�p�X���C������ꍇ�͢�͂����I�����Ă��������B" & vbCrLf & vbCrLf & "�" & sPath & "�", MsgBoxStyle.Exclamation Or MsgBoxStyle.YesNo)
			If nRc = MsgBoxResult.Yes Then
				PathOpen_TextForm.txtPath.Text = ""
				For i = LBound(arrStr) To UBound(arrStr)
					If arrStr(i) <> "" Then
						PathOpen_TextForm.txtPath.Text = PathOpen_TextForm.txtPath.Text & Trim(arrStr(i)) & vbCrLf
					End If
				Next
				PathOpen_TextForm.ShowDialog()
				ShowPath = (CDbl(PathOpen_TextForm.Tag) = 1)
				sOrg = PathOpen_TextForm.txtPath.Text
				PathOpen_TextForm.Close()
			End If

		End If

FUNC_END:

	End Function

	Function ShowPath2(ByVal arrStr As Object, ByVal nIndex As Short, ByVal sPath As String, ByRef arrPath() As String) As Object

		Dim i As Short
		Dim arrSplit(2) As String
		arrSplit(0) = ""
		arrSplit(1) = "\"
		arrSplit(2) = " "

		ShowPath2 = ""

		If nIndex <= UBound(arrStr) Then

			For i = LBound(arrSplit) To UBound(arrSplit)
				Call ShowPath2(arrStr, nIndex + 1, sPath & arrSplit(i) & arrStr(nIndex), arrPath)
			Next

		Else

			' �\��̏d�����폜�B���[�Ţ\����d�����Ă���ꍇ��2�ɂ���B
			sPath = VB.Left(sPath, 2) & Replace(Mid(sPath, 3), "\\", "\")
			sPath = VB.Left(sPath, 2) & Replace(Mid(sPath, 3), "\\", "\")
			If VB.Right(sPath, 1) = "\" Then
				sPath = VB.Left(sPath, Len(sPath) - 1)
			End If
			Call ReplaceLeft(sPath, "\\\", "\\")
			Call ReplaceLeft(sPath, "\\\", "\\")
			Call ReplaceLeft(sPath, "\\\", "\\")

			For i = 1 To UBound(arrPath)
				If sPath = arrPath(i) Then
					Exit Function
				End If
			Next
			ReDim Preserve arrPath(UBound(arrPath) + 1)
			arrPath(UBound(arrPath)) = sPath

			Debug.Print("""" & sPath & """")

		End If



	End Function

	'==============================================================================
	'
	'  �֐���   : ReplaceLeft
	'  �ԋp�l   : ����
	'  �@�\���� : ��������폜���܂����B��̉�ʂ���āA�I������B
	'
	'==============================================================================
	Private Sub ReplaceLeft(ByRef sText As String, ByVal sOld As String, ByVal sNew As String)

		If UCase(VB.Left(sText, Len(sOld))) = UCase(sOld) Then
			sText = sNew & Mid(sText, Len(sOld) + 1)
		End If

	End Sub


	'==============================================================================
	'
	'  �֐���   : MyTrim
	'  �ԋp�l   :
	'  �@�\���� :
	'
	'==============================================================================
	Private Function MyTrim(ByVal sText As String) As String

		' 2021.03.11 �s���̢�E����폜����悤�ύX

		Do
			If VB.Left(sText, 1) = "<" Or VB.Left(sText, 1) = ">" Or VB.Left(sText, 1) = "|" Or VB.Left(sText, 1) = """" Or VB.Left(sText, 1) = vbTab Or VB.Left(sText, 1) = " " Or VB.Left(sText, 1) = "�@" Or VB.Left(sText, 1) = "�E" Then

				sText = Mid(sText, 2)

			ElseIf VB.Right(sText, 1) = "<" Or VB.Right(sText, 1) = ">" Or VB.Right(sText, 1) = "|" Or VB.Right(sText, 1) = """" Or VB.Right(sText, 1) = vbTab Or VB.Right(sText, 1) = " " Or VB.Right(sText, 1) = "�@" Then

				sText = VB.Left(sText, Len(sText) - 1)

			Else
				Exit Do
			End If
		Loop While (True)

		MyTrim = sText

	End Function

	'==============================================================================
	'
	'  �֐���   : MyReplace
	'  �ԋp�l   :
	'  �@�\���� :
	'
	'==============================================================================
	Private Function MyReplace(ByVal sText As String, ByVal sOld As String, ByVal sNew As String) As String

		Dim i As Integer
		sOld = LCase(sOld)

		MyReplace = sText

		For i = 1 To Len(sText)
			If LCase(Mid(sText, i, Len(sOld))) = sOld Then
				MyReplace = VB.Left(sText, i - 1) & sNew & Mid(sText, i + Len(sOld))
				Exit Function
			End If
		Next

	End Function


	Private Function GetClipboardText() As String

		' �N���b�v�{�[�h�̃f�[�^���e�L�X�g�ȊO�̏ꍇ�͉������Ȃ��B
		If Not (My.Computer.Clipboard.ContainsText()) Then
			End
		End If

		GetClipboardText = My.Computer.Clipboard.GetText

	End Function

	'----------------------
	' CheckPathModule
	'----------------------

	Public Function CheckPath(ByVal sPath As String, ByRef bComplete As Boolean) As String

		Dim arr() As String
		Dim i As Short
		Dim bIsServer As Boolean

		CheckPath = ""
		sPath = CheckPathTrim(sPath)

		' ��2����\\�̏ꍇ�̓T�[�o�̃p�X
		bIsServer = Strings.Left(sPath, 2) = "\\"

		sPath = Replace(sPath, vbCrLf, "\")
		sPath = Replace(sPath, "\\", "\")

		arr = Split(sPath, "\")

		For i = UBound(arr) To LBound(arr) Step -1

			sPath = MakePath(arr, i, bIsServer)
			If IsExist(sPath) Then
				CheckPath = sPath
				bComplete = (i = LBound(arr))
				Exit For
			End If

		Next

		If i <> UBound(arr) Then

			For i = i + 1 To UBound(arr)

				If Not CheckSubFolder(sPath, arr(i)) Then
					Exit For
				End If
				sPath = sPath & "\" & arr(i)
				bComplete = (i = UBound(arr))
				CheckPath = sPath
			Next

		End If


	End Function

	Private Function MakePath(ByRef arr() As String, ByRef nNum As Short, ByRef bIsServer As Boolean) As String

		Dim i As Short
		MakePath = ""

		For i = 0 To nNum
			MakePath = MakePath & arr(i) & "\"
		Next
		MakePath = Strings.Left(MakePath, Len(MakePath) - 1)

		If bIsServer Then
			MakePath = "\" & MakePath
		End If

	End Function

	Private Function IsExist(ByVal sPath As String) As Boolean

		IsExist = System.IO.Directory.Exists(sPath) Or System.IO.File.Exists(sPath)

	End Function

	Function CheckSubFolder(ByRef sPath As String, ByRef sName As String) As Boolean
		On Error Resume Next
		Dim subFolders As String() = System.IO.Directory.GetDirectories(sPath, "*", System.IO.SearchOption.AllDirectories)
		If subFolders Is Nothing Then
			Exit Function
		End If
		On Error GoTo 0

		For Each sFolder As String In subFolders
			If sName.ToUpper = sFolder.ToUpper Then
				sName = sFolder
				CheckSubFolder = True
				Exit Function
			End If
		Next

		Dim di As New System.IO.DirectoryInfo(sPath)
		Dim files As System.IO.FileInfo() = di.GetFiles("*", System.IO.SearchOption.AllDirectories)

		For Each f As System.IO.FileInfo In files
			If sName.ToUpper = f.Name.ToUpper Then
				sName = f.Name
				CheckSubFolder = True
				Exit Function
			End If
		Next

	End Function


	'==============================================================================
	'
	'  �֐���   : CheckPathTrim
	'  �ԋp�l   :
	'  �@�\���� :
	'
	'==============================================================================
	Private Function CheckPathTrim(ByVal sText As String) As String

		sText = Replace(sText, "/", "")
		sText = Replace(sText, "*", "")
		sText = Replace(sText, "?", "")
		sText = Replace(sText, """", "")
		sText = Replace(sText, "<", "")
		sText = Replace(sText, ">", "")
		sText = Replace(sText, "|", "")
		sText = Replace(sText, vbTab, "")

		' ���E�̋󔒂��폜
		Do
			If Strings.Left(sText, 1) = " " Or Strings.Left(sText, 1) = "�@" Then

				sText = Mid(sText, 2)

			ElseIf Strings.Right(sText, 1) = " " Or Strings.Right(sText, 1) = "�@" Then

				sText = Strings.Left(sText, Len(sText) - 1)

			Else
				Exit Do
			End If
		Loop While (True)

		CheckPathTrim = sText

	End Function

End Class
