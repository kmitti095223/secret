﻿Public Class MainForm
    Public Sub New()

        ' この呼び出しはデザイナーで必要です。
        InitializeComponent()

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim p As New PathOpen2
        Dim f As New PathOpen2.TestPattern

        'p.Open("c:\temp" & vbCrLf & "a.vb")

        f.Load()
        For i As Integer = 0 To f.Count() - 1
            Dim t As PathOpen2.TestPattern.Test = f.GetAt(i)
            p.Test(t)
        Next

        End

    End Sub

End Class

