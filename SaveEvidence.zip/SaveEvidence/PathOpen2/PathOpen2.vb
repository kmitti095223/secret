﻿Imports System.IO
Public Class PathOpen2
    Public Enum PathType
        Empty
        Path
        NotPath
    End Enum

    Dim m_sSrc As String = ""
    Dim m_sFolder As String
    Dim m_sFileName As String
    Private m_bOpenParentFolder As Boolean = False

    Public Sub Exec(ByVal bOpenParentFolder As Boolean)

        ' クリップボードのデータがテキスト以外の場合は何もしない
        If Not (My.Computer.Clipboard.ContainsText()) Then
            Return
        End If

        ' パスオープン2
        m_bOpenParentFolder = bOpenParentFolder

        ' クリップボードの文字列(パス)を開く
        Open(My.Computer.Clipboard.GetText)

    End Sub

    Public Sub Open(ByVal sPath As String)
        On Error GoTo FUNC_ERR

        Dim t As PathType = SetPath(sPath)
        Dim sFilePath As String

        Select Case t
            Case PathType.Empty
                Return

            Case PathType.NotPath
                MsgBox("指定された文字列はパスではありません。" & vbCrLf & vbCrLf & sPath, vbExclamation)

            Case PathType.Path

                ' パス全体で開く
                ' ①フォルダとファイルを｢\｣ありで結合
                If Not m_sFolder.EndsWith("\") Then
                    sFilePath = m_sFolder & m_sFileName
                    If IsFolderOrFile(sFilePath) Then
                        OpenPath(sFilePath)
                        Return
                    End If
                    If m_sFolder <> "" Then
                        sFilePath = m_sFolder & "\" & m_sFileName
                        If IsFolderOrFile(sFilePath) Then
                            OpenPath(sFilePath)
                            Return
                        End If
                    End If
                End If

                ' 開ける部分までを開くか？
                Dim rc As DialogResult =
                        MsgBox("指定されたパスを開けませんでした。開ける部分までを開きますか？" & vbCrLf & vbCrLf & m_sSrc,
                           vbExclamation Or vbYesNo Or MsgBoxStyle.DefaultButton1)
                If rc <> vbYes Then
                    Exit Sub
                End If

                ' 開ける部分までを開く
                sFilePath = m_sFileName
                If m_sFolder <> "" Then
                    sFilePath = m_sFolder & "\" & m_sFileName
                End If

                While True
                    Dim n As Integer = sFilePath.LastIndexOf("\")
                    If n < 0 Then
                        Exit While
                    End If

                    sFilePath = sFilePath.Substring(0, n)
                    If IsFolderOrFile(sFilePath) Then
                        OpenPath(sFilePath)
                        Return
                    End If
                End While

                MsgBox("指定されたパスを開けませんでした。" & vbCrLf & vbCrLf & m_sSrc, vbExclamation)
                Return

            Case Else
                Debug.Assert(False)
        End Select

        Return

FUNC_ERR:
        MsgBox("指定されたパスを開けませんでした。(エラー)", vbExclamation)
    End Sub

    Public Function SetPath(ByVal sPath As String) As PathType

        Dim lstLine As New List(Of String)
        Dim s As String

        sPath = sPath.Substring(0, Math.Min(sPath.Length, 500))  ' 長すぎると問題起きそうなのでカット
        m_sSrc = sPath

        ' 改行を統一
        sPath = sPath.Replace(vbLf, vbCrLf)
        sPath = sPath.Replace(vbCr, vbCrLf)

        ' ファイル名に使えない文字を除去
        sPath = sPath.Replace("/", "")
        'sPath = sPath.Replace(":", "")
        sPath = sPath.Replace("*", "")
        sPath = sPath.Replace("?", "")
        sPath = sPath.Replace("""", "")
        sPath = sPath.Replace("<", "")
        sPath = sPath.Replace(">", "")
        sPath = sPath.Replace("|", "")

        ' 文字列を行ごとに分割 (ここで前後の空白(全角も)が削除される)
        Dim arrLine() As String = sPath.Split(vbCrLf)

        For i As Integer = 0 To arrLine.Length - 1
            s = arrLine(i).Trim
            If s = "" Then
                Continue For
            End If

            lstLine.Add(s)
        Next

        ' 文字列が空になった場合は終了
        If lstLine.Count = 0 Then
            Return PathType.Empty
        End If

        ' 最後だけ行頭の「・」を削除
        lstLine(lstLine.Count - 1) = lstLine(lstLine.Count - 1).TrimStart("・")

        ' フォルダ名(最終行以外)を作成する。
        m_sFolder = ""
        For i As Integer = 0 To lstLine.Count - 1 - 1
            m_sFolder = m_sFolder & lstLine(i)
        Next

        ' 最終行はファイル名とする。
        m_sFileName = lstLine(lstLine.Count - 1)

        ' パスの種類をチェック
        Dim sTarget As String = m_sFolder
        If sTarget = "" Then
            sTarget = m_sFileName
        End If
        If sTarget.StartsWith("\\") Or sTarget.Substring(1, 1) = ":" Then
            Return PathType.Path
        End If
        Return PathType.NotPath

    End Function

    Function IsFolderOrFile(ByVal path As String) As Boolean
        Return (Directory.Exists(path) OrElse File.Exists(path))
    End Function

    Private Sub OpenPath(ByVal sPath As String)

        If File.Exists(sPath) Then
            If m_bOpenParentFolder Then
                sPath = System.IO.Path.GetDirectoryName(sPath)
            End If
        End If
        System.Diagnostics.Process.Start(sPath)


    End Sub


    '==============================================================================================
    ' 以下はテスト用ソース
    '==============================================================================================
    Public Sub Test(ByRef t As TestPattern.Test)

        Debug.Print("--------")
        Debug.Print("[in]")
        Debug.Print(t.sIn)
        Debug.Print("[out]")
        Debug.Print(t.sOutFolder)
        Debug.Print(t.sOutFileName)

        SetPath(t.sIn)

        If m_sFolder <> t.sOutFolder Or
                m_sFileName <> t.sOutFileName Then

            MsgBox("インプット" & vbCrLf &
           t.sIn & vbCrLf &
           "正解" & vbCrLf &
           t.sOutFolder & vbCrLf &
           t.sOutFileName & vbCrLf & vbCrLf &
           "結果" & vbCrLf &
           m_sFolder & vbCrLf &
           m_sFileName, vbExclamation)

            End
        End If

    End Sub

    Public Class TestPattern

        Class Test
            Public sIn As String = ""
            Public sOutFolder As String = ""
            Public sOutFileName As String = ""
        End Class

        Private m_List As New List(Of Test)

        Sub Load()

            Dim nFlag As Integer = 0
            Dim sFilePath As String = Application.StartupPath & "\TestPattern.txt"
            Dim nLine As Integer = 0
            On Error Resume Next

            ' リソースのテキストファイルをStringReaderを使って読み込む
            Using reader As New StreamReader(sFilePath)
                ' 1行ずつ読み込む
                Dim s As String = reader.ReadLine()

                ' 読み込んだ行を処理
                Do While s IsNot Nothing
                    nLine += 1
                    Debug.Print(nLine.ToString & " " & s)

                    If s = "[in]" Then
                        m_List.Add(New Test)
                        nFlag = 0
                    ElseIf s = "[out]" Then
                        nFlag = 1
                    Else
                        Select Case nFlag
                            Case 0
                                m_List(m_List.Count - 1).sIn = m_List(m_List.Count - 1).sIn & s & vbCrLf
                            Case 1
                                m_List(m_List.Count - 1).sOutFolder = s
                                nFlag = nFlag + 1
                            Case 2
                                m_List(m_List.Count - 1).sOutFileName = s
                                nFlag = nFlag + 1
                            Case 3
                                Debug.Assert(False)
                        End Select
                    End If
                    s = reader.ReadLine()
                Loop
            End Using

        End Sub

        Public Function Count() As Integer
            Return m_List.Count
        End Function

        Public Function GetAt(ByVal n As Integer) As Test
            Return m_List(n)
        End Function

    End Class

End Class
