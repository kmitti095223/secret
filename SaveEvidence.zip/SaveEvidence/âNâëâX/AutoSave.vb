﻿Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports System.IO

Public Class AutoSave

    '''<summary>キーボードが押されているか放されているかを表す。</summary>
    Public Enum KeyboardUpDown
        '''<summary>キーは押されている。</summary>
        Down
        '''<summary>キーは放されている。</summary>
        Up
    End Enum

    '''<summary>メッセージコードを表す。</summary>
    Friend Enum KeyboardMessage
        '''<summary>キーが押された。</summary>
        KeyDown = &H100
        '''<summary>キーが放された。</summary>
        KeyUp = &H101
        '''<summary>システムキーが押された。</summary>
        SysKeyDown = &H104
        '''<summary>システムキーが放された。</summary>
        SysKeyUp = &H105
    End Enum

    '''<summary>キーボードの状態を表す。</summary>
    Friend Structure KeyboardState
        '''<summary>仮想キーコード。</summary>
        Public KeyCode As Keys
        '''<summary>スキャンコード。</summary>
        Public ScanCode As Integer
        '''<summary>各種特殊フラグ。</summary>
        Public Flag As Integer
        '''<summary>このメッセージが送られたときの時間。</summary>
        Public Time As Integer
        '''<summary>メッセージに関連づけられた拡張情報。</summary>
        Public ExtraInfo As IntPtr
    End Structure

    '''<summary>メッセージコードを表す。</summary>
    Friend Enum MouseMessage
        '''<summary>キーが押された。</summary>
        KeyDown = &H100
        '''<summary>キーが放された。</summary>
        KeyUp = &H101
        '''<summary>システムキーが押された。</summary>
        SysKeyDown = &H104
        '''<summary>システムキーが放された。</summary>
        SysKeyUp = &H105
    End Enum

    '''<summary>キーボードの状態を表す。</summary>
    Friend Structure MouseState
        '''<summary>仮想キーコード。</summary>
        Public KeyCode As Keys
        '''<summary>スキャンコード。</summary>
        Public ScanCode As Integer
        '''<summary>各種特殊フラグ。</summary>
        Public Flag As Integer
        '''<summary>このメッセージが送られたときの時間。</summary>
        Public Time As Integer
        '''<summary>メッセージに関連づけられた拡張情報。</summary>
        Public ExtraInfo As IntPtr
    End Structure

    <DllImport("user32.dll", SetLastError:=True)> _
    Private Shared Function SetWindowsHookEx(hookType As Integer, hookDelegate As KeyboardHookDelegate, hInstance As IntPtr, threadId As UInteger) As IntPtr
    End Function
    <DllImport("user32.dll", SetLastError:=True)> _
    Private Shared Function CallNextHookEx(hook As IntPtr, code As Integer, message As KeyboardMessage, ByRef state As KeyboardState) As Integer
    End Function

    <DllImport("user32.dll", SetLastError:=True, EntryPoint:="SetWindowsHookEx")> _
    Private Shared Function SetWindowsHookExMouse(hookType As Integer, hookDelegate As MouseHookDelegate, hInstance As IntPtr, threadId As UInteger) As IntPtr
    End Function
    <DllImport("user32.dll", SetLastError:=True, EntryPoint:="CallNextHookEx")> _
    Private Shared Function CallNextHookExMouse(hook As IntPtr, code As Integer, message As IntPtr, state As IntPtr) As Integer
    End Function

    <DllImport("user32.dll", SetLastError:=True)> _
    Private Shared Function UnhookWindowsHookEx(hook As IntPtr) As Boolean
    End Function

    'MouseHookStruct structure declaration.
    <StructLayout(LayoutKind.Sequential)> Public Structure MouseHookStruct
        Public x As Integer
        Public y As Integer
        'Public mouseData As Long
        'Public flags As Long
        'Public time As Long
        'Public dwExtraInfo As Long
    End Structure


    Private Const KeyboardHookType As Integer = 13
    Private Delegate Function KeyboardHookDelegate(code As Integer, message As KeyboardMessage, ByRef state As KeyboardState) As Integer
    Private hookDelegateKeyboard As KeyboardHookDelegate
    Private hookKeyboard As IntPtr


    Private Const WM_LBUTTONDOWN As Integer = &H201
    Private Const WM_LBUTTONUP As Integer = &H202
    Private Const MouseHookType As Integer = 14
    Private Delegate Function MouseHookDelegate(code As Integer, message As IntPtr, state As IntPtr) As Integer
    Private hookDelegateMouse As MouseHookDelegate
    Private hookMouse As IntPtr


    'Import for the GetModuleHandle function.
    <DllImport("kernel32.dll", CharSet:=CharSet.Auto, CallingConvention:=CallingConvention.StdCall)> _
    Public Overloads Shared Function GetModuleHandle _
      (ByVal lpModuleName As String) As IntPtr
    End Function


    Public Function StartSave() As Boolean

        ' キーフック有効だとデバッグしづらいので
        ' デバッグ時はキーフックを有効にしない。
#If DEBUG Then
        Return True
#End If

        If hookKeyboard <> IntPtr.Zero Then
            Return True
        End If

        hookDelegateKeyboard = New KeyboardHookDelegate(AddressOf CallNextHookKeyboard)
        hookKeyboard = SetWindowsHookEx(KeyboardHookType, hookDelegateKeyboard, GetModuleHandle(Process.GetCurrentProcess().MainModule.ModuleName), 0)

        hookDelegateMouse = New MouseHookDelegate(AddressOf CallNextHookMouse)
        hookMouse = SetWindowsHookExMouse(MouseHookType, CType(hookDelegateMouse, MouseHookDelegate), GetModuleHandle(Process.GetCurrentProcess().MainModule.ModuleName), 0)

        Return True

    End Function

    Public Sub StopSave()

        If hookKeyboard <> IntPtr.Zero Then
            UnhookWindowsHookEx(hookKeyboard)
            hookKeyboard = IntPtr.Zero
        End If

        If hookMouse <> IntPtr.Zero Then
            UnhookWindowsHookEx(hookMouse)
            hookMouse = IntPtr.Zero
        End If

    End Sub

    Private Function CallNextHookKeyboard(code As Integer, message As KeyboardMessage, ByRef state As KeyboardState) As Integer

        If code >= 0 Then

            '    Debug.Print(String.Format("code={0}, message={1}, state={2}", code, message, state.KeyCode))

            If (message = KeyboardMessage.KeyUp) Or
                (message = KeyboardMessage.SysKeyUp) Then

                If (state.KeyCode = Keys.Enter) Or
                    (state.KeyCode = Keys.Space) Or
                    (state.KeyCode = Keys.Enter) Then

                    Save("Key_" & state.KeyCode.ToString)

                End If

            End If

        End If

        Return CallNextHookEx(hookKeyboard, code, message, state)

    End Function

    Private Function CallNextHookMouse(code As Integer, wParam As IntPtr, lParam As IntPtr) As Integer

        If code >= 0 Then


            'If wParam = WM_LBUTTONUP Then
            '    Save("Mouse_LButtonUp")
            'End If


            If wParam = WM_LBUTTONDOWN Then
                Dim MyMouseHookStruct As New MouseHookStruct()
                MyMouseHookStruct = CType(Marshal.PtrToStructure(lParam, MyMouseHookStruct.GetType()), MouseHookStruct)
                Save("Mouse_LButtonDown", New Point(MyMouseHookStruct.x, MyMouseHookStruct.y))
            End If

        End If


        Return CallNextHookExMouse(hookMouse, code, wParam, lParam)

    End Function

    Sub Save(ByVal sType As String, Optional posMouse As Object = Nothing)

        Dim sw As New Stopwatch()
        sw.Start()

        Dim sActiveProcessName As String = GetActiveWindow()
        If (String.Compare(sActiveProcessName, "Explorer", True) = 0) Or _
            (String.Compare(sActiveProcessName, "SaveEvidence", True) = 0) Or _
            (String.Compare(sActiveProcessName, "MsPaint", True) = 0) Then
            Exit Sub
        End If

        'Dim ScreenBmp As Bitmap = Nothing
        'ScreenBmp = New Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height)
        'Dim g As Graphics = Graphics.FromImage(ScreenBmp)
        'g.CopyFromScreen(New Point(0, 0), New Point(0, 0), ScreenBmp.Size)
        'g.Dispose()
        'g = Nothing

        'Dim ScreenBmp2 As Bitmap = Nothing
        'ScreenBmp2 =New Bitmap(CInt(Screen.PrimaryScreen.Bounds.Width / 2), CInt(Screen.PrimaryScreen.Bounds.Height / 2))
        'Dim g2 As Graphics = Graphics.FromImage(ScreenBmp2)
        'g2.DrawImage(ScreenBmp, CInt(Screen.PrimaryScreen.Bounds.Width / 2), CInt(Screen.PrimaryScreen.Bounds.Height / 2))
        'g2.Dispose()
        'g2 = Nothing
        'ScreenBmp = ScreenBmp2

        Dim ScreenBmp As Bitmap = Nothing
        ScreenBmp = New Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height)
        Dim g As Graphics = Graphics.FromImage(ScreenBmp)
        g.CopyFromScreen(New Point(0, 0), New Point(0, 0), ScreenBmp.Size)
        If posMouse IsNot Nothing Then
            Dim pos As Point = CType(posMouse, Point)
            Const nLEN = 10
            g.DrawLine(New Pen(Brushes.Red, 3), New Point(pos.X - nLEN, pos.Y - nLEN), New Point(pos.X + nLEN, pos.Y + nLEN))
            g.DrawLine(New Pen(Brushes.Red, 3), New Point(pos.X - nLEN, pos.Y + nLEN), New Point(pos.X + nLEN, pos.Y - nLEN))
        End If
        g.Dispose()
        g = Nothing

        Dim sFolder As String = ""
        Dim sFilePath As String = ""

        sFolder = Application.StartupPath & "\自動保存"
        Directory.CreateDirectory(sFolder)

        sFolder += ("\" & DateTime.Now.ToString("yyyy年MM月dd日"))
        Directory.CreateDirectory(sFolder)

        sFolder += ("\" & DateTime.Now.ToString("HH時"))
        Directory.CreateDirectory(sFolder)

        For i As Integer = 1 To 99

            sFilePath = String.Format("{0}\{1}_{2}([{3}]{4}).png", _
                                     sFolder, _
                                     DateTime.Now.ToString("yyyy年MM月dd日_HH時mm分ss秒"),
                                     i.ToString("D3"), _
                                     sActiveProcessName, _
                                     sType)

            If File.Exists(sFilePath) Then
                Continue For
            End If

            Try
                ScreenBmp.Save(sFilePath)
                Exit For
            Catch ex As Exception
                Continue For
            End Try

        Next

        Debug.Print("Save .. " & sw.ElapsedMilliseconds & " ms")
        GC.Collect()

    End Sub

End Class
