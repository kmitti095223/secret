﻿Imports System
Imports System.Text
Imports System.Runtime.InteropServices
Imports System.Management ' WMI の使用に必要

Public Class BrowserWindowDetector
    <DllImport("user32.dll")>
    Private Shared Function GetForegroundWindow() As IntPtr
    End Function

    <DllImport("user32.dll")>
    Private Shared Function GetWindowThreadProcessId(hWnd As IntPtr, ByRef lpdwProcessId As UInteger) As UInteger
    End Function

    ''' <summary>
    ''' 現在のフォアグラウンドウィンドウがブラウザかどうかを判別し、ブラウザならハンドルを返す。
    ''' </summary>
    ''' <returns>ブラウザのウィンドウハンドル (IntPtr)、ブラウザでなければ IntPtr.Zero</returns>
    Public Shared Function IsForegroundWindowBrowser() As IntPtr
        Dim hWnd As IntPtr = GetForegroundWindow()
        If hWnd = IntPtr.Zero Then Return IntPtr.Zero

        Dim processId As UInteger
        GetWindowThreadProcessId(hWnd, processId)
        If processId = 0 Then Return IntPtr.Zero

        Dim processName As String = GetProcessNameById(processId).ToLower()
        If String.IsNullOrEmpty(processName) Then Return IntPtr.Zero

        Dim browserProcesses As String() = {"chrome.exe", "firefox.exe", "msedge.exe", "iexplore.exe", "opera.exe", "brave.exe", "vivaldi.exe"}

        If Array.Exists(browserProcesses, Function(x) x = processName) Then
            Return hWnd ' ブラウザならウィンドウハンドルを返す
        End If

        Return IntPtr.Zero ' ブラウザでなければ IntPtr.Zero を返す
    End Function

    ''' <summary>
    ''' WMI を使用してプロセスIDからプロセス名を取得
    ''' </summary>
    ''' <param name="processId">プロセスID</param>
    ''' <returns>プロセス名 (取得できない場合は空文字列)</returns>
    Private Shared Function GetProcessNameById(processId As UInteger) As String
        Try
            Dim query As String = $"SELECT Name FROM Win32_Process WHERE ProcessId = {processId}"
            Using searcher As New ManagementObjectSearcher("root\CIMV2", query)
                For Each queryObj As ManagementObject In searcher.Get()
                    Return queryObj("Name").ToString()
                Next
            End Using
        Catch ex As Exception
            ' エラー時は空文字列を返す
        End Try
        Return String.Empty
    End Function
End Class
