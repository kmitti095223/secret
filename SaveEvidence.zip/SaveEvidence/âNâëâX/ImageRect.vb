﻿Public Class ImageRect

    Const MIN_LINE_LENGTH As Integer = 13
    Const MIN_LINE_LENGTH_HALF As Integer = MIN_LINE_LENGTH / 2

    Const MAX_BUTTON_WIDTH As Integer = 300
    Const MAX_BUTTON_WIDTH_HALF As Integer = MAX_BUTTON_WIDTH / 2

    Const MAX_BUTTON_HEIGHT As Integer = 50
    Const MAX_BUTTON_HEIGHT_HALF As Integer = MAX_BUTTON_HEIGHT / 2

    Public Shared Function CheckRect(ByRef bmp As Bitmap, ByVal pos As Point, ByRef rect As Rectangle) As Boolean

        ' 画像のサイズを取得
        Dim width As Integer = bmp.Width
        Dim height As Integer = bmp.Height

        Dim pixelColor As Color

        rect = Rectangle.Empty
        Dim count As Integer = 0

        Dim CurrentColor As Color = bmp.GetPixel(pos.X, pos.Y)

        ' 左探索
        For x As Integer = pos.X - 1 To Math.Max(0, pos.X - MAX_BUTTON_WIDTH_HALF) Step -1

            If Check(CurrentColor, True, bmp, New Point(x, pos.Y), pixelColor) Then
                rect.X = x
                count += 1
                Exit For
            End If
        Next

        ' 右探索
        For x As Integer = pos.X + 1 To Math.Min(bmp.Width - 1, pos.X + MAX_BUTTON_WIDTH_HALF)

            If Check(CurrentColor, True, bmp, New Point(x, pos.Y), pixelColor) Then
                rect.Width = x - rect.X
                count += 1
                Exit For
            End If
        Next

        ' 上探索
        For y As Integer = pos.Y - 1 To Math.Max(0, pos.Y - MAX_BUTTON_HEIGHT_HALF) Step -1

            If Check(CurrentColor, False, bmp, New Point(pos.X, y), pixelColor) Then
                rect.Y = y
                count += 1
                Exit For
            End If
        Next

        ' 下探索
        For y As Integer = pos.Y + 1 To Math.Min(bmp.Height - 1, pos.Y + MAX_BUTTON_HEIGHT_HALF)

            If Check(CurrentColor, False, bmp, New Point(pos.X, y), pixelColor) Then
                rect.Height = y - rect.Y
                count += 1
                Exit For
            End If
        Next

        Dim expandBy As Integer = 2
        Dim newX As Integer = Math.Max(0, rect.X - expandBy)
        Dim newY As Integer = Math.Max(0, rect.Y - expandBy)

        Dim newWidth As Integer = Math.Min(bmp.Width - newX, rect.Width + expandBy * 2)
        Dim newHeight As Integer = Math.Min(bmp.Height - newY, rect.Height + expandBy * 2)

        rect = New Rectangle(newX, newY, newWidth, newHeight)
        Debug.Print(rect.ToString)

        '  If rect.Left =0 Or rect.Right = 0 Or 

        Return count = 4
    End Function

    Private Shared Function Check(ByVal CurrentColor As Color, ByVal bVertical As Boolean, ByRef bmp As Bitmap, ByVal pos As Point, ByRef pixelColor As Color) As Boolean

        pixelColor = bmp.GetPixel(pos.X, pos.Y)
        Debug.Print("Check .. " & pos.ToString() & vbTab & pixelColor.ToString)

        'Dim r = AreColorsSimilar(Color.FromArgb(100, 100, 150), Color.White)

        ' 白は対象外
        If AreColorsSimilar(pixelColor, Color.White, 40) Then
            Return False
        End If

        ' 起点の色と同じ場合は対象外
        If AreColorsSimilar(pixelColor, CurrentColor, 30) Then
            Return False
        End If

        Dim LineLength As Integer = 0

        If bVertical Then

            ' 縦線チェック (上方向)
            For y As Integer = pos.Y To pos.Y - MAX_BUTTON_HEIGHT Step -1

                ' 同じ色でなければ探索終了
                If Not AreColorsSimilar(bmp.GetPixel(pos.X, y), pixelColor) Then
                    Exit For
                End If

                LineLength += 1
                If LineLength >= MIN_LINE_LENGTH Then
                    Return True
                End If
            Next

            ' 縦線チェック (下方向)
            For y As Integer = pos.Y To pos.Y + MAX_BUTTON_HEIGHT

                ' 同じ色でなければ探索終了
                If Not AreColorsSimilar(bmp.GetPixel(pos.X, y), pixelColor) Then
                    Return False
                End If

                LineLength += 1
                If LineLength >= MIN_LINE_LENGTH Then
                    Return True
                End If
            Next

        Else

            ' 横線チェック (左方向)
            For x As Integer = pos.X To pos.X - MAX_BUTTON_WIDTH Step -1

                ' 同じ色でなければ探索終了
                If Not AreColorsSimilar(bmp.GetPixel(x, pos.Y), pixelColor) Then
                    Exit For
                End If

                LineLength += 1
                If LineLength >= MIN_LINE_LENGTH Then
                    Return True
                End If
            Next

            ' 横線チェック (右方向)
            For x As Integer = pos.X To pos.X + MAX_BUTTON_WIDTH

                ' 同じ色でなければ探索終了
                If Not AreColorsSimilar(bmp.GetPixel(x, pos.Y), pixelColor) Then
                    Return False
                End If

                LineLength += 1
                If LineLength >= MIN_LINE_LENGTH Then
                    Return True
                End If
            Next

        End If

        Return True
    End Function

    Shared Function AreColorsSimilar(color1 As Color, color2 As Color, Optional threshold As Double = 30) As Boolean

        ' R, G, Bの値をDouble型にキャストして差分を計算
        Dim rDifference As Double = CDbl(color1.R) - CDbl(color2.R)
        Dim gDifference As Double = CDbl(color1.G) - CDbl(color2.G)
        Dim bDifference As Double = CDbl(color1.B) - CDbl(color2.B)

        ' ユークリッド距離を計算
        Dim distance As Double = Math.Sqrt(rDifference ^ 2 + gDifference ^ 2 + bDifference ^ 2)

        ' Debug.Print(distance.ToString)

        Return distance < threshold

    End Function

End Class
