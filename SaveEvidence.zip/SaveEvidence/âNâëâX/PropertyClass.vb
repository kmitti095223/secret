﻿Imports System.ComponentModel

Public Class PropertyClass

    ' https://dobon.net/vb/dotnet/control/propertygrid.html

    Private _四角の太さ As Integer = 3
    Private _四角の色 As System.Drawing.Color = System.Drawing.Color.Red

    Private _テキスト枠の太さ As Integer = 3
    Private _テキスト枠の色 As System.Drawing.Color = System.Drawing.Color.Red
    Private _テキスト枠の文字色 As System.Drawing.Color = System.Drawing.Color.Blue
    Private _テキスト枠の背景色 As System.Drawing.Color = System.Drawing.Color.Yellow
    Private _テキスト枠の透明度 As Integer = 128
    Private _テキスト枠のフォント As New Font("MS UI Gothic", 14)

    Private _矢印線の太さ As Integer = 5
    Private _矢印線の色 As System.Drawing.Color = System.Drawing.Color.Blue

    ' 四角
    <Category("四角")> _
    Public Property 四角の太さ() As Integer
        Get
            Return _四角の太さ
        End Get
        Set(ByVal Value As Integer)
            If (1 <= Value) And (Value <= 20) Then
                _四角の太さ = Value
            End If
        End Set
    End Property

    <Category("四角")> _
    Public Property 四角の色() As System.Drawing.Color
        Get
            Return _四角の色
        End Get
        Set(ByVal Value As System.Drawing.Color)
            _四角の色 = Value
        End Set
    End Property

    ' テキスト枠
    <Category("テキスト枠")> _
    Public Property テキスト枠の太さ() As Integer
        Get
            Return _テキスト枠の太さ
        End Get
        Set(ByVal Value As Integer)
            If (1 <= Value) And (Value <= 20) Then
                _テキスト枠の太さ = Value
            End If
        End Set
    End Property

    <Category("テキスト枠")> _
    Public Property テキスト枠の色() As System.Drawing.Color
        Get
            Return _テキスト枠の色
        End Get
        Set(ByVal Value As System.Drawing.Color)
            _テキスト枠の色 = Value
        End Set
    End Property

    <Category("テキスト枠")> _
    Public Property テキスト枠の文字色() As System.Drawing.Color
        Get
            Return _テキスト枠の文字色
        End Get
        Set(ByVal Value As System.Drawing.Color)
            _テキスト枠の文字色 = Value
        End Set
    End Property

    <Category("テキスト枠")> _
    Public Property テキスト枠の背景色() As System.Drawing.Color
        Get
            Return _テキスト枠の背景色
        End Get
        Set(ByVal Value As System.Drawing.Color)
            _テキスト枠の背景色 = Value
        End Set
    End Property

    <Category("テキスト枠")> _
    Public Property テキスト枠の透明度() As Integer
        Get
            Return _テキスト枠の透明度
        End Get
        Set(ByVal Value As Integer)
            If (1 <= Value) And (Value <= 255) Then
                _テキスト枠の透明度 = Value
            End If
        End Set
    End Property

    <Category("テキスト枠")> _
    Public Property テキスト枠のフォント() As Font
        Get
            Return _テキスト枠のフォント
        End Get
        Set(ByVal Value As Font)
            If Value IsNot Nothing Then
                _テキスト枠のフォント = New Font(Value.FontFamily, Math.Round(Value.Size), Value.Style, GraphicsUnit.Point)
            End If
        End Set
    End Property

    ' 矢印
    <Category("矢印")> _
    Public Property 矢印線の太さ() As Integer
        Get
            Return _矢印線の太さ
        End Get
        Set(ByVal Value As Integer)
            If (1 <= Value) And (Value <= 20) Then
                _矢印線の太さ = Value
            End If
        End Set
    End Property

    <Category("矢印")> _
    Public Property 矢印線の色() As System.Drawing.Color
        Get
            Return _矢印線の色
        End Get
        Set(ByVal Value As System.Drawing.Color)
            _矢印線の色 = Value
        End Set
    End Property

    Public Sub New(ByVal bLoad As Boolean)

        If Not bLoad Then
            Exit Sub
        End If

        四角の太さ = My.Settings.四角の太さ
        四角の色 = New ColorConverter().ConvertFromString(My.Settings.四角の色)

        テキスト枠の太さ = My.Settings.テキスト枠の太さ
        テキスト枠の色 = New ColorConverter().ConvertFromString(My.Settings.テキスト枠の色)
        テキスト枠の文字色 = New ColorConverter().ConvertFromString(My.Settings.テキスト枠の文字色)
        テキスト枠の背景色 = New ColorConverter().ConvertFromString(My.Settings.テキスト枠の背景色)
        テキスト枠の透明度 = My.Settings.テキスト枠の透明度
        テキスト枠のフォント = New FontConverter().ConvertFromString(My.Settings.テキスト枠のフォント)

        矢印線の太さ = My.Settings.矢印線の太さ
        矢印線の色 = New ColorConverter().ConvertFromString(My.Settings.矢印線の色)

    End Sub

    Protected Overrides Sub Finalize()
        Save()
    End Sub

    Public Sub Save()
        My.Settings.四角の太さ = 四角の太さ
        My.Settings.四角の色 = New ColorConverter().ConvertToString(四角の色)

        My.Settings.テキスト枠の太さ = テキスト枠の太さ
        My.Settings.テキスト枠の色 = New ColorConverter().ConvertToString(テキスト枠の色)
        My.Settings.テキスト枠の文字色 = New ColorConverter().ConvertToString(テキスト枠の文字色)
        My.Settings.テキスト枠の背景色 = New ColorConverter().ConvertToString(テキスト枠の背景色)
        My.Settings.テキスト枠の透明度 = テキスト枠の透明度
        My.Settings.テキスト枠のフォント = New FontConverter().ConvertToString(テキスト枠のフォント)

        My.Settings.矢印線の太さ = 矢印線の太さ
        My.Settings.矢印線の色 = New ColorConverter().ConvertToString(矢印線の色)

        My.Settings.Save()

        MyBase.Finalize()
    End Sub

    ' コピーを作成するメソッド
    Public Function Clone() As PropertyClass
        Return MemberwiseClone()
    End Function

End Class
