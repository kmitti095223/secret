﻿Public Class RestoreWindow

    ''' <summary>
    ''' ウィンドウの位置、サイズを復元する。
    ''' </summary>
    ''' <param name="frm"></param>
    ''' <remarks></remarks>
    Public Shared Sub Restore(ByRef frm As Form)

        Dim nWindowState As Integer = My.Settings.WindowState
        Dim pos = New Point(My.Settings.WindowLocationX, My.Settings.WindowLocationY)
        Dim size As New Size(My.Settings.WindowSizeX, My.Settings.WindowSizeY)

        If size.Width < 800 OrElse size.Height < 600 Then ' ここは通らないはず
            size = New Size(800, 600)
        End If

        ' Size(50,50) はちょっとおまけ。
        ' ウィンドウを右寄せにした場合、右下が画面からはみ出ると判定されてしまったため、ちょっと調整する。
        If Not IsLocationInAnyScreen(pos) Or Not IsLocationInAnyScreen(pos + size - New Size(50, 50)) Then
            Try ' メインスクリーンが取れないことは無いと思うが念のため例外処理
                pos = Screen.AllScreens(0).WorkingArea.Location
                size = New Size(800, 600)
            Catch
                pos = New Point(0, 0)
            End Try
        End If


        If nWindowState = FormWindowState.Minimized Then
            nWindowState = FormWindowState.Normal
        End If
        frm.WindowState = nWindowState

        frm.Location = pos
        frm.Size = size

    End Sub

    ''' <summary>
    ''' ウィンドウの位置、サイズを保存する。
    ''' </summary>
    ''' <param name="frm"></param>
    ''' <remarks></remarks>
    Public Shared Sub Save(ByRef frm As Form)

        My.Settings.WindowState = frm.WindowState

        If (frm.WindowState = FormWindowState.Normal) Then
            My.Settings.WindowLocationX = frm.Location.X
            My.Settings.WindowLocationY = frm.Location.Y
            My.Settings.WindowSizeX = frm.Size.Width
            My.Settings.WindowSizeY = frm.Size.Height
        ElseIf (frm.WindowState = FormWindowState.Minimized) Then
            My.Settings.WindowLocationX = 0
            My.Settings.WindowLocationY = 0
            My.Settings.WindowSizeX = 0
            My.Settings.WindowSizeY = 0
        Else
            My.Settings.WindowLocationX = frm.RestoreBounds.Location.X
            My.Settings.WindowLocationY = frm.RestoreBounds.Location.Y
            My.Settings.WindowSizeX = frm.RestoreBounds.Size.Width
            My.Settings.WindowSizeY = frm.RestoreBounds.Size.Height
        End If

        My.Settings.Save()
    End Sub

    Public Shared Function IsLocationInAnyScreen(location As Point) As Boolean

        ' 全画面を確認します。
        For Each s As Screen In Screen.AllScreens
            ' 座標がScreenの範囲内にあるかどうかを確認します。
            If s.Bounds.Contains(location) Then
                Return True
            End If
        Next

        ' 座標がどのScreenの範囲内にもない場合はFalseを返します。
        Return False
    End Function

End Class
