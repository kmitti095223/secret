﻿Public Class ShortcutKey

    Public Const MOD_ALT As Integer = &H1
    Public Const MOD_CONTROL As Integer = &H2
    Public Const MOD_SHIFT As Integer = &H4
    Public Const MOD_WIN As Integer = &H8

    Public Const MOD_CONTROL_ALT As Integer = MOD_ALT + MOD_CONTROL
    ' Public Const WM_HOTKEY As Integer = &H312

    Private m_nKeyValue As Integer

    Public Sub New(ByVal sKey As String)
        SetKeyStr(sKey)
    End Sub

    Public Function SetKeyStr(ByVal sKey As String) As Integer

        ' 半角に変換
        sKey = StrConv(sKey, VbStrConv.Narrow)

        ' 余計な空白を除去
        sKey = sKey.Replace(vbTab, "")
        sKey = sKey.Replace(" ", "")

        ' 仮想キー="+"の判別のためいったん置換
        sKey = sKey.Replace("++", "+＋")

        ' 区切り文字で分割
        Dim arrKeys() As String = sKey.Split("+")

        ' 仮想キー="+"の判別のため全角に置換した文字を戻す
        For i As Integer = 0 To arrKeys.Length - 1
            arrKeys(i) = arrKeys(i).Replace("＋", "+")
        Next

        ' 区切られたキーをキーコードに変換
        m_nKeyValue = 0
        For Each s In arrKeys
            m_nKeyValue += KeyConvStringToInteger(s)
        Next

        Return m_nKeyValue

    End Function

    Public Function GetKeyStr(Optional ByVal nValue As Integer = -1) As String

        If nValue = -1 Then
            nValue = m_nKeyValue
        End If

        GetKeyStr = ""

        If nValue And MOD_CONTROL Then
            GetKeyStr &= "Ctrl+"
            nValue -= MOD_CONTROL
        End If

        If nValue And MOD_SHIFT Then
            GetKeyStr &= "Shift+"
            nValue -= MOD_SHIFT
        End If

        If nValue And MOD_ALT Then
            GetKeyStr &= "Alt+"
            nValue -= MOD_ALT
        End If

        If nValue And MOD_WIN Then
            GetKeyStr &= "Windows+"
            nValue -= MOD_WIN
        End If

        ' 右に16ビットシフト
        nValue = nValue >> 16

        ' ファンクションキー
        For i As Integer = Keys.F1 To Keys.F24
            If i = nValue Then
                GetKeyStr &= ("F" & (i - Keys.F1 + 1) & "+")
                nValue = 0
                Exit For
            End If
        Next

        ' アルファベット
        For i As Integer = Keys.A To Keys.Z
            If i = nValue Then
                GetKeyStr &= (Chr(i) & "+")
                nValue = 0
                Exit For
            End If
        Next

        ' 数字
        For i As Integer = Keys.NumPad0 To Keys.NumPad9
            If i = nValue Then
                GetKeyStr &= (Chr(Asc("0") + i - Keys.NumPad0) & "+")
                nValue = 0
                Exit For
            End If
        Next

        ' ｢-｣キー
        If nValue = Keys.Subtract Then
            GetKeyStr &= ("-" & "+")
            nValue = 0
        End If

        ' ｢+｣キー
        If nValue = Keys.Add Then
            GetKeyStr &= ("+" & "+")
            nValue = 0
        End If

        ' ｢*｣キー
        If nValue = Keys.Multiply Then
            GetKeyStr &= ("*" & "+")
            nValue = 0
        End If

        Debug.Assert(nValue = 0)

        If GetKeyStr.Length > 0 Then
            GetKeyStr = GetKeyStr.Substring(0, GetKeyStr.Length - 1)
        End If

    End Function

    Public Function GetKeyValue() As Integer
        Return m_nKeyValue
    End Function

    Public Sub SetKeyValue(ByVal nValue As Integer, ByVal nDefault As Integer)
        m_nKeyValue = nValue
    End Sub


    Public Function GetModKey() As Integer
        Return (m_nKeyValue And &HFFFF)
    End Function

    Public Function GetModKeyStr() As String
        Return GetKeyStr(m_nKeyValue And &HFFFF)
    End Function

    Public Function GetVirtualKey() As Integer
        Return (m_nKeyValue >> 16)
    End Function

    Public Function GetVirtualKeyStr() As String
        Return GetKeyStr(m_nKeyValue And &HFFFF0000)
    End Function

    Private Function KeyConvStringToInteger(ByVal sKey As String) As Integer

        ' 全角統一
        sKey = sKey.ToUpper().Trim

        ' 空文字は終了
        If sKey = "" Then
            Return 0
        End If

        ' 修飾キー
        Select Case sKey
            Case "ALT"
                Return MOD_ALT
            Case "CONTROL", "CTL", "CTRL"
                Return MOD_CONTROL
            Case "SHIFT"
                Return MOD_SHIFT
            Case "WIN", "WINDOWS"
                Return MOD_WIN
            Case Else
                Exit Select
        End Select

        ' ファンクションキー (一応F24まで)
        For I As Integer = 1 To 24
            If ("F" & I) = sKey Then
                Return (Keys.F1 + I - 1) * &H10000
            End If
            If ("F" & Strings.Right("00" & I, 2)) = sKey Then
                Return (Keys.F1 + I - 1) * &H10000
            End If
        Next

        ' 上記以外は1文字じゃなきゃダメ
        If sKey.Length <> 1 Then
            Return 0
        End If

        ' アルファベット
        If Char.IsLetter(sKey) Then
            Return (Asc(sKey) * &H10000)
        End If

        ' 数字
        If "01234567890".Contains(sKey) Then
            Return (Keys.NumPad0 + Asc(sKey) - Asc("0")) * &H10000
        End If

        If sKey = "-" Then Return Keys.Subtract * &H10000   ' ｢-｣キー
        If sKey = "+" Then Return Keys.Add * &H10000        ' ｢+｣キー
        If sKey = "*" Then Return Keys.Multiply * &H10000   ' ｢*｣キー

        ' 不正なキー
        Debug.Assert(False)

        Return 0

    End Function

End Class
