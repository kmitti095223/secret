﻿' MIS-400-00 ST400-42022 対応(T)
' フォーカスが来ないボタン
' https://social.msdn.microsoft.com/Forums/vstudio/ja-JP/aacd5485-9b7f-4dad-9ba0-9c5ec68c5cf5?forum=csharpgeneralja

' 方法 : 既存の Windows フォーム コントロールから継承する
' https://msdn.microsoft.com/ja-jp/library/7h62478z(v=vs.110).aspx

' ControlStyles.Selectable を False に設定してもフォーカスが設定される場合がある
' http://blogs.wankuma.com/youryella/archive/2008/02/26/125060.aspx

' ※ 以下の方法ではフォーカスをセットできてしまうようですが、
' 　 わざわざこれらの操作を行うことはないはずなので、問題ないと思います。
' ・Focus メソッド
' ・Select メソッド
' ・ActiveControl プロパティ


''' <summary>
''' フォーカスを持たないボタンのクラス
''' </summary>
''' <remarks></remarks>
Partial Public Class NonFocusButton
    Inherits System.Windows.Forms.Button

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub New()

        ' コンポーネントの初期化を行う。
        InitializeComponent()

        ' フォーカスを受け取らないよう設定する。
        SetStyle(ControlStyles.Selectable, False)

    End Sub

End Class
' MIS-400-00 ST400-42022 対応(B)