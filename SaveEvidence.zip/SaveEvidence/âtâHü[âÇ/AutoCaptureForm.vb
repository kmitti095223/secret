﻿Public Class AutoCaptureForm

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Me.Show()
        'Application.DoEvents()

        'Dim ScreenBmp As Bitmap = Nothing
        'ScreenBmp = New Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height)
        'Dim g As Graphics = Graphics.FromImage(ScreenBmp)
        'g.CopyFromScreen(New Point(0, 0), New Point(0, 0), ScreenBmp.Size)

        'Dim sFilePath As String
        'sFilePath = Now.ToString("yyyyMMddHHmmss")
        'sFilePath = Application.StartupPath & "\" & sFilePath & ".png"
        'ScreenBmp.Save(sFilePath)

        'g.Dispose()
        'g = Nothing

        'Application.DoEvents()
        'Threading.Thread.Sleep(500)

        'Application.Exit()

    End Sub
End Class
