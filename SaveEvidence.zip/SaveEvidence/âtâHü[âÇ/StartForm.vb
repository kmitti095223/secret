﻿Imports System.IO

Public Class StartForm

    Private Const WM_HOTKEY As Integer = &H312

    Private Sub MainForm_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load

        ' 引数でファイルパスが指定された場合、
        If Environment.GetCommandLineArgs.Length = 2 Then
            SaveFile(Environment.GetCommandLineArgs(1))
            End
        End If

        ' 二重起動は禁止
        If Diagnostics.Process.GetProcessesByName(Diagnostics.Process.GetCurrentProcess.ProcessName).Length > 1 Then
            End
        End If

        g_StartFormHandle = Me.Handle
        Me.Hide()

        ' 格納フォルダを取得する。存在しない場合はSaveEvidence.exeのパスにより決定する。
        g_sFolder = My.Settings.格納フォルダ
        g_sFolder = g_sFolder.Trim("\")
        If Not Directory.Exists(g_sFolder) Then
            g_sFolder = Application.StartupPath & "\エビデンス\"
        Else
            g_sFolder = g_sFolder.Trim("\") & "\"
        End If
        Directory.CreateDirectory(g_sFolder)

        ' ファイルの一覧を作成する。
        g_RecentFileList.CreateFileList(g_sFolder)

        ' ショートカットキー設定
        ShortcutKeySettingForm.Initialize()
        ShortcutKeySettingForm.RegisterHotKey()

#If DEBUG Then
        'ShortcutKeySettingForm.ShowDialog()
        'ShortcutKeySettingForm.ShowDialog()
        'End

        'Dim frm As New RenameForm
        'frm.Show()
        Hide()
        ShowForm(SaveMode.All, False)
#End If


    End Sub


    Private Sub MainForm_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles Me.FormClosing

        ShortcutKeySettingForm.UnregisterHotKey()

    End Sub


    Protected Overrides Sub WndProc(ByRef m As Message)

        MyBase.WndProc(m)

        If m.Msg = WM_HOTKEY Then

            ' ウィンドウのみ
            If m.LParam = ShortcutKeySettingForm.GetKeyValue(0) Or m.LParam = ShortcutKeySettingForm.GetKeyValue(1) Then ShowForm(SaveMode.WindowOnly, False)
            If m.LParam = ShortcutKeySettingForm.GetKeyValue(2) Then ShowForm(SaveMode.WindowOnly, True) ' 自動保存

            ' 全体
            If m.LParam = ShortcutKeySettingForm.GetKeyValue(3) Or m.LParam = ShortcutKeySettingForm.GetKeyValue(4) Then ShowForm(SaveMode.All, False)
            If m.LParam = ShortcutKeySettingForm.GetKeyValue(5) Then ShowForm(SaveMode.All, True) ' 自動保存

            ' クリップボード
            If m.LParam = ShortcutKeySettingForm.GetKeyValue(6) Or m.LParam = ShortcutKeySettingForm.GetKeyValue(7) Then ShowForm(SaveMode.Clipboard, False)
            If m.LParam = ShortcutKeySettingForm.GetKeyValue(8) Then ShowForm(SaveMode.Clipboard, True) ' 自動保存

            ' 書式削除
            If m.LParam = ShortcutKeySettingForm.GetKeyValue(9) Then
                On Error Resume Next
                Dim frm As New CleanClipboard
                frm.ShowDialog()
            End If

            ' パスオープン
            If m.LParam = ShortcutKeySettingForm.GetKeyValue(10) Or
                m.LParam = ShortcutKeySettingForm.GetKeyValue(11) Then
                On Error Resume Next
                'Dim frm As New PathOpen_MainForm
                'frm.ShowDialog()
                Dim p As New PathOpen2
                p.Exec(m.LParam = ShortcutKeySettingForm.GetKeyValue(11))
                p = Nothing
            End If

        End If

    End Sub

    Private Sub menuFileExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles mnuFileExit.Click

        Me.Close()
        End

    End Sub

    Private Sub menuFileOpenFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuFileOpenFolder.Click, menuFileOpenFolder2.Click

        If sender Is menuFileOpenFolder Then
            System.Diagnostics.Process.Start(g_sFolder)
        Else
            If (g_sLastFolder IsNot Nothing) AndAlso (g_sLastFolder <> "") Then
                System.Diagnostics.Process.Start(g_sLastFolder)
            Else
                System.Diagnostics.Process.Start(g_sFolder)
            End If
        End If

    End Sub

    Private Sub m_NotifyIcon_MouseDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles m_NotifyIcon.MouseDoubleClick

        menuFileOpenFolder_Click(Nothing, Nothing)

    End Sub

    Private Sub StartForm_PreviewKeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.PreviewKeyDownEventArgs) Handles Me.PreviewKeyDown

        ' Alt+F4対策
        If e.Alt Then
            e.IsInputKey = True
        End If

    End Sub

    Private Sub StartForm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        ' Alt+F4対策
        If e.Alt And e.KeyCode = Keys.F4 Then
            e.Handled = True
        End If

    End Sub

    ''' <summary>
    ''' スクリーンのキャプチャをファイルに保存する。
    ''' </summary>
    ''' <param name="sFilePath"></param>
    ''' <remarks></remarks>
    Private Sub SaveFile(ByVal sFilePath As String)

        ' 画面全体をコピーする
        Dim ScreenBmp As Bitmap = New Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height)
        Dim g As Graphics = Graphics.FromImage(ScreenBmp)
        g.CopyFromScreen(New Point(0, 0), New Point(0, 0), ScreenBmp.Size)
        g.Dispose()
        g = Nothing

        ' 拡張子をpngにする。
        If Not sFilePath.EndsWith(".png", StringComparison.OrdinalIgnoreCase) Then
            sFilePath += ".png"
        End If

        ' ファイルの存在をチェックする。
        If File.Exists(sFilePath) Then
            Dim nRc As Integer = MsgBox("指定されたファイルは既に存在します。" & vbCrLf & "上書きしますか？", vbExclamation Or MsgBoxStyle.OkCancel)
            If nRc <> MsgBoxResult.Ok Then
                Exit Sub
            End If
        End If

        Try
            ScreenBmp.Save(sFilePath)
            g_RecentFileList.Add(sFilePath)
        Catch
            MsgBox("エビデンスの保存に失敗しました。" & vbCrLf & "　ファイル : " & sFilePath, vbExclamation)
        End Try

    End Sub

    Private Sub mnuHelp_Click(sender As Object, e As EventArgs) Handles mnuHelp.Click

        If sender.Equals(mnuHelp) Then
            ShowHelp("SaveEvidence.mht")
        End If

    End Sub

    Private Sub リネームツールを起動ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles リネームツールを起動ToolStripMenuItem.Click
        Dim frm As New RenameForm
        frm.Show()
    End Sub

End Class
