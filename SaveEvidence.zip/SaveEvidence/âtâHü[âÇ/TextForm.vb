﻿Public Class TextForm

    Private Const TEXT_SPLIT = "[[SPLIT]]"
    Private Const TEXT_CRLF = "[[改行]]"
    Private Const MAX_NUM = 100

    Private Sub TextForm_Load(sender As Object, e As EventArgs) Handles Me.Load
        履歴読み込み()
    End Sub

    Public Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        AddText(txtText.Text, True)
        Save()
        DialogResult = DialogResult.OK
        Close()
    End Sub

    ' 履歴読み込み
    Public Sub 履歴読み込み()

        ' セルの内容に合わせて、行の高さが自動的に調節されるようにする
        gdvText.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells

        ' テキストを折り返して表示する
        gdvText.Columns(0).DefaultCellStyle.WrapMode = DataGridViewTriState.True

        ' Tabキーで次のコントロールに移動する
        gdvText.StandardTab = True

        ' 編集不可にする。
        gdvText.ReadOnly = True

        ' 行選択(常に選択)にする。
        gdvText.SelectionMode = DataGridViewSelectionMode.FullRowSelect


        ' 前回の文字列を読み込みグリッドビューに表示する。
        gdvText.Rows.Clear()
        Dim sText() As String = Split(My.Settings.テキスト履歴, TEXT_SPLIT, -1, CompareMethod.Binary)
        For i As Integer = LBound(sText) To UBound(sText)
            AddText(sText(i), False)
        Next

        Showテキスト履歴()

    End Sub

    ' キーダウンイベント処理
    Private Sub gdvText_KeyDown(sender As System.Object, e As System.Windows.Forms.KeyEventArgs) Handles gdvText.KeyDown

        ' 1行選択以外の場合は何もしない。
        If gdvText.SelectedRows.Count <> 1 Then
            Exit Sub
        End If

        ' 選択されたインデックスを取得する。
        Dim nIndex As Integer = gdvText.SelectedRows(0).Index

        Select Case e.KeyCode

            Case Keys.Delete

                ' Deleteキー処理：データを削除。
                If MsgBox("選択された文字列を削除しますか？", MsgBoxStyle.Exclamation Or MsgBoxStyle.YesNo) <> vbYes Then
                    Exit Sub
                End If
                gdvText.Rows.RemoveAt(nIndex)

            Case Keys.PageUp

                ' PageUpキー処理：データを上に移動。
                If nIndex > 0 Then
                    Dim sWk As String = gdvText.Rows(nIndex - 1).Cells(0).Value
                    gdvText.Rows(nIndex - 1).Cells(0).Value = gdvText.Rows(nIndex).Cells(0).Value
                    gdvText.Rows(nIndex).Cells(0).Value = sWk
                    gdvText.Rows(nIndex - 1).Selected = True
                End If
                e.Handled = True

            Case Keys.PageDown

                ' PageDownキー処理：データを下に移動。
                If nIndex < (gdvText.Rows.Count - 1) Then
                    Dim sWk As String = gdvText.Rows(nIndex + 1).Cells(0).Value
                    gdvText.Rows(nIndex + 1).Cells(0).Value = gdvText.Rows(nIndex).Cells(0).Value
                    gdvText.Rows(nIndex).Cells(0).Value = sWk
                    gdvText.Rows(nIndex + 1).Selected = True
                End If
                e.Handled = True

            Case Keys.Enter
                e.Handled = True
                btnOK_Click(Nothing, Nothing)
        End Select
    End Sub

    ' テキストを追加する。
    Public Sub AddText(ByVal sText As String, ByVal bTop As Boolean)

        ' とりあえずTrim。
        sText = sText.Trim()
        If sText = "" Then
            Exit Sub
        End If

        ' 改行を置換する。
        sText = sText.Replace(TEXT_CRLF, vbCrLf)

        ' 同じテキストがあれば削除する。
        For i As Integer = gdvText.Rows.Count - 1 To 0 Step -1
            If sText = gdvText.Rows(i).Cells(0).Value Then
                gdvText.Rows.RemoveAt(i)
            End If
        Next

        ' テキストを追加する。
        If bTop Then
            gdvText.Rows.Insert(0, sText)
            gdvText.Rows(0).Selected = True
        Else
            gdvText.Rows.Add(sText)
        End If

    End Sub


    Sub Save()
        ' グリッドビューに設定された文字列を保存する。
        Dim sText As String = ""
        Dim sWk As String = ""

        For i As Integer = 0 To (Math.Min(gdvText.Rows.Count, MAX_NUM) - 1)
            sWk = gdvText.Rows(i).Cells(0).Value
            sWk = sWk.Replace(vbCrLf, TEXT_CRLF)
            sText = sText & sWk & TEXT_SPLIT
        Next

        My.Settings.テキスト履歴 = sText
        My.Settings.Save()
    End Sub


    ' マウスダブルクリック処理(OKボタン押下と同等。)
    Private Sub gdvText_CellMouseDoubleClick(sender As System.Object, e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles gdvText.CellMouseDoubleClick

        If gdvText.SelectedRows.Count = 0 Then
            Exit Sub
        End If

        txtText.Text = gdvText.SelectedRows(0).Cells(0).Value()

        If (Control.ModifierKeys And Keys.Shift) = Keys.Shift Then
            btnOK_Click(Nothing, Nothing)
        End If

    End Sub

    Sub Showテキスト履歴()

        Me.Height = GetWindowRectEx(gdvText.Handle).Top - GetWindowRectEx(Handle).Top + 280
        gdvText.Visible = True

    End Sub

End Class