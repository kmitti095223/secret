﻿Module ExtendedMethod

    '''============================================================================================
    ''' <summary>
    ''' 2つの点の距離が近い場合Trueを返却する。
    ''' </summary>
    ''' <param name="p1"></param>
    ''' <param name="p2"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Function Match(ByVal p1 As Point, ByVal p2 As Point) As Boolean

        If Math.Abs(p1.X - p2.X) > 6 Then
            Return False
        End If
        If Math.Abs(p1.Y - p2.Y) > 6 Then
            Return False
        End If

        Return True

    End Function

    '''============================================================================================
    ''' <summary>
    ''' 2つの点により作られる矩形を返却する。
    ''' </summary>
    ''' <param name="p1"></param>
    ''' <param name="p2"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Function MakeRect(ByVal p1 As Point, ByVal p2 As Point) As Rectangle

        Return New Rectangle(Math.Min(p1.X, p2.X), Math.Min(p1.Y, p2.Y), _
                      Math.Abs(p1.X - p2.X), Math.Abs(p1.Y - p2.Y))

    End Function

    '''============================================================================================
    ''' <summary>
    ''' 矩形を点の位置まで拡張する。
    ''' </summary>
    ''' <param name="rect"></param>
    ''' <param name="pos"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    '''============================================================================================
     Public Function MakeRect(ByVal rect As Rectangle, ByVal pos As Point) As Rectangle

        Return New Rectangle(Math.Min(rect.Left, pos.X), Math.Min(rect.Top, pos.Y), _
                      Math.Max(Math.Abs(rect.Left - pos.X), Math.Abs(rect.Right - pos.X)), _
                      Math.Max(Math.Abs(rect.Top - pos.Y), Math.Abs(rect.Bottom - pos.Y)))


    End Function

    '''============================================================================================
    ''' <summary>
    ''' 矩形の左上の点を返却する。
    ''' </summary>
    ''' <param name="rect">矩形</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Function LeftTop(ByVal rect As Rectangle) As Point
        Return New Point(rect.Left, rect.Top)
    End Function

    '''============================================================================================
    ''' <summary>
    ''' 矩形の右上の点を返却する。
    ''' </summary>
    ''' <param name="rect">矩形</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Function RightTop(ByVal rect As Rectangle) As Point
        Return New Point(rect.Right, rect.Top)
    End Function

    '''============================================================================================
    ''' <summary>
    ''' 矩形の右下の点を返却する。
    ''' </summary>
    ''' <param name="rect">矩形</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Function RightBottom(ByVal rect As Rectangle) As Point
        Return New Point(rect.Right, rect.Bottom)
    End Function

    '''============================================================================================
    ''' <summary>
    ''' 矩形の左下の点を返却する。
    ''' </summary>
    ''' <param name="rect">矩形</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Function LeftBottom(ByVal rect As Rectangle) As Point
        Return New Point(rect.Left, rect.Bottom)
    End Function


    '''============================================================================================
    ''' <summary>
    ''' 2点の距離を返却する。
    ''' </summary>
    ''' <param name="pos1">点1</param>
    ''' <param name="pos2">点2</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Function Distance(ByVal pos1 As Point, ByVal pos2 As Point) As Double

        Return Math.Sqrt(Math.Pow(Math.Abs(pos1.X - pos2.X), 2) + _
                         Math.Pow(Math.Abs(pos1.Y - pos2.Y), 2))

    End Function

End Module
