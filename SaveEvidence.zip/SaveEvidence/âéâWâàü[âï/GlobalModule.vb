﻿Option Explicit On
Option Strict On

Imports System.Runtime.InteropServices
Imports System.IO

Module GlobalModule

    <DllImport("user32.dll")> _
    Public Function GetForegroundWindow() As IntPtr
    End Function


    <DllImport("user32.dll")> _
    Public Function GetWindowThreadProcessId(hWnd As IntPtr, _
   ByRef ProcessId As IntPtr) As UInteger
    End Function

    Public Function GetActiveWindow() As String

        Dim wnd As IntPtr = GetForegroundWindow()
        Dim id As IntPtr
        GetWindowThreadProcessId(wnd, id)
        Return Process.GetProcessById(id.ToInt32).ProcessName

    End Function

    Public Sub ShowHelp(ByVal sHelpFile As String)

        Dim myAssembly As System.Reflection.Assembly = System.Reflection.Assembly.GetExecutingAssembly()
        Dim stream As Stream = myAssembly.GetManifestResourceStream("SaveEvidence." & sHelpFile)
        Dim buf(Convert.ToInt32(stream.Length) - 1) As Byte
        stream.Read(buf, 0, Convert.ToInt32(stream.Length))
        File.WriteAllBytes(Application.StartupPath & "\" & sHelpFile, buf)
        Process.Start(Application.StartupPath & "\" & sHelpFile)

    End Sub

    <DllImport("shlwapi.dll", EntryPoint:="PathCompactPathExW", SetLastError:=True, CharSet:=CharSet.Unicode)>
    Public Function PathCompactPathEx(
                      <MarshalAs(UnmanagedType.LPTStr)> pszOut As System.Text.StringBuilder,
                      <MarshalAs(UnmanagedType.LPTStr)> pszSrc As String,
                      cchMax As UInteger,
                      reserved As Integer
                      ) As <MarshalAs(UnmanagedType.Bool)> Boolean

    End Function

    Public Function SetCompactPath(ByRef lbl As LinkLabel, ByVal str As String, ByVal nMinSize As Integer, ByVal nMaxSize As Integer) As Integer

        Dim g As Graphics = lbl.CreateGraphics

        'If g.MeasureString(str, lbl.Font).Width < lbl.ClientSize.Width Then
        '    lbl.Text = str
        '    Return 100
        'End If

        For i As Integer = str.Length + 2 To 1 Step -1
            Dim buf As New System.Text.StringBuilder(1024)
            PathCompactPathEx(buf, str, Convert.ToUInt32(i), 0)

            Dim nNeedSize = Convert.ToInt32(g.MeasureString(buf.ToString, lbl.Font).Width)
            If nNeedSize < nMaxSize Then
                lbl.Text = buf.ToString
                Return Math.Max(nNeedSize, nMinSize)
            End If

            'If g.MeasureString(buf.ToString, lbl.Font).Width < lbl.ClientSize.Width Then
            '    lbl.Text = buf.ToString
            '    Exit For
            'End If
        Next


        'Dim g As Graphics = lbl.CreateGraphics
        'Debug.Print(g.MeasureString("ABC", lbl.Font).Width.ToString)
        'Debug.Print(g.MeasureString("ab", lbl.Font).Width.ToString)

        'Dim tmp As String = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"

        'Dim i As Integer
        'For i = 1 To str.Length - 1
        '    Debug.Print(g.MeasureString(tmp.Substring(0, i), lbl.Font).Width.ToString)
        '    Debug.Print(lbl.Width.ToString)
        '    If g.MeasureString(tmp.Substring(0, i), lbl.Font).Width > lbl.Width Then
        '        Exit For
        '    End If
        'Next
        'If i >= str.Length Then
        '    lbl.Text = str
        '    Exit Sub
        'End If


        'Dim buf As New System.Text.StringBuilder(1024)
        'buf.Append(str)

        'Dim strbWork As New System.Text.StringBuilder(128)

        'PathCompactPathEx(buf, str, Convert.ToUInt32(i), 0)
        'lbl.Text = buf.ToString

        Return nMinSize
    End Function

End Module
