﻿Option Explicit On
Option Strict On

Imports System.Runtime.InteropServices
Imports System.IO
Imports System.Text

Module GlobalModule


    <DllImport("user32.dll")>
    Public Function GetWindowThreadProcessId(hWnd As IntPtr,
   ByRef ProcessId As IntPtr) As UInteger
    End Function

    <DllImport("user32.dll")>
    Public Function EnumWindows(lpEnumFunc As EnumWindowsProc, lParam As IntPtr) As Boolean
    End Function
    Public Delegate Function EnumWindowsProc(hWnd As IntPtr, lParam As IntPtr) As Boolean

    <DllImport("user32.dll")>
    Public Function GetWindowText(hWnd As IntPtr, lpString As StringBuilder, nMaxCount As Integer) As Integer
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto)>
    Public Sub keybd_event(bVk As Byte, bScan As Byte, dwFlags As UInteger, dwExtraInfo As IntPtr)
    End Sub

    <DllImport("user32.dll")>
    Public Function SetForegroundWindow(hWnd As IntPtr) As Boolean
    End Function

    Public Const VK_PAGEUP As Byte = &H21        ' Page Up
    Public Const VK_PAGEDOWN As Byte = &H22 ' Page Down
    Public Const VK_END As Byte = &H23     ' End
    Public Const VK_HOME As Byte = &H24         ' Home


    <StructLayout(LayoutKind.Sequential)>
    Public Structure RECT
        Public left As Integer
        Public top As Integer
        Public right As Integer
        Public bottom As Integer
    End Structure

    <DllImport("user32.dll")>
    Public Function GetForegroundWindow() As IntPtr
    End Function

    <DllImport("user32.dll")>
    Public Function GetWindowRect(ByVal hwnd As IntPtr,
    ByRef lpRect As RECT) As Integer
    End Function

    <DllImport("dwmapi.dll", EntryPoint:="DwmGetWindowAttribute")>
    Public Function DwmGetWindowAttribute(ByVal hwnd As IntPtr,
                                           ByVal dwAttribute As Integer,
                                           ByRef lpRect As RECT,
                                           ByVal cbAttribute As Integer) As Integer
    End Function


    Public Function GetActiveWindow() As String

        Dim wnd As IntPtr = GetForegroundWindow()
        Dim id As IntPtr
        GetWindowThreadProcessId(wnd, id)
        Return Process.GetProcessById(id.ToInt32).ProcessName

    End Function


    Public Sub ShowHelp(ByVal sHelpFile As String)

        Dim myAssembly As System.Reflection.Assembly = System.Reflection.Assembly.GetExecutingAssembly()
        Dim stream As Stream = myAssembly.GetManifestResourceStream("SaveEvidence." & sHelpFile)
        Dim buf(Convert.ToInt32(stream.Length) - 1) As Byte
        stream.Read(buf, 0, Convert.ToInt32(stream.Length))
        File.WriteAllBytes(Application.StartupPath & "\" & sHelpFile, buf)
        Process.Start(Application.StartupPath & "\" & sHelpFile)

    End Sub

    <DllImport("shlwapi.dll", EntryPoint:="PathCompactPathExW", SetLastError:=True, CharSet:=CharSet.Unicode)>
    Public Function PathCompactPathEx(
                      <MarshalAs(UnmanagedType.LPTStr)> pszOut As System.Text.StringBuilder,
                      <MarshalAs(UnmanagedType.LPTStr)> pszSrc As String,
                      cchMax As UInteger,
                      reserved As Integer
                      ) As <MarshalAs(UnmanagedType.Bool)> Boolean

    End Function

    Public Function SetCompactPath(ByRef lbl As LinkLabel, ByVal str As String, ByVal nMinSize As Integer, ByVal nMaxSize As Integer) As Integer

        Dim g As Graphics = lbl.CreateGraphics

        'If g.MeasureString(str, lbl.Font).Width < lbl.ClientSize.Width Then
        '    lbl.Text = str
        '    Return 100
        'End If

        For i As Integer = str.Length + 2 To 1 Step -1
            Dim buf As New System.Text.StringBuilder(1024)
            PathCompactPathEx(buf, str, Convert.ToUInt32(i), 0)

            Dim nNeedSize = Convert.ToInt32(g.MeasureString(buf.ToString, lbl.Font).Width)
            If nNeedSize < nMaxSize Then
                lbl.Text = buf.ToString
                Return Math.Max(nNeedSize, nMinSize)
            End If

            'If g.MeasureString(buf.ToString, lbl.Font).Width < lbl.ClientSize.Width Then
            '    lbl.Text = buf.ToString
            '    Exit For
            'End If
        Next
        Return nMinSize
    End Function

    ''' <summary>
    ''' 接続されているすべてのモニターの中で、最も大きい高さを取得する関数
    ''' </summary>
    ''' <returns>最も大きい高さ (ピクセル単位)</returns>
    Public Function GetMaxScreenHeight() As Integer
        ' 最大高さを保持する変数
        Dim maxHeight As Integer = 0

        ' すべてのスクリーンをループして高さを比較
        For Each screen As Screen In Screen.AllScreens
            Dim screenHeight As Integer = screen.Bounds.Height
            If screenHeight > maxHeight Then
                maxHeight = screenHeight
            End If
        Next

        ' 最大の高さを返す
        Return maxHeight
    End Function

    Function GetAdjacentFile(currentFilePath As String, offset As Integer) As String
        ' ファイルのフォルダを取得
        Dim folderPath As String = Path.GetDirectoryName(currentFilePath)
        If String.IsNullOrEmpty(folderPath) Then Return Nothing

        ' 指定のフォルダ内のすべてのファイルを取得
        Dim files As String() = Directory.GetFiles(folderPath)

        ' 現在のファイルをリスト内で検索
        Dim currentFileIndex As Integer = Array.IndexOf(files, currentFilePath)

        ' 現在のファイルが見つからない場合、または無効なインデックスの場合は終了
        If currentFileIndex < 0 Then Return Nothing

        ' 前または次のファイルのインデックスを計算
        Dim adjacentFileIndex As Integer = currentFileIndex + offset

        ' 有効なインデックス範囲内であればファイルのフルパスを返却、それ以外はNothing
        If adjacentFileIndex >= 0 AndAlso adjacentFileIndex < files.Length Then
            Return files(adjacentFileIndex)
        Else
            Return currentFilePath
        End If
    End Function

End Module
