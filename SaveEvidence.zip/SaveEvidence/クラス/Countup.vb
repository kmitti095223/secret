﻿Public Class Countup

    Public Enum eMode
        modeNone = 1
        modeCtrl = 2        ' Ctrl押下
        modeCtrlShift = 3   ' Ctrl+Shift押下
    End Enum

    ''' ===========================================================================================
    ''' <summary>
    ''' カウントアップ処理
    ''' </summary>
    ''' <param name="sSrc">入力文字列</param>
    ''' <param name="bUp">Up or Down</param>
    ''' <param name="nMode">動作モード</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ''' ===========================================================================================
    Shared Function Count(ByVal sSrc As String, ByVal bUp As Boolean, Optional ByVal nMode As eMode = eMode.modeNone) As String
        On Error GoTo FUNC_END

        ' 数字とその他に分けて配列に格納する。
        Dim lstResult As List(Of String) = SplitNulAndOthers(sSrc)
        If lstResult.Count = 0 Then
            Return sSrc
        End If

        ' カウントアップ対象の配列要素のインデックス1
        Dim nTarget1 As Integer = -1

        ' カウントアップ対象の配列要素のインデックス2(Ctrl押下時用)
        Dim nTarget2 As Integer = -1

        ' カウントアップ対象の配列要素のインデックス2(Ctrl+Shift押下時用)
        Dim nTarget3 As Integer = -1

        ' カウントアップ対象の配列要素のインデックス1を決定する。
        ' 　右端が数字の場合、それがカウントアップ対象。
        ' 　そうでない場合、2番目がカウントアップ対象
        If IsNumber(lstResult(lstResult.Count - 1)) Then
            nTarget1 = lstResult.Count - 1
        Else
            nTarget1 = lstResult.Count - 2
            ' 例えば対象データが｢a｣の場合、
            ' 配列要素数は1で、nTarget1は-1(対象無し)となる。
        End If

        ' カウントアップ対象の配列要素のインデックス2を決定する。
        '   カウントアップ対象の配列要素のインデックス1が-1(対象無し)の場合、
        '   カウントアップ対象の配列要素のインデックス2も-1(対象無し)。
        If nTarget1 > 0 Then
            ' nTarget2はnTarget1の2つ前の要素(1つ前は数字でないため）、
            ' または、対象無し。
            If (nTarget1 - 2) >= 0 Then
                nTarget2 = nTarget1 - 2
            End If
        End If


        ' カウントアップ対象の配列要素のインデックス2を決定する。
        '   カウントアップ対象の配列要素のインデックス1が-1(対象無し)の場合、
        '   カウントアップ対象の配列要素のインデックス2も-1(対象無し)。
        If (nTarget1 > 0) And (nTarget2 > 0) Then
            ' nTarget2はnTarget1の2つ前の要素(1つ前は数字でないため）、
            ' または、対象無し。
            If (nTarget2 - 2) >= 0 Then
                nTarget3 = nTarget2 - 2
            End If
        End If

        ' カウントアップ対象の配列要素のインデックス1が
        ' -1(対象無し)の場合、カウントアップしようがないので終了。
        If nTarget1 < 0 Then
            Return sSrc
        End If

        ' Ctrlが押されていて、カウントアップ対象の配列要素のインデックス2が
        ' -1(対象無し)の場合、カウントアップしようがないので終了。
        If (nMode >= 2) And (nTarget2 < 0) Then
            Return sSrc
        End If

        ' Ctrl+Shiftが押されていて、カウントアップ対象の配列要素のインデックス3が
        ' -1(対象無し)の場合、カウントアップしようがないので終了。
        If (nMode >= 3) And (nTarget3 < 0) Then
            Return sSrc
        End If

        ' カウントアップ実行
        If nMode = eMode.modeNone Then
            ' Ctrlが押されていない場合、nTarget1の要素をカウントアップする。
            lstResult(nTarget1) = Up(lstResult(nTarget1), bUp)
        ElseIf nMode = eMode.modeCtrl Then
            ' Ctrlが押されている場合、nTarget2の要素をカウントアップし、
            ' nTarget1の要素は1にする。
            lstResult(nTarget2) = Up(lstResult(nTarget2), bUp)
            lstResult(nTarget1) = (1).ToString("D" & lstResult(nTarget1).Length)
        Else
            ' Ctrl+Shiftが押されている場合、nTarget3の要素をカウントアップし、
            ' nTarget1、nTarget2の要素は1にする。
            lstResult(nTarget3) = Up(lstResult(nTarget3), bUp)
            lstResult(nTarget2) = (1).ToString("D" & lstResult(nTarget2).Length)
            lstResult(nTarget1) = (1).ToString("D" & lstResult(nTarget1).Length)
        End If

        ' 返却する文字列を作成する。
        sSrc = ""
        For Each s As String In lstResult
            sSrc += s
        Next

FUNC_END:
        Return sSrc
    End Function

    ''' ===========================================================================================
    ''' <summary>
    ''' 文字列を数値とその他に分割し、配列に格納する。
    ''' </summary>
    ''' <param name="sSrc"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ''' ===========================================================================================
    Shared Function SplitNulAndOthers(ByVal sSrc As String) As List(Of String)

        Dim lstResult As List(Of String) = Nothing
        Dim bNumber As Boolean = False

        For i = (sSrc.Length - 1) To 0 Step -1

            Dim sWk As String = sSrc.Substring(i, 1)
            Dim bNumberWk As Boolean = IsNumber(sWk)
            If lstResult Is Nothing Then
                lstResult = New List(Of String)
                lstResult.Add("")
            ElseIf (bNumber <> bNumberWk) Then
                lstResult.Add("")
            End If
            lstResult(lstResult.Count - 1) = (sWk & lstResult(lstResult.Count - 1))
            bNumber = bNumberWk
        Next

        ' データ無しの場合、サイズ0の配列を作成して返却する。
        If lstResult Is Nothing Then
            Return New List(Of String)
        End If

        lstResult.Reverse()
        Return lstResult

    End Function

    ''' ===========================================================================================
    ''' <summary>
    ''' 指定された文字列が数字か判定
    ''' </summary>
    ''' <param name="s"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ''' ===========================================================================================
    Public Shared Function IsNumber(ByVal s As String) As Boolean

        For Each c As Char In s
            If c < "0"c OrElse "9"c < c Then
                Return False
            End If
        Next
        Return True

    End Function

    ''' ===========================================================================================
    ''' <summary>
    ''' 数値のカウントアップ/カウントダウン処理
    ''' </summary>
    ''' <param name="sText"></param>
    ''' <param name="bUp"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ''' ===========================================================================================
    Public Shared Function Up(ByVal sText As String, ByVal bUp As Boolean) As String
        Dim nNumber As Int64
        nNumber = Convert.ToInt64(sText)
        If (nNumber <> 0) Or bUp Then ' 0の場合は減らさない。
            nNumber += If(bUp, 1, -1)
            nNumber = Math.Max(nNumber, 1)
        End If
        Return nNumber.ToString("D" & sText.Length)
    End Function

    ''' ===========================================================================================
    ''' <summary>
    ''' Countメソッドのテスト処理
    ''' </summary>
    ''' <remarks>エクセルシートより作成</remarks>
    ''' ===========================================================================================
    Public Shared Sub CountTest()

        CountTest("", True, 1, "") : CountTest("", False, 1, "") : CountTest("", True, 2, "") : CountTest("", False, 2, "")
        CountTest("a", True, 1, "a") : CountTest("a", False, 1, "a") : CountTest("a", True, 2, "a") : CountTest("a", False, 2, "a")
        CountTest("0", True, 1, "1") : CountTest("0", False, 1, "0") : CountTest("0", True, 2, "0") : CountTest("0", False, 2, "0")
        CountTest("1", True, 1, "2") : CountTest("1", False, 1, "1") : CountTest("1", True, 2, "1") : CountTest("1", False, 2, "1")
        CountTest("00", True, 1, "01") : CountTest("00", False, 1, "00") : CountTest("00", True, 2, "00") : CountTest("00", False, 2, "00")
        CountTest("1a", True, 1, "2a") : CountTest("1a", False, 1, "1a") : CountTest("1a", True, 2, "1a") : CountTest("1a", False, 2, "1a")
        CountTest("10a", True, 1, "11a") : CountTest("10a", False, 1, "09a") : CountTest("10a", True, 2, "10a") : CountTest("10a", False, 2, "10a")
        CountTest("a1", True, 1, "a2") : CountTest("a1", False, 1, "a1") : CountTest("a1", True, 2, "a1") : CountTest("a1", False, 2, "a1")
        CountTest("a10", True, 1, "a11") : CountTest("a10", False, 1, "a09") : CountTest("a10", True, 2, "a10") : CountTest("a10", False, 2, "a10")
        CountTest("0-1", True, 1, "0-2") : CountTest("0-1", False, 1, "0-1") : CountTest("0-1", True, 2, "1-1") : CountTest("0-1", False, 2, "0-1")
        CountTest("1-0", True, 1, "1-1") : CountTest("1-0", False, 1, "1-0") : CountTest("1-0", True, 2, "2-1") : CountTest("1-0", False, 2, "1-1")
        CountTest("1-1", True, 1, "1-2") : CountTest("1-1", False, 1, "1-1") : CountTest("1-1", True, 2, "2-1") : CountTest("1-1", False, 2, "1-1")
        CountTest("1-2", True, 1, "1-3") : CountTest("1-2", False, 1, "1-1") : CountTest("1-2", True, 2, "2-1") : CountTest("1-2", False, 2, "1-1")
        CountTest("2-1", True, 1, "2-2") : CountTest("2-1", False, 1, "2-1") : CountTest("2-1", True, 2, "3-1") : CountTest("2-1", False, 2, "1-1")
        CountTest("2-2", True, 1, "2-3") : CountTest("2-2", False, 1, "2-1") : CountTest("2-2", True, 2, "3-1") : CountTest("2-2", False, 2, "1-1")
        CountTest("1-1あ", True, 1, "1-2あ") : CountTest("1-1あ", False, 1, "1-1あ") : CountTest("1-1あ", True, 2, "2-1あ") : CountTest("1-1あ", False, 2, "1-1あ")
        CountTest("1-2あ", True, 1, "1-3あ") : CountTest("1-2あ", False, 1, "1-1あ") : CountTest("1-2あ", True, 2, "2-1あ") : CountTest("1-2あ", False, 2, "1-1あ")
        CountTest("2-1あ", True, 1, "2-2あ") : CountTest("2-1あ", False, 1, "2-1あ") : CountTest("2-1あ", True, 2, "3-1あ") : CountTest("2-1あ", False, 2, "1-1あ")
        CountTest("2-2あ", True, 1, "2-3あ") : CountTest("2-2あ", False, 1, "2-1あ") : CountTest("2-2あ", True, 2, "3-1あ") : CountTest("2-2あ", False, 2, "1-1あ")
        CountTest("あ1-1", True, 1, "あ1-2") : CountTest("あ1-1", False, 1, "あ1-1") : CountTest("あ1-1", True, 2, "あ2-1") : CountTest("あ1-1", False, 2, "あ1-1")
        CountTest("あ1-2", True, 1, "あ1-3") : CountTest("あ1-2", False, 1, "あ1-1") : CountTest("あ1-2", True, 2, "あ2-1") : CountTest("あ1-2", False, 2, "あ1-1")
        CountTest("あ2-1", True, 1, "あ2-2") : CountTest("あ2-1", False, 1, "あ2-1") : CountTest("あ2-1", True, 2, "あ3-1") : CountTest("あ2-1", False, 2, "あ1-1")
        CountTest("2-2あ", True, 1, "2-3あ") : CountTest("2-2あ", False, 1, "2-1あ") : CountTest("2-2あ", True, 2, "3-1あ") : CountTest("2-2あ", False, 2, "1-1あ")
        CountTest("02\02", True, 1, "02\03") : CountTest("02\02", False, 1, "02\01") : CountTest("02\02", True, 2, "03\01") : CountTest("02\02", False, 2, "01\01")
        CountTest("99-99", True, 1, "99-100") : CountTest("99-99", False, 1, "99-98") : CountTest("99-99", True, 2, "100-01") : CountTest("99-99", False, 2, "98-01")
        CountTest("99-100", True, 1, "99-101") : CountTest("99-100", False, 1, "99-099") : CountTest("99-100", True, 2, "100-001") : CountTest("99-100", False, 2, "98-001")
        CountTest("100-99", True, 1, "100-100") : CountTest("100-99", False, 1, "100-98") : CountTest("100-99", True, 2, "101-01") : CountTest("100-99", False, 2, "099-01")
        CountTest("100-100", True, 1, "100-101") : CountTest("100-100", False, 1, "100-099") : CountTest("100-100", True, 2, "101-001") : CountTest("100-100", False, 2, "099-001")
        CountTest("100\100", True, 1, "100\101") : CountTest("100\100", False, 1, "100\099") : CountTest("100\100", True, 2, "101\001") : CountTest("100\100", False, 2, "099\001")
        CountTest("2345678901234567890-2345678901234567890", True, 1, "2345678901234567890-2345678901234567891") : CountTest("2345678901234567890-2345678901234567890", False, 1, "2345678901234567890-2345678901234567889") : CountTest("2345678901234567890-2345678901234567890", True, 2, "2345678901234567891-0000000000000000001") : CountTest("2345678901234567890-2345678901234567890", False, 2, "2345678901234567889-0000000000000000001")

    End Sub

    ''' ===========================================================================================
    ''' <summary>
    ''' CountTestメソッドのサブ処理
    ''' </summary>
    ''' <param name="sSrc"></param>
    ''' <param name="bUp"></param>
    ''' <param name="nMode"></param>
    ''' <param name="sCorrect"></param>
    ''' <remarks></remarks>
    ''' ===========================================================================================
    Shared Sub CountTest(ByVal sSrc As String, ByVal bUp As Boolean, ByVal nMode As eMode, ByVal sCorrect As String)
        Dim sResult As String = Count(sSrc, bUp, nMode)
        Debug.Print(" bUp=" & If(bUp, "True ", "False") & _
                    ", bCtrl=" & If(nMode = eMode.modeNone, "True ", "False") & vbTab & _
                    """" & sSrc & """ → """ & sResult & """ 正解=""" & sCorrect & """")
        Debug.Assert(sResult = sCorrect)
    End Sub

    ''' ===========================================================================================
    ''' <summary>
    ''' SplitNulAndOthersメソッドのテスト
    ''' </summary>
    ''' <param name="sSrc"></param>
    ''' <param name="sCorrect"></param>
    ''' <remarks></remarks>
    ''' ===========================================================================================
    Shared Sub SplitNulAndOthers_Test(ByVal sSrc As String, ByVal sCorrect As String)

        Dim lstResult As List(Of String) = SplitNulAndOthers(sSrc)
        Dim sResult As String = ""

        For Each s As String In lstResult
            sResult += (s & ",")
        Next
        If sResult <> "" Then
            sResult = sResult.Substring(0, sResult.Length - 1)
        End If
        Debug.Assert(sResult = sCorrect)

    End Sub


End Class
