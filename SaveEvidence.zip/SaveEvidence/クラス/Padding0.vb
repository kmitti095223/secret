﻿Public Class Padding0

    Public Shared Function Padding0(ByVal sText As String) As String

        Dim sResult As String = ""
        Dim arrText As New ArrayList

        For i As Integer = 0 To sText.Length - 1
            arrText.Add(sText.Substring(i, 1))
        Next

        ' 数字部分をまとめる
        For i As Integer = 0 To arrText.Count - 2

            If (i >= arrText.Count - 1) Then
                Continue For
            End If

            If Not IsNumber(arrText(i)) Then
                Continue For
            End If

            If IsNumber(arrText(i + 1)) Then
                arrText(i) = arrText(i) + arrText(i + 1)
                arrText.RemoveAt(i + 1)
            End If
        Next

        For i As Integer = 0 To arrText.Count - 1

            If Not IsNumber(arrText(i)) Then
                Continue For
            End If

            If (i <> 0) AndAlso
               Not IsSeparator(arrText(i - 1).ToString.Substring(arrText(i - 1).ToString.Length - 1, 1)) Then
                Continue For
            End If

            If Not (i = (arrText.Count - 1)) AndAlso
                 Not IsSeparator(arrText(i + 1).ToString.Substring(0, 1)) Then
                Continue For
            End If

            If arrText(i).ToString.Length = 1 Then
                arrText(i) = "0" & arrText(i)
            End If

        Next

        sResult = ""
        For i As Integer = 0 To arrText.Count - 1
            sResult = sResult & arrText(i)
        Next

        Return sResult

    End Function

    Public Shared Function IsNumber(ByVal s As String) As Boolean

        For Each c As Char In s
            If c < "0"c OrElse "9"c < c Then
                Return False
            End If
        Next
        Return True

    End Function

    Public Shared Function IsSeparator(ByVal s As String) As Boolean

        Return ("-_.+-=@()[]<>\".IndexOf(s) >= 0)
        
    End Function

    Public Shared Sub Test()

        Debug.Assert(Padding0("Win10-ST-1") = "Win10-ST-01")

        Debug.Assert(Padding0("1") = "01")
        Debug.Assert(Padding0("01") = "01")
        Debug.Assert(Padding0("a") = "a")
        Debug.Assert(Padding0("1a") = "1a")
        Debug.Assert(Padding0("1a-2") = "1a-02")
        Debug.Assert(Padding0("1-") = "01-")
        Debug.Assert(Padding0("-1") = "-01")
        Debug.Assert(Padding0("1ab2c") = "1ab2c")
        Debug.Assert(Padding0("1-1") = "01-01")
        Debug.Assert(Padding0("1_1_1") = "01_01_01")
        Debug.Assert(Padding0("-1-") = "-01-")

        '   End

    End Sub

End Class
