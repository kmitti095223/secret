﻿Public Class RecentItemMap

    ' セパレータ
    Public Shared SEPARATOR_1 As String = "[■]"
    Public Shared SEPARATOR_2 As String = "[■■]"

    ' アイテムの最大数
    Public Shared MAX_COUNT As Integer = 30

    ' 1アイテム分のクラス
    Private Class TextItem
        Public m_sFileName As String = ""   ' ファイル名
        Public m_sItemText As String = ""   ' テキスト
    End Class

    ' アイテムの配列
    Private m_arrTextItem As New List(Of TextItem)

    ' 複数アイテムをまとめたテキストを分割し、
    ' クラスメンバの配列に格納する。
    Public Sub SetMultiItem(ByVal sMultiItem As String)

        Try
            m_arrTextItem = New List(Of TextItem)

            ' セパレータで1アイテムごとに分割する。
            Dim sTextItem() As String = Split(sMultiItem, SEPARATOR_2)

            ' アイテム数分ループする。
            For i As Integer = 0 To sTextItem.Length - 1

                ' ファイル名とテキストに分割する。
                Dim sTmp() As String = Split(sTextItem(i), SEPARATOR_1)
                If sTmp.Length <> 2 Then
                    Continue For
                End If

                ' 配列の末尾に追加する。
                AddItem(sTmp(0), sTmp(1), False)
            Next

            ' デバッグ用ダンプ処理
            Dump()

        Catch ex As Exception
            m_arrTextItem = New List(Of TextItem)
        End Try

    End Sub

    ' 複数アイテムをまとめたテキストを作成して返却する。
    Public Function GetMultiItem() As String

        GetMultiItem = ""

        For i As Integer = 0 To m_arrTextItem.Count - 1
            GetMultiItem += (m_arrTextItem(i).m_sFileName & SEPARATOR_1 & m_arrTextItem(i).m_sItemText)

            If i <> (m_arrTextItem.Count - 1) Then
                GetMultiItem += SEPARATOR_2
            End If
        Next

    End Function

    ' 1つのアイテムを追加する。
    Public Sub AddItem(ByVal sFileName As String, ByVal sItemText As String, Optional bAddTop As Boolean = True)

        ' とりあえずトリム。
        sFileName = sFileName.Trim
        sItemText = sItemText.Trim()

        ' 文字列が空の場合は終了する。
        If (sFileName = "") Or (sItemText = "") Then
            Exit Sub
        End If


        ' 配列に同じファイル名がある場合は削除する。
        For i As Integer = m_arrTextItem.Count - 1 To 0 Step -1
            If String.Compare(sFileName, m_arrTextItem(i).m_sFileName, True) = 0 Then
                m_arrTextItem.RemoveAt(i)
            End If
        Next

        ' 配列に追加する。
        Dim item As New TextItem
        item.m_sFileName = sFileName
        item.m_sItemText = sItemText
        If bAddTop Then
            m_arrTextItem.Insert(0, item)
        Else
            m_arrTextItem.Add(item)
        End If

        ' 配列の要素数が上限を超える場合は削除する。
        For i As Integer = m_arrTextItem.Count - 1 To MAX_COUNT Step -1
            m_arrTextItem.RemoveAt(i)
        Next

    End Sub

    ' ファイル名に対応するテキストを取得する。
    Public Function GetItem(ByVal sFileName As String) As String

        For i As Integer = 0 To m_arrTextItem.Count - 1
            If String.Compare(sFileName, m_arrTextItem(i).m_sFileName, True) = 0 Then
                Return m_arrTextItem(i).m_sItemText
            End If
        Next
        Return ""

    End Function

    ' ファイル名に対応するテキストの有無を取得する。
    Public Function IsItemExist(ByVal sFileName As String) As Boolean

        Return (GetItem(sFileName) <> "")

    End Function

    ' ダンプ処理(デバッグ用)
    Public Sub Dump()

        Debug.Print("---- Dump ----")
        For i As Integer = 0 To m_arrTextItem.Count - 1
            Debug.Print(i.ToString("d4") & " " & m_arrTextItem(i).m_sFileName & " " & m_arrTextItem(i).m_sItemText)
        Next

    End Sub


End Class
