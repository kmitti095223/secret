﻿Option Explicit On

Imports System.Drawing.Drawing2D

Public Class TrackerItem

    Private m_Rect As Rectangle
    Private m_ArrowPos As Point
    Private m_bLine As Boolean

    Private m_DragCurPos As CursorPos
    Private m_DragStartPos As Point
    Private m_DragStartRect As Rectangle
    Private m_DragStartArrowPos As Point
    Private m_DragStartRectTotal As Rectangle

    Private m_ImageSize As Size
    Private m_sText As String = ""
    Private m_TextPoint As New Point(0, 0)

    Enum eType
        Rect
        Text
    End Enum
    Private m_Type As eType = eType.Rect

    Enum CursorPos
        LeftTop
        RightTop
        RightBottom
        LeftBottom
        Left
        Top
        Right
        Bottom
        Inside
        OutSide
        ArrowPos
    End Enum

    Public Sub New()
        m_DragCurPos = CursorPos.OutSide
        m_DragStartPos = New Point(0, 0)
        m_ImageSize = New Size(10000, 10000)
    End Sub

    '''============================================================================================
    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="pos">マウスクリック位置</param>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Sub New(ByVal pos As Point, ByVal ImageSize As Size, ByVal Mode As Boolean)
        Me.New()

        m_Rect = New Rectangle(pos.X, pos.Y, 1, 1)
        m_DragStartPos = pos
        m_ImageSize = ImageSize
        m_bLine = Not Mode

    End Sub

    '''============================================================================================
    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="sText">マウス矩形を文字列化したテキスト</param>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Sub New(ByVal sText As String)
        Me.New()

        Dim arrText() As String = sText.Split(",")
        m_Rect = New Rectangle(Convert.ToInt32(arrText(0)), _
                               Convert.ToInt32(arrText(1)), _
                               Convert.ToInt32(arrText(2)), _
                               Convert.ToInt32(arrText(3)))
        m_ArrowPos = New Point(Convert.ToInt32(arrText(4)), _
                               Convert.ToInt32(arrText(5)))

        m_sText = arrText(6)
        For i As Integer = 7 To UBound(arrText)
            m_sText += ("," & arrText(i))
        Next

        m_bLine = False

    End Sub

    '''============================================================================================
    ''' <summary>
    ''' トラッカーの種類を取得する。
    ''' </summary>
    ''' <returns>True:テキスト, FalseE:四角</returns>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Function IsText() As Boolean
        Return m_sText <> ""
    End Function

    '''============================================================================================
    ''' <summary>
    ''' イメージサイズ設定
    ''' </summary>
    ''' <param name="ImageSize">イメージサイズ</param>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Sub SetImageSize(ByVal ImageSize As Size)
        m_ImageSize = ImageSize
    End Sub

    '''============================================================================================
    ''' <summary>
    ''' 矩形設定
    ''' </summary>
    ''' <param name="rect">矩形</param>
    ''' <param name="bHosei">補正有無</param>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Sub SetRect(ByVal rect As Rectangle, ByVal bHosei As Boolean)

        ' 矩形移動により矢印が表示されないようにするための処理
        'Dim bShowAllow = (m_ArrowPos <> LeftTop(m_Rect))

        m_Rect = rect
        If Not bHosei Then
            Exit Sub
        End If

        m_Rect.Width = Math.Max(m_Rect.Width, 5)
        m_Rect.Height = Math.Max(m_Rect.Height, 5)

        ' 右下にはみ出した場合は補正する。
        If m_Rect.Right >= m_ImageSize.Width Then
            m_Rect.Offset(-(m_Rect.Right - m_ImageSize.Width + 1), 0)
        End If
        If m_Rect.Bottom >= m_ImageSize.Height Then
            m_Rect.Offset(0, -(m_Rect.Bottom - m_ImageSize.Height + 1))
        End If

        ' 元々矢印が表示されていない場合、矢印位置を更新することで、
        ' 矢印が表示されなくする。
        'm_ArrowPos = LeftTop(m_Rect)

        テキスト枠サイズ補正()

    End Sub

    '''============================================================================================
    ''' <summary>
    ''' 矩形取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Function GetRect() As Rectangle
        Return m_Rect
    End Function

    '''============================================================================================
    ''' <summary>
    ''' テキスト設定
    ''' </summary>
    ''' <param name="sText">テキスト</param>
    '''============================================================================================
    Public Sub SetText(ByVal sText As String)
        m_sText = sText

        テキスト枠サイズ補正()

    End Sub

    '''============================================================================================
    ''' <summary>
    ''' テキスト取得
    ''' </summary>
    ''' <returns>テキスト</returns>
    '''============================================================================================
    Public Function GetText() As String
        Return m_sText
    End Function

    '''============================================================================================
    ''' <summary>
    ''' ドラッグ開始
    ''' </summary>
    '''============================================================================================
    Public Function DragStart(ByVal pos As Point) As Boolean

        m_DragCurPos = GetCursorPos(pos)
        Select Case m_DragCurPos

            Case CursorPos.LeftTop, CursorPos.RightTop, CursorPos.RightBottom, CursorPos.LeftBottom, _
                CursorPos.Left, CursorPos.Top, CursorPos.Right, CursorPos.Bottom
                ' リサイズ
                m_DragStartRect = m_Rect

            Case CursorPos.Inside
                ' 矩形移動
                m_DragStartPos = pos
                m_DragStartRect = m_Rect
                If Not IsText() Then
                    m_ArrowPos = LeftTop(m_Rect)
                End If
                m_DragStartArrowPos = m_ArrowPos
                m_DragStartRectTotal = MakeRect(m_Rect, m_ArrowPos)

            Case CursorPos.ArrowPos
                ' 矢印の先を移動
                m_DragStartPos = pos
                m_DragStartArrowPos = m_ArrowPos

            Case Else
                ' その他は何もしない
                Return False

        End Select

        Return True

    End Function

    '''============================================================================================
    ''' <summary>
    ''' ドラッグ移動処理
    ''' </summary>
    ''' <param name="pos"></param>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Sub DragMove(ByVal pos As Point)

        Dim rect As Rectangle = Nothing

        Select Case m_DragCurPos

            Case CursorPos.LeftTop
                ' 左上 ⇒ リサイズ
                rect = MakeRect(pos, RightBottom(m_DragStartRect))
            Case CursorPos.RightTop
                ' 右上 ⇒ リサイズ
                rect = MakeRect(pos, LeftBottom(m_DragStartRect))
            Case CursorPos.RightBottom
                ' 右下 ⇒ リサイズ
                rect = MakeRect(pos, LeftTop(m_DragStartRect))
            Case CursorPos.LeftBottom
                ' 左下 ⇒ リサイズ
                rect = MakeRect(pos, RightTop(m_DragStartRect))

            Case CursorPos.Left
                ' 左 ⇒ リサイズ
                rect = New Rectangle(Math.Min(m_DragStartRect.Right, pos.X), _
                                     m_DragStartRect.Top, _
                                     Math.Max(m_DragStartRect.Right - pos.X, pos.X - m_DragStartRect.Right), _
                                     m_DragStartRect.Height)
            Case CursorPos.Top
                ' 上 ⇒ リサイズ
                rect = New Rectangle(m_DragStartRect.Left, _
                                     Math.Min(m_DragStartRect.Bottom, pos.Y), _
                                     m_DragStartRect.Width, _
                                     Math.Max(m_DragStartRect.Bottom - pos.Y, pos.Y - m_DragStartRect.Bottom))
            Case CursorPos.Right
                ' 右 ⇒ リサイズ
                rect = New Rectangle(Math.Min(m_DragStartRect.Left, pos.X), _
                                     m_DragStartRect.Top, _
                                     Math.Max(m_DragStartRect.Left - pos.X, pos.X - m_DragStartRect.Left), _
                                     m_DragStartRect.Height)
            Case CursorPos.Bottom
                ' 下 ⇒ リサイズ
                rect = New Rectangle(m_DragStartRect.Left, _
                                     Math.Min(m_DragStartRect.Top, pos.Y), _
                                     m_DragStartRect.Width, _
                                     Math.Max(m_DragStartRect.Top - pos.Y, pos.Y - m_DragStartRect.Top))
            Case CursorPos.Inside
                ' 内側 ⇒ 矩形移動

                ' 移動量を計算
                Dim sizeMove As Size = pos - m_DragStartPos
                Dim rectTmp1 As Rectangle = MakeRect(m_DragStartRect, m_DragStartArrowPos)
                rectTmp1.Offset(sizeMove)
                If rectTmp1.Left < 0 Then
                    sizeMove.Width -= rectTmp1.Left
                ElseIf rectTmp1.Right >= m_ImageSize.Width Then
                    sizeMove.Width -= (rectTmp1.Right - m_ImageSize.Width + 1)
                End If
                If rectTmp1.Top < 0 Then
                    sizeMove.Height -= rectTmp1.Top
                ElseIf rectTmp1.Bottom >= m_ImageSize.Height Then
                    sizeMove.Height -= (rectTmp1.Bottom - m_ImageSize.Height + 1)
                End If

                ' 矩形を移動する。
                rect = m_DragStartRect
                rect.Offset(sizeMove)

                ' 矢印の端を移動する。
                Dim ArrowPos As Point = m_DragStartArrowPos
                ArrowPos.Offset(sizeMove)
                m_ArrowPos = ArrowPos

            Case CursorPos.ArrowPos
                ' 矢印の端を移動
                Dim ArrowPos As Point = m_DragStartArrowPos
                ArrowPos.Offset(pos - m_DragStartPos)
                m_ArrowPos = ArrowPos

                ' イメージからはみ出さないように補正する。
                If m_ArrowPos.X < 0 Then
                    m_ArrowPos.X = 0
                End If
                If rect.Y < 0 Then
                    m_ArrowPos.Y = 0
                End If
                If m_ArrowPos.X >= m_ImageSize.Width Then
                    m_ArrowPos.X = m_ImageSize.Width - 1
                End If
                If m_ArrowPos.Y >= m_ImageSize.Height Then
                    m_ArrowPos.Y = m_ImageSize.Height - 1
                End If
                Return

            Case Else
                ' その他は何もしない
                rect = MakeRect(pos, m_DragStartPos)

        End Select

        rect.Intersect(New Rectangle(0, 0, m_ImageSize.Width - 1, m_ImageSize.Height - 1))
        SetRect(rect, False)

    End Sub

    '''============================================================================================
    ''' <summary>
    ''' ドラッグ終了
    ''' </summary>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Function DragEnd() As Boolean

        m_DragCurPos = CursorPos.OutSide
        'm_DragStartPos = Nothing
        If Not IsText() Then
            m_ArrowPos = LeftTop(m_Rect)
        End If

        If (m_Rect.Width >= 5) And (m_Rect.Height >= 5) Then
            SetRect(m_Rect, True)
            Return True
        End If

        Return False

    End Function

    '''============================================================================================
    ''' <summary>
    ''' 矩形削除処理
    ''' </summary>
    ''' <param name="pos">クリック座標</param>
    ''' <param name="bRemove">処理有無</param>
    ''' <returns></returns>
    ''' <remarks>右クリック時に呼び出すこと。</remarks>
    '''============================================================================================
    Public Function Remove(ByVal pos As Point, ByRef bRemove As Boolean) As Boolean

        Select Case GetCursorPos(pos)
            Case CursorPos.ArrowPos
                m_ArrowPos = LeftTop(m_Rect)
                Return True
            Case CursorPos.OutSide
                Return False
            Case Else
                ' 矩形がクリックされた場合はトラッカーを削除するため
                bRemove = True
                Return True
        End Select

    End Function


    '''============================================================================================
    ''' <summary>
    ''' 描画処理
    ''' </summary>
    ''' <param name="g">Graphicsobject</param>
    '''============================================================================================
    Public Sub Draw(ByRef g As Graphics)

        Dim m_PenFrame As Pen = New Pen(g_Property.四角の色, g_Property.四角の太さ)
        Dim m_PenTextFrame As Pen = New Pen(g_Property.テキスト枠の色, g_Property.テキスト枠の太さ)
        Dim m_BrushTextBack As Brush = New SolidBrush(Color.FromArgb(g_Property.テキスト枠の透明度, g_Property.テキスト枠の背景色))
        Dim m_PenBlue As Pen = New Pen(Color.Blue, 3)
        Dim m_ArrowPen As Pen = New Pen(g_Property.矢印線の色, g_Property.矢印線の太さ)
        Dim m_ArrowPenDot As Pen = New Pen(g_Property.矢印線の色, g_Property.矢印線の太さ)
        m_ArrowPenDot.DashStyle = DashStyle.Dash

        Dim m_Font As New Font(g_Property.テキスト枠のフォント.Name, g_Property.テキスト枠のフォント.Size)
        Dim m_Color As Brush = New SolidBrush(g_Property.テキスト枠の文字色)
        'Private m_Color As Brush = Brushes.Blue

        If m_sText = "" Then
            If Not m_bLine Then
                ' 矩形を描画する。
                g.DrawRectangle(m_PenFrame, GetRect)
            Else
                ' 線を描画する。
                g.DrawLine(m_PenBlue, m_DragStartPos, GetDragEndPos)
            End If
        Else

            ' 矩形を描画する。
            g.FillRectangle(m_BrushTextBack, GetRect)
            g.DrawRectangle(m_PenTextFrame, GetRect)

            ' 文字列を描画する。
            g.DrawString(m_sText, m_Font, m_Color, GetRect)

            ' 矢印を描画する
            If m_ArrowPos <> LeftTop(m_Rect) Then

                Dim pos As Point = LeftTop(m_Rect)
                If m_ArrowPos.X < m_Rect.Right Then
                    If m_ArrowPos.Y < m_Rect.Bottom Then
                        ' 左上
                        pos = LeftTop(m_Rect)
                    Else
                        ' 左下
                        pos = LeftBottom(m_Rect)
                    End If
                Else
                    If m_ArrowPos.Y < m_Rect.Bottom Then
                        ' 右上
                        pos = RightTop(m_Rect)
                    Else
                        ' 右下
                        pos = RightBottom(m_Rect)
                    End If

                End If

                ' 矢印の線の部分を描画する。
                Const AROOW_SIZE As Integer = 15
                Const ARROW_RADIAN As Double = 0.4
                g.DrawLine(m_ArrowPenDot, pos, m_ArrowPos)

                Dim dTmp As Double = Math.Sqrt(Math.Pow(pos.X - m_ArrowPos.X, 2) + Math.Pow(pos.Y - m_ArrowPos.Y, 2))
                If dTmp = 0 Then
                    dTmp = 1 ' 0除算の対策
                End If
                Dim TmpPos = New Point(m_ArrowPos.X + (pos.X - m_ArrowPos.X) / dTmp * AROOW_SIZE, m_ArrowPos.Y + (pos.Y - m_ArrowPos.Y) / dTmp * AROOW_SIZE)
                Dim ArrowPos As Point

                ' 矢印の先を描画する。
                ArrowPos.X = m_ArrowPos.X + ((TmpPos.X - m_ArrowPos.X) * Math.Cos(-ARROW_RADIAN) + (TmpPos.Y - m_ArrowPos.Y) * Math.Sin(-ARROW_RADIAN))
                ArrowPos.Y = m_ArrowPos.Y + (-(TmpPos.X - m_ArrowPos.X) * Math.Sin(-ARROW_RADIAN) + (TmpPos.Y - m_ArrowPos.Y) * Math.Cos(-ARROW_RADIAN))
                g.DrawLine(m_ArrowPen, m_ArrowPos, ArrowPos)

                ArrowPos.X = m_ArrowPos.X + ((TmpPos.X - m_ArrowPos.X) * Math.Cos(ARROW_RADIAN) + (TmpPos.Y - m_ArrowPos.Y) * Math.Sin(ARROW_RADIAN))
                ArrowPos.Y = m_ArrowPos.Y + (-(TmpPos.X - m_ArrowPos.X) * Math.Sin(ARROW_RADIAN) + (TmpPos.Y - m_ArrowPos.Y) * Math.Cos(ARROW_RADIAN))
                g.DrawLine(m_ArrowPen, m_ArrowPos, ArrowPos)

            End If

        End If

    End Sub

    '''============================================================================================
    ''' <summary>
    ''' マウス矩形を文字列化する
    ''' </summary>
    ''' <returns>マウス矩形を文字列化したテキスト</returns>
    '''============================================================================================
    Public Function GetString() As String
        Return String.Format("{0},{1},{2},{3},{4},{5},{6}", _
                             m_Rect.Left, m_Rect.Top, _
                             m_Rect.Width, m_Rect.Height, m_ArrowPos.X, m_ArrowPos.Y, m_sText)

    End Function

    '''============================================================================================
    ''' <summary>
    ''' マウスクリックされた位置を返却する。
    ''' </summary>
    ''' <param name="pos"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Function GetCursorPos(ByVal pos As Point) As CursorPos

        If m_sText <> "" Then
            ' 矢印の端
            If Match(m_ArrowPos, pos) Then
                Return CursorPos.ArrowPos
            End If
        End If


        ' 線の場合、線との距離が遠ければ対象外とする。
        'If m_bLine Then

        '     線の左(上、または下)、右(上、または下)の座標を求める。
        '    Dim posLeft As Point = Nothing
        '    Dim posRight As Point = Nothing
        '    If (LeftTop(m_Rect) = m_DragStartPos) Or
        '       (RightBottom(m_Rect) = m_DragStartPos) Then
        '        posLeft = LeftTop(m_Rect)
        '        posRight = RightBottom(m_Rect)
        '    ElseIf (LeftBottom(m_Rect) = m_DragStartPos) Or
        '           (RightTop(m_Rect) = m_DragStartPos) Then
        '        posLeft = LeftBottom(m_Rect)
        '        posRight = RightTop(m_Rect)
        '    Else
        '        Debug.Assert(False)
        '    End If
        'End If

        If Match(LeftTop(m_Rect), pos) Then
            ' 左上
            Return CursorPos.LeftTop
        ElseIf Match(RightTop(m_Rect), pos) Then
            ' 右上
            Return CursorPos.RightTop
        ElseIf Match(RightBottom(m_Rect), pos) Then
            ' 右下
            Return CursorPos.RightBottom
        ElseIf Match(LeftBottom(m_Rect), pos) Then
            ' 左下
            Return CursorPos.LeftBottom
        End If

        If (m_Rect.Top <= pos.Y) And (pos.Y <= m_Rect.Bottom) Then
            If Math.Abs(m_Rect.Left - pos.X) <= 4 Then
                ' 左
                Return CursorPos.Left
            ElseIf Math.Abs(m_Rect.Right - pos.X) <= 4 Then
                ' 右
                Return CursorPos.Right
            End If
        End If

        If (m_Rect.Left <= pos.X) And (pos.X <= m_Rect.Right) Then
            If Math.Abs(m_Rect.Top - pos.Y) <= 4 Then
                ' 上
                Return CursorPos.Top
            ElseIf Math.Abs(m_Rect.Bottom - pos.Y) <= 4 Then
                ' 下
                Return CursorPos.Bottom
            End If
        End If

        If GetRect.Contains(pos) Then
            ' 矩形の内側
            Return CursorPos.Inside
        End If

        ' 矩形の外側
        Return CursorPos.OutSide

    End Function

    Public Function IsValid() As Boolean

        If (m_Rect.Width) <= 0 Or (m_Rect.Height <= 0) Then
            Return False
        End If

        If (m_Rect.Right >= m_ImageSize.Width) Or (m_Rect.Bottom >= m_ImageSize.Height) Then
            Return False
        End If

        Return True

    End Function

    Public Function GetDragEndPos() As Point

        Dim EndPos As Point = New Point(m_Rect.Right, m_Rect.Bottom)

        If m_Rect.Left < m_DragStartPos.X Then
            EndPos.X = m_Rect.Left
        ElseIf m_DragStartPos.X < m_Rect.Right Then
            EndPos.X = m_Rect.Right
        End If
        If m_Rect.Top < m_DragStartPos.Y Then
            EndPos.Y = m_Rect.Top
        ElseIf m_DragStartPos.Y < m_Rect.Bottom Then
            EndPos.Y = m_Rect.Bottom
        End If

        Return EndPos

    End Function

    Public Sub テキスト枠サイズ補正()

        If m_sText = "" Then
            Exit Sub
        End If

        If Not g_bテキスト枠サイズをテキストに合わせる Then
            Exit Sub
        End If

        Dim canvas As New Bitmap(m_Rect.Width, 1000)
        Dim g As Graphics = Graphics.FromImage(canvas)
        Dim sf As New StringFormat
        Dim font As New Font(g_Property.テキスト枠のフォント.Name, g_Property.テキスト枠のフォント.Size)
        Dim textsize As SizeF = g.MeasureString(m_sText, font, m_Rect.Width, sf)
        Debug.Print(Math.Ceiling(textsize.Width))
        Debug.Print(Math.Ceiling(textsize.Height))
        m_Rect.Width = Math.Ceiling(textsize.Width)
        m_Rect.Height = Math.Ceiling(textsize.Height)

    End Sub

End Class
