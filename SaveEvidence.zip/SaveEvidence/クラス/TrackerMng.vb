﻿Public Class TrackerMng

    Private m_Trackers As New List(Of TrackerItem)
    Private m_Target As TrackerItem
    Private m_ImageSize As Size

    Public Sub SetImageSize(ByVal ImageSize As Size)
        m_ImageSize = ImageSize
        For i As Integer = m_Trackers.Count - 1 To 0 Step -1
            m_Trackers(i).SetImageSize(ImageSize)
            If Not m_Trackers(i).IsValid() Then
                m_Trackers.RemoveAt(i)
            End If
        Next
    End Sub

    Public Function GetMouseCursor(ByVal pos As Point) As Cursor

        For i As Integer = m_Trackers.Count - 1 To 0 Step -1
            Select Case m_Trackers(i).GetCursorPos(pos)
                Case TrackerItem.CursorPos.LeftTop, TrackerItem.CursorPos.RightBottom
                    ' 左上、右下
                    Return Cursors.SizeNWSE
                Case TrackerItem.CursorPos.RightTop, TrackerItem.CursorPos.LeftBottom
                    ' 左下、右上
                    Return Cursors.SizeNESW
                Case TrackerItem.CursorPos.Top, TrackerItem.CursorPos.Bottom
                    ' 上、下
                    Return Cursors.SizeNS
                Case TrackerItem.CursorPos.Left, TrackerItem.CursorPos.Right
                    ' 左、右
                    Return Cursors.SizeWE
                Case TrackerItem.CursorPos.Inside
                    ' 内側
                    Return Cursors.Hand
                Case TrackerItem.CursorPos.ArrowPos
                    ' 矢印の端
                    Return Cursors.Hand
            End Select
        Next

        Return Cursors.Arrow

    End Function


    '''============================================================================================
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="pos"></param>
    ''' <param name="btn"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Function MouseDown( _
        ByVal pos As Point, _
        btn As MouseButtons _
    ) As Boolean

        Select Case (btn)

            Case MouseButtons.Left

                If (Control.ModifierKeys And Keys.Control) <> Keys.Control Then
                    ' 矩形上でドラッグされたかをチェックする。
                    Dim bRc As Boolean = False
                    For i As Integer = m_Trackers.Count - 1 To 0 Step -1
                        Dim target As TrackerItem = m_Trackers(i)
                        bRc = target.DragStart(pos)
                        If bRc Then
                            ' ターゲットを配列の末尾に移動する。
                            m_Trackers.Add(target)
                            m_Trackers.RemoveAt(i)
                            m_Target = target
                            Exit For
                        End If
                    Next

                    ' 矩形以外でドラッグされた場合、新しい矩形を追加する。
                    If Not bRc Then
                        ' イメージの外側は無効とする
                        If (pos.X < 0) Or (pos.Y < 0) Or _
                            (pos.X >= (m_ImageSize.Width - 1)) Or (pos.Y >= (m_ImageSize.Height - 1)) Then
                            Exit Function
                        End If

                        ' 矩形を追加する。
                        m_Target = New TrackerItem(pos, m_ImageSize, True)
                        m_Trackers.Add(m_Target)
                        bRc = True
                    End If

                    ' 新規矩形描画、矩形移動、矩形サイズ変更のいずれかの場合は、Trueを返却する。
                    MouseDown = True

                Else

                    ' 矩形上でドラッグされたかをチェックする。
                    Dim bRc As Boolean = False
                    Dim bRemove As Boolean = False
                    For i As Integer = m_Trackers.Count - 1 To 0 Step -1
                        bRc = m_Trackers(i).Remove(pos, bRemove)
                        If bRc Then
                            If bRemove Then
                                m_Trackers.RemoveAt(i)
                            End If
                            MouseDown = True
                            Exit For
                        End If
                    Next

                    ' 矩形以外でドラッグされた場合、新しい線を追加する。
                    If Not bRc Then
                        ' イメージの外側は無効とする
                        If (pos.X < 0) Or (pos.Y < 0) Or _
                            (pos.X >= (m_ImageSize.Width - 1)) Or (pos.Y >= (m_ImageSize.Height - 1)) Then
                            Exit Function
                        End If

                        ' 矩形を追加する。
                        m_Target = New TrackerItem(pos, m_ImageSize, False)
                        m_Trackers.Add(m_Target)
                        bRc = True
                    End If

                    ' 新規線描画の場合は、Trueを返却する。
                    MouseDown = True
                End If

            Case MouseButtons.Right
                '★★★
                ' 矩形上でドラッグされたかをチェックする。
                Dim bRc As Boolean = False
                Dim bRemove As Boolean = False
                For i As Integer = m_Trackers.Count - 1 To 0 Step -1

                    bRc = m_Trackers(i).Remove(pos, bRemove)
                    If bRc Then

                        If (Control.ModifierKeys And Keys.Shift) <> Keys.Shift Then
                            ' コンテキストメニューを表示
                            Dim c As New Control
                            c.Tag = i
                            Dim p As System.Drawing.Point = System.Windows.Forms.Cursor.Position
                            p -= New Point(g_MainForm.m_Image.Left, SystemInformation.CaptionHeight) 'g_MainForm.m_Image.Top - g_MainForm.ClientRectangle.Top)
                            g_MainForm.RightClickContextMenu.Show(c, p)
                        Else
                            ' Shift押下時は図形削除
                            If bRemove Then
                                m_Trackers.RemoveAt(i)
                            End If
                            MouseDown = True
                            Exit For
                        End If

                    End If
                Next

        End Select

    End Function

    '''============================================================================================
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="pos"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Function MouseMove(pos As Point) As Boolean

        If m_Target IsNot Nothing Then
            m_Target.DragMove(pos)
            MouseMove = True
        End If

    End Function

    '''============================================================================================
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="pos"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Function MouseUp(pos As Point) As Boolean

        If m_Target IsNot Nothing Then
            Dim bRc As Boolean = m_Target.DragEnd()
            m_Target = Nothing
            MouseUp = True

            If Not bRc Then
                m_Trackers.RemoveAt(m_Trackers.Count - 1)
            End If
        End If

    End Function

    '''============================================================================================
    ''' <summary>
    ''' 
    '''     ''' 
    ''' </summary>
    ''' <param name="pos"></param>
    ''' <param name="btn"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Function MouseDoubleClick( _
        ByVal pos As Point, _
        btn As MouseButtons _
    ) As Boolean

        ' 左ボタン以外は何もしない。
        If btn <> MouseButtons.Left Then
            Exit Function
        End If

        ' ダブルクリックされ矩形を取得する。
        ' 矩形以外がダブルクリックされた場合は何もしない。
        Dim Target As TrackerItem = HitTest(pos)
        If Target Is Nothing Then
            Exit Function
        End If

        ' インプットボックスでテキストを入力させる。
        Dim frm As New TextForm
        frm.txtText.Text = Target.GetText
        Dim rc As DialogResult = frm.ShowDialog(g_MainForm)

        ' キャンセルされた場合は終了する。
        If rc <> DialogResult.OK Then
            Exit Function
        End If

        'テキストを設定する。
        Target.SetText(frm.txtText.Text)
        MouseDoubleClick = True

    End Function


    Public Sub Draw(g As Graphics)
        For i As Integer = 0 To m_Trackers.Count - 1
            m_Trackers(i).Draw(g)
        Next
    End Sub

    Public Sub SetString(ByVal sText As String)

        Try
            m_Trackers.Clear()

            Dim arrRect() As String = sText.Split("／")
            For Each s As String In arrRect
                Dim target As New TrackerItem(s)
                m_Trackers.Add(target)
            Next

        Catch
        Finally
        End Try
        Dim sResult As String = ""
        For Each target As TrackerItem In m_Trackers
            sResult = (target.GetString & "／")
        Next
        If sResult.EndsWith("／") Then
            sResult = sResult.Substring(0, sResult.Length - 1)
        End If

    End Sub

    Public Function GetString() As String

        Dim sResult As String = ""
        For Each target As TrackerItem In m_Trackers
            sResult &= (target.GetString & "／")
        Next
        If sResult.EndsWith("／") Then
            sResult = sResult.Substring(0, sResult.Length - 1)
        End If
        Return sResult

    End Function

    Public Sub Delete(ByVal nIndex As Integer)
        If m_Trackers.Count = 0 Then
            Exit Sub
        End If
        If nIndex < 0 Then
            nIndex = m_Trackers.Count - 1
        End If
        If (nIndex + 1) <= m_Trackers.Count Then
            m_Trackers.RemoveAt(nIndex)
        End If
    End Sub

    Public Sub DeleteAll()
        While m_Trackers.Count <> 0
            m_Trackers.RemoveAt(0)
        End While
    End Sub

    Private Function HitTest(ByVal pos As Point) As TrackerItem

        For i As Integer = m_Trackers.Count - 1 To 0 Step -1
            If m_Trackers(i).GetRect.Contains(pos) Then
                Return m_Trackers(i)
            End If
        Next

        Return Nothing

    End Function

    Private Sub Remove(ByVal pos As Point)

        For i As Integer = m_Trackers.Count - 1 To 0 Step -1
            If m_Trackers(i).GetRect.Contains(pos) Then
                m_Trackers.RemoveAt(i)
                Exit Sub
            End If
        Next

    End Sub

    Public Function GetCount()
        Return m_Trackers.Count
    End Function

    Public Function GetAt(ByVal nIndex As Integer) As TrackerItem
        Return m_Trackers(nIndex)
    End Function

    Public Function GetSelectedRect() As Rectangle

        If m_Trackers.Count() = 0 Then
            Return New Rectangle(0, 0, 0, 0)
        End If

        Return m_Trackers(m_Trackers.Count() - 1).GetRect()

    End Function

    Public Function MoveRect(ByVal x As Integer, ByVal y As Integer) As Boolean

        If m_Trackers.Count = 0 Then
            Return False
        End If

        Dim rect As Rectangle = m_Trackers(m_Trackers.Count() - 1).GetRect()
        m_Trackers(m_Trackers.Count() - 1).SetRect(New Rectangle(rect.Left + x, rect.Top + y, rect.Width, rect.Height), True)
        Return True

    End Function

    Public Function ResizeRect(ByVal x As Integer, ByVal y As Integer) As Boolean

        If m_Trackers.Count = 0 Then
            Return False
        End If

        Dim rect As Rectangle = m_Trackers(m_Trackers.Count() - 1).GetRect()
        m_Trackers(m_Trackers.Count() - 1).SetRect(New Rectangle(rect.Left, rect.Top, rect.Width + x, rect.Height + y), True)
        Return True

    End Function

End Class
