﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ScrollPictureBox
	Inherits System.Windows.Forms.Panel

	'UserControl はコンポーネント一覧をクリーンアップするために dispose をオーバーライドします。
	<System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
		Me.m_Image = New SaveEvidence.PictureBoxEx()
		CType(Me.m_Image, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'm_Image
		'
		Me.m_Image.BackColor = System.Drawing.SystemColors.ControlDark
		Me.m_Image.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.m_Image.Dock = System.Windows.Forms.DockStyle.Fill
		Me.m_Image.Location = New System.Drawing.Point(0, 0)
		Me.m_Image.Margin = New System.Windows.Forms.Padding(5)
		Me.m_Image.Name = "m_Image"
		Me.m_Image.Size = New System.Drawing.Size(899, 421)
		Me.m_Image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
		Me.m_Image.TabIndex = 14
		Me.m_Image.TabStop = False
		Me.m_Image.Tag = "m_Image"
		Me.m_Image.AllowDrop = True
		'
		'ScrollPictureBox
		'
		Me.AutoScroll = True
		Me.Controls.Add(Me.m_Image)
		Me.Size = New System.Drawing.Size(899, 421)
		CType(Me.m_Image, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)

	End Sub

	Friend WithEvents m_Image As PictureBoxEx
End Class
