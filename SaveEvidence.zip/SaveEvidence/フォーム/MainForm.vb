﻿Imports System.IO
Imports System.Environment

Public Class MainForm

    Private m_Bmp As Bitmap
    Private m_bSaved As Boolean = False
    Dim m_OldBmp As Bitmap
    Private m_ZukeiRireki As New RecentItemMap

    Public m_bForceClose As Boolean = False
    Public m_bAutoSave As Boolean = False

    Private m_bInitialized As Boolean = False

    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' Countupクラスのテスト
        'Countup.CountTest()

        ' Padding0クラスのテスト
        'Padding0.Test()

        If m_bAutoSave Then
            'AutoCaptureForm.Show()
            Show()
            Activate()
            Application.DoEvents()
        End If
        m_bSaved = False

        Left = 0
        Top = 0

        m_Image.Visible = True
        m_Image.AllowDrop = True
        g_RecentFileIndex = -1


        Me.Width = Math.Max(Integer.Parse(My.Settings.幅), Me.MinimumSize.Width)
        Me.Height = Math.Max(Integer.Parse(My.Settings.高さ), Me.MinimumSize.Height)
        txtFileName.Text = My.Settings.ファイル名
        mnuSetting最前面表示.Checked = My.Settings.最前面表示
        mnuSettingマウス矩形保存.Checked = My.Settings.マウス矩形保存
        mnuファイル名0詰め2桁.Checked = My.Settings.ファイル名0詰め2桁
        If mnuSettingマウス矩形保存.Checked Then
            m_Image.SetMouseRect(My.Settings.マウス矩形)
        End If
        mnuSetting自動で番号をカウントアップ.Checked = My.Settings.自動で番号をカウントアップ
        If mnuSetting自動で番号をカウントアップ.Checked Then
            Count(True, True)
        End If
        m_ZukeiRireki.SetMultiItem(My.Settings.過去のマウス矩形)
        mnuファイル名0詰め2桁.Checked = My.Settings.ファイル名0詰め2桁

        テキスト枠サイズをテキストに合わせるToolStripMenuItem.Checked = Not My.Settings.テキスト枠サイズをテキストに合わせる
        テキスト枠サイズをテキストに合わせるToolStripMenuItem_Click(Nothing, Nothing)

        ResizePath()

        ' 過去のイメージを表示している場合はマウス矩形は不可。
        m_ImageOld.SetDrawMouseRect(False)

        m_Image.SetBmp(m_Bmp)

#If DEBUG Then
        ' 〇リオテスト用
        'mnu設定_Click(mnuSettting〇リオ, Nothing)
#End If


        If m_bAutoSave Then
            ' 再描画
            Update()

            SaveFile()

            Threading.Thread.Sleep(500)
            '  AutoCaptureForm.Close()

            Close()

        End If

        m_bInitialized = True

    End Sub

    Public Sub SetBmp(ByRef bmp As Bitmap)
        m_Bmp = bmp
    End Sub

    Private Sub MainForm_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        Me.TopMost = mnuSetting最前面表示.Checked
    End Sub

    Private Sub MainForm_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed

        If m_bForceClose Then
            Exit Sub
        End If

        SaveSettings(False)

    End Sub



    Private Sub mnuファイル_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) _
        Handles mnuFile終了.Click, btnSave.Click, mnuFile保存.Click, mnuFile名前を付けて保存.Click

        If sender Is mnuFile終了 Then
            Close()
        ElseIf (sender Is btnSave) Or (sender Is mnuFile保存) Then
            SaveFile()
        ElseIf (sender Is mnuFile名前を付けて保存) Then
            SaveFile2()
        End If
    End Sub

    Public Sub SaveFile()

        ' 過去のイメージが表示されている場合、最新のイメージを表示する。
        If g_RecentFileIndex <> -1 Then
            Dim rc As DialogResult =
                MsgBox("過去のイメージが表示されています。" & vbCrLf &
                       "最後に取得したエビデンスをこのイメージに上書きしますか？" & vbCrLf & vbCrLf &
                       "　はい　：現在のファイル名と最新のイメージを表示する。" & vbCrLf &
                       "　いいえ：ファイル名を変更せず最新のイメージを表示する。",
                       MsgBoxStyle.Exclamation Or MsgBoxStyle.YesNo Or MsgBoxStyle.DefaultButton2)
            If rc = vbYes Then
                txtFileName.Text = txtFileNameOld.Text
            End If
            g_RecentFileIndex = -1
            ShowOldImage()
            Exit Sub
        End If

        ' Bitmapの作成
        Dim sFilePath As String

        If txtFileName.Text = "" Then
            MsgBox("ファイル名が入力されていません。", vbExclamation)
            Exit Sub
        End If

        ' 最後の保存したフォルダ名
        g_sLastFolder = g_sFolder

        ' TABを｢-｣に置換する
        txtFileName.Text = txtFileName.Text.Replace(vbTab, "-")

        ' ファイル名の数字部分を0詰め2桁に変換
        If mnuファイル名0詰め2桁.Checked Then
            txtFileName.Text = Padding0.Padding0(txtFileName.Text)
        End If


        ' ｢\｣が含まれている場合、フォルダを作成する。
        Dim arrItems() As String = txtFileName.Text.Split("\")
        Select Case arrItems.Length
            Case 1
                ' ファイル名のみ指定
            Case 2
                ' フォルダ名+ファイル名を指定
                Dim sFolder As String = g_sFolder & arrItems(0)
                If Not Directory.Exists(sFolder) Then
                    Try
                        Directory.CreateDirectory(sFolder)
                    Catch
                        MsgBox(String.Format("フォルダの作成に失敗しました。({0})", sFolder), vbExclamation)
                        Exit Sub
                    End Try
                End If
                g_sLastFolder = sFolder
            Case Else
                MsgBox("ファイル名の形式が不正です。(｢\｣が２つ以上含まれています。)", vbExclamation)
                Exit Sub
        End Select


        If txtFileName.Text.EndsWith(".png", StringComparison.OrdinalIgnoreCase) Then
            txtFileName.Text = txtFileName.Text.Substring(0, txtFileName.Text.Length - 4)
        End If
        sFilePath = g_sFolder & txtFileName.Text
        sFilePath += ".png"

        ' フォルダが無ければ作成する。
        If Not Directory.Exists(sFilePath) Then
            Directory.CreateDirectory(g_sFolder)
        End If

        If File.Exists(sFilePath) Then
            If m_bAutoSave Then
                Show()
            End If
            Dim nRc As Integer = MsgBox("指定されたファイルは既に存在します。" & vbCrLf & "上書きしますか？", vbExclamation Or MsgBoxStyle.OkCancel)
            If nRc <> MsgBoxResult.Ok Then
                Exit Sub
            End If
        End If

        Try
            m_Image.Save(sFilePath)
            g_RecentFileList.Add(sFilePath)
        Catch
            MsgBox("エビデンスの保存に失敗しました。" & vbCrLf & "　ファイル : " & sFilePath, vbExclamation)
        End Try

        SaveSettings(True)

        m_bSaved = True
        Close()

    End Sub

    Public Sub SaveFile2()

        'SaveFileDialogクラスのインスタンスを作成
        Dim sfd As New SaveFileDialog()

        '[ファイルの種類]に表示される選択肢を指定する
        sfd.Filter = "PNG ファイル(*.png)|*.png|すべてのファイル(*.*)|*.*"
        sfd.Title = "保存先のファイルを選択してください"
        sfd.RestoreDirectory = True

        'ダイアログを表示する
        If sfd.ShowDialog() <> DialogResult.OK Then
            Exit Sub
        End If

        Try
            If g_RecentFileIndex = -1 Then
                m_Image.Save(sfd.FileName)
            Else
                m_ImageOld.Save(sfd.FileName)
            End If
        Catch
            MsgBox("ファイルの保存に失敗しました。" & vbCrLf & "　ファイル : " & sfd.FileName, vbExclamation)
        End Try

    End Sub

    Private Sub lblPathDisp_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lblPathDisp.LinkClicked

        Try
            System.Diagnostics.Process.Start(g_sFolder)
        Catch
            MsgBox("格納フォルダが存在しません。" & vbCrLf & "格納フォルダを変更してください。", vbExclamation)
        End Try


    End Sub

    Private Sub mnuSettingマウス矩形保存_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuSettingマウス矩形保存.Click
        mnuSettingマウス矩形保存.Checked = Not mnuSettingマウス矩形保存.Checked
        SaveSettings(False)
    End Sub

    Private Sub mnuSetting最前面表示_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuSetting最前面表示.Click
        mnuSetting最前面表示.Checked = Not mnuSetting最前面表示.Checked
        Me.TopMost = mnuSetting最前面表示.Checked
        SaveSettings(False)
    End Sub

    Sub SaveSettings(ByVal bSaveファイル名 As Boolean)

        My.Settings.幅 = Me.Width
        My.Settings.高さ = Me.Height
        If bSaveファイル名 Then
            My.Settings.ファイル名 = txtFileName.Text
        End If
        My.Settings.最前面表示 = mnuSetting最前面表示.Checked
        My.Settings.マウス矩形保存 = mnuSettingマウス矩形保存.Checked
        If My.Settings.マウス矩形保存 Then
            My.Settings.マウス矩形 = m_Image.GetMouseRect
        End If
        My.Settings.格納フォルダ = g_sFolder
        My.Settings.自動で番号をカウントアップ = mnuSetting自動で番号をカウントアップ.Checked
        m_ZukeiRireki.AddItem(txtFileName.Text, m_Image.GetMouseRect)
        My.Settings.過去のマウス矩形 = m_ZukeiRireki.GetMultiItem
        My.Settings.ファイル名0詰め2桁 = mnuファイル名0詰め2桁.Checked

        My.Settings.テキスト枠サイズをテキストに合わせる = テキスト枠サイズをテキストに合わせるToolStripMenuItem.Checked

        My.Settings.Save()

    End Sub

    Private Sub mnuSetttingスタートアップに登録_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuSetttingスタートアップに登録.Click

        Dim sStartupFolder As String = "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup"
        If sStartupFolder = "" Then
            sStartupFolder = "C:\Users\" & UserName & "\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup"
        End If

        Dim rc As MsgBoxResult
        rc = MsgBox("ログイン時に本ツールが起動するよう、スタートアップに登録します。よろしいですか？" & vbCrLf & vbCrLf &
                    "※｢はい｣を選択すると、以下のフォルダにショートカットが作成されます。" & vbCrLf &
                     sStartupFolder, MsgBoxStyle.YesNo Or MsgBoxStyle.Exclamation, My.Application.Info.AssemblyName)
        If rc <> MsgBoxResult.Yes Then
            Exit Sub
        End If

        Try

            '作成するショートカットのパス 
            Dim sShortcutPathTmp As String = Path.Combine(Application.StartupPath, "SaveEvidence.lnk")
            Dim sShortcutPath As String = Path.Combine(sStartupFolder, "SaveEvidence.lnk")

            'WshShellを作成 
            Dim shell As New IWshRuntimeLibrary.WshShell()
            Dim shortcut As IWshRuntimeLibrary.IWshShortcut = DirectCast(shell.CreateShortcut(sShortcutPathTmp), IWshRuntimeLibrary.IWshShortcut)

            shortcut.TargetPath = Application.ExecutablePath
            shortcut.WorkingDirectory = Application.StartupPath
            shortcut.Save()

            System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shortcut)
            System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shell)

            If File.Exists(sShortcutPath) Then
                File.SetAttributes(sShortcutPath, FileAttributes.Normal)
            End If

            File.Copy(sShortcutPathTmp, sShortcutPath, True)
            File.Delete(sShortcutPathTmp)

            MsgBox("スタートアップへの登録が完了しました。",
                   MsgBoxStyle.Information, My.Application.Info.AssemblyName)
        Catch

            MsgBox("スタートアップへの登録に失敗しました。" & vbCrLf &
                   "フォルダを表示しますので、手動でショートカットを作成してください。", MsgBoxStyle.Exclamation)
            System.Diagnostics.Process.Start(sStartupFolder)

        End Try

    End Sub

    Private Sub MainForm_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown

        ' 強制的に最前面に表示する。
        SetForeground(Me)

        '' フォームが背面に表示されることがある。
        '' 対策として一時的に最前面にしてしまう。
        'Me.TopMost = True
        'Update()
        'Me.TopMost = mnuSetting最前面表示.Checked

    End Sub


    Private Sub 番号をカウントアップCtToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 番号をカウントアップCtToolStripMenuItem.Click
        Count(True)
    End Sub

    Private Sub 番号をカウントダウンCtToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem3.Click
        Count(False)
    End Sub

    Private Sub MainForm_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown

        Select Case e.KeyCode
            Case Keys.PageUp
                Count(True)
            Case Keys.PageDown
                Count(False)

            Case Keys.Left
                If e.Alt Then
                    If (g_RecentFileIndex + 1) >= (g_RecentFileList.Count) Then
                        Exit Sub
                    End If
                    g_RecentFileIndex += 1
                    ShowOldImage()
                End If
            Case Keys.Right
                If e.Alt Then
                    If g_RecentFileIndex = -1 Then
                        Exit Sub
                    End If
                    g_RecentFileIndex -= 1
                    ShowOldImage()
                End If
            Case Keys.Delete
                If g_RecentFileIndex <> -1 Then
                    Dim rc As DialogResult = MsgBox("表示されているファイルを削除します。" & vbCrLf & "よろしいですか？",
                                                    vbYesNo Or MsgBoxStyle.Exclamation Or MsgBoxStyle.DefaultButton2)
                    If rc = Windows.Forms.DialogResult.Yes Then
                        Try
                            File.Delete(g_RecentFileList.GetAt(g_RecentFileIndex))
                            g_RecentFileList.RemoveAt(g_RecentFileIndex)
                            g_RecentFileIndex -= 1
                            ShowOldImage()
                        Catch ex As Exception

                        End Try
                    End If

                End If
            Case Keys.Escape
                Close()

        End Select

        ' Mario
        m_Image.MyKeyDown(e.KeyCode, e.Control, e.Alt, e.Shift)

    End Sub

    Private Sub ShowOldImage()

        Try
            Dim bCurImage As Boolean = (g_RecentFileIndex = -1)

            m_ImageOld.Visible = Not bCurImage
            m_Image.Visible = bCurImage
            txtFileNameOld.Visible = Not bCurImage
            txtFileName.Visible = bCurImage

            If g_RecentFileIndex <> -1 Then
                txtFileNameOld.Text = System.IO.Path.GetFileNameWithoutExtension(g_RecentFileList.GetAt(g_RecentFileIndex))
                m_OldBmp = PictureBoxEx.CreateImage(g_RecentFileList.GetAt(g_RecentFileIndex).ToString)
                'm_OldBmp = Bitmap.FromFile(g_RecentFileList.GetAt(g_RecentFileIndex).ToString)
                m_ImageOld.SetBmp(m_OldBmp)
            End If

        Catch ex As Exception

        End Try

    End Sub

    Private Sub Count(ByVal bUp As Boolean, Optional bStart As Boolean = False)

        Dim SelectionstartBak As Integer = txtFileName.SelectionStart
        Dim SelectionLengthBak As Integer = txtFileName.SelectionLength
        Dim LengthBak As Integer = txtFileName.Text.Length

        Dim nMode As Countup.eMode = Countup.eMode.modeNone
        If (Control.ModifierKeys And Keys.Control) Then
            If (Control.ModifierKeys And Keys.Shift) Then
                nMode = Countup.eMode.modeCtrlShift
            Else
                nMode = Countup.eMode.modeCtrl
            End If
        End If

        txtFileName.Text = Countup.Count(txtFileName.Text, bUp,
                                         If(bStart, Countup.eMode.modeNone, nMode))

        txtFileName.SelectionStart = SelectionstartBak + (txtFileName.Text.Length - LengthBak)
        txtFileName.SelectionLength = SelectionLengthBak

    End Sub

    '''============================================================================================
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    '''============================================================================================
    Private Sub mnuエビデンス_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) _
        Handles mnuエビデンス_クリップボードにコピー.Click,
        mnuエビデンス_クリップボードのイメージを貼り付け.Click,
        mnuエビデンス_クリップボードにコピー_選択範囲.Click


        If sender Is mnuエビデンス_クリップボードにコピー Then
            Clipboard.SetImage(m_Image.GetImage)
        ElseIf sender Is mnuエビデンス_クリップボードにコピー_選択範囲 Then
            Clipboard.SetImage(m_Image.GetSelectecRectImage)
        ElseIf sender Is mnuエビデンス_クリップボードのイメージを貼り付け Then
            Dim img As Image = Clipboard.GetImage
            If img IsNot Nothing Then
                m_Image.SetBmp(img)
            End If
        End If

    End Sub

    '''============================================================================================
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    '''============================================================================================
    Private Sub mnu図形_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) _
        Handles mnu図形_削除.Click, mnu図形_全て削除.Click, mnu図形_最新に反映.Click, mnu図形_設定.Click

        If sender Is mnu図形_削除 Then

            m_Image.DeleteTracker(-1)

        ElseIf sender Is mnu図形_全て削除 Then

            If m_Image.GetTrackerCount > 0 Then
                Dim rc As DialogResult
                rc = MsgBox("全ての図形を削除します。よろしいですか？", MsgBoxStyle.YesNo Or MsgBoxStyle.Exclamation, My.Application.Info.AssemblyName)
                If rc = Windows.Forms.DialogResult.Yes Then
                    m_Image.DeleteAllTracker()
                End If

            End If

        ElseIf sender Is mnu図形_最新に反映 Then

            If g_RecentFileIndex <> -1 Then

                Dim rc As DialogResult =
                    MsgBox("このイメージ上の図形を最新のイメージに反映しますか？",
                           MsgBoxStyle.Exclamation Or MsgBoxStyle.YesNo Or MsgBoxStyle.DefaultButton2)
                If rc = vbYes Then
                    m_Image.SetMouseRect(m_ZukeiRireki.GetItem(GetCurrentFileName))
                    m_Image.Redraw()
                    g_RecentFileIndex = -1
                    ShowOldImage()
                    Exit Sub
                End If
            End If


        ElseIf sender Is mnu図形_設定 Then
            Dim dlg As New PropertyForm
            Dim tmp As PropertyClass = g_Property.Clone
            dlg.m_Data = tmp
            If dlg.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
                g_Property = tmp
                g_Property.Save()
                Me.Refresh()
                m_Image.Refresh()
                m_Image.Redraw()

            End If
        End If
    End Sub

    Private Sub mnu設定_格納フォルダ変更_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnu設定_格納フォルダ変更.Click

        'FolderBrowserDialogクラスのインスタンスを作成
        Dim fbd As New FolderBrowserDialog

        '上部に表示する説明テキストを指定する
        fbd.Description = "フォルダを指定してください。"
        'ルートフォルダを指定する
        'デフォルトでDesktop
        fbd.RootFolder = Environment.SpecialFolder.Desktop
        '最初に選択するフォルダを指定する
        'RootFolder以下にあるフォルダである必要がある
        fbd.SelectedPath = g_sFolder
        'ユーザーが新しいフォルダを作成できるようにする
        'デフォルトでTrue
        fbd.ShowNewFolderButton = True

        'ダイアログを表示する
        If fbd.ShowDialog(Me) = DialogResult.OK Then
            '選択されたフォルダを表示する
            g_sFolder = fbd.SelectedPath
            g_sFolder = g_sFolder.Trim("\") & "\"
            ResizePath()
        End If

        g_RecentFileIndex = -1
        g_RecentFileList.CreateFileList(g_sFolder)
        ShowOldImage()

    End Sub

    Private Sub mnu設定_ショートカットキー設定_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnu設定_ショートカットキー変更.Click

        Dim frm As New ShortcutKeySettingForm
        frm.ShowDialog(Me)

    End Sub

    Private Sub mnuHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuHelp.Click

        If sender.Equals(mnuHelp) Then
            ShowHelp("SaveEvidence.mht")
        End If

    End Sub

    Private Sub mnu設定_Click(sender As Object, e As EventArgs) Handles mnuSetting自動で番号をカウントアップ.Click, mnuSettting〇リオ.Click

        If sender.Equals(mnuSetting自動で番号をカウントアップ) Then
            mnuSetting自動で番号をカウントアップ.Checked = Not mnuSetting自動で番号をカウントアップ.Checked
        ElseIf sender.Equals(mnuSettting〇リオ) Then

            txtFileName.ReadOnly = True
            txtFileNameOld.ReadOnly = True

            If mnuSettting〇リオ.Text = "〇リオ！(&G)" Then
                m_Image.ShowMario(True)
                mnuSettting〇リオ.Text = "〇イージ！！(&G)"
            Else
                m_Image.ShowMario(False)
                mnuSettting〇リオ.Text = "〇リオ！(&G)"
            End If
        End If

    End Sub

    ' Mario
    Private Sub MainForm_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyUp
        m_Image.MyKeyUp(e.KeyCode)
    End Sub

    ' Mario
    Private Sub MainForm_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LostFocus
        m_Image.MyLostFocus()
    End Sub


    Private Sub mnuSettingファイルリストを再作成_Click(sender As Object, e As EventArgs)
        g_RecentFileIndex = -1
        g_RecentFileList.CreateFileList(g_sFolder)
        ShowOldImage()
    End Sub

    Private Sub MainForm_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing

        If m_bForceClose Then
            Exit Sub
        End If

        If Not m_bSaved Then
            Dim rc As DialogResult = MsgBox("イメージが保存されていません。" & vbCrLf & "終了してもよろしいですか？", vbYesNo Or MsgBoxStyle.Exclamation Or MsgBoxStyle.DefaultButton2)
            If rc <> Windows.Forms.DialogResult.Yes Then
                e.Cancel = True
                Exit Sub
            End If
        End If


        ' Ctrlが押されている場合はエビデンスフォルダを開く
        'If (Control.ModifierKeys And Keys.Control) = Keys.Control Then
        '    Try
        '        System.Diagnostics.Process.Start(lblPath.Text)
        '    Catch
        '    End Try
        'End If

        m_Image.CloseMario()

    End Sub

    Private Sub m_Image_ChangeFileName(sFilePath As String) Handles m_Image.ChangeFileName

        On Error Resume Next
        txtFileName.Text = Path.GetFileNameWithoutExtension(sFilePath)

    End Sub

    ''' <summary>
    ''' ダブルクリックで番号をカウントアップ
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub txtFileName_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles txtFileName.MouseDoubleClick

        ' ★使いにくかったので機能削除

        'If (txtFileName.SelectedText = "") Or _
        '    Not Countup.IsNumber(txtFileName.SelectedText) Then
        '    Exit Sub
        'End If

        'Dim SelectionStartBak As Integer = txtFileName.SelectionStart
        'Dim SelectionLengthBak As Integer = txtFileName.SelectionLength
        'Dim LengthBak As Integer = txtFileName.Text.Length
        'Dim SelectedText As String = txtFileName.SelectedText

        'Dim nNo As Int64 = Convert.ToInt64(SelectedText)

        'If (Control.ModifierKeys And Keys.Shift) = Keys.Shift Then
        '    nNo = 1
        'ElseIf (Control.ModifierKeys And Keys.Control) = Keys.Control Then
        '    nNo -= 1
        '    nNo = Math.Max(nNo, 0)
        'Else
        '    nNo += 1
        'End If


        '' txtFileName.Text = Countup.Count(txtFileName.Text, bUp)
        'txtFileName.Text = txtFileName.Text.Substring(0, SelectionStartBak) & _
        '    nNo.ToString("D" & SelectedText.Length) & _
        '    txtFileName.Text.Substring(SelectionStartBak + SelectionLengthBak)
        'txtFileName.SelectionStart = SelectionStartBak
        'txtFileName.SelectionLength = SelectionLengthBak

    End Sub

    Private Sub mnu図形_DropDownOpened(sender As Object, e As EventArgs) Handles mnu図形.DropDownOpened

        Dim bEnable As Boolean = True

        If g_RecentFileIndex = -1 Then
            bEnable = False
        End If

        If Not m_ZukeiRireki.IsItemExist(GetCurrentFileName) Then
            bEnable = False
        End If

        mnu図形_最新に反映.Enabled = bEnable

    End Sub

    Private Function GetCurrentFileName() As String

        If g_RecentFileIndex = -1 Then
            Return txtFileName.Text
        Else
            Return txtFileNameOld.Text
        End If

    End Function

    Private Sub mnuStting_Click(sender As Object, e As EventArgs) Handles mnuファイル名0詰め2桁.Click
        If sender.Equals(mnuファイル名0詰め2桁) Then
            mnuファイル名0詰め2桁.Checked = Not mnuファイル名0詰め2桁.Checked
        End If

    End Sub

    Private Sub テキスト枠サイズをテキストに合わせるToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles テキスト枠サイズをテキストに合わせるToolStripMenuItem.Click

        テキスト枠サイズをテキストに合わせるToolStripMenuItem.Checked = Not テキスト枠サイズをテキストに合わせるToolStripMenuItem.Checked
        g_bテキスト枠サイズをテキストに合わせる = テキスト枠サイズをテキストに合わせるToolStripMenuItem.Checked

    End Sub

    Private Sub 図形を削除ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 図形を削除ToolStripMenuItem.Click
        m_Image.DeleteTracker(RightClickContextMenu.SourceControl.Tag)
    End Sub

    Private Sub 図形内のイメージをクリアToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 図形内のイメージをクリアToolStripMenuItem.Click

        Dim rect As Rectangle = m_Image.GetTracker(RightClickContextMenu.SourceControl.Tag).GetRect

        Dim g As Graphics = Graphics.FromImage(m_Image.GetScreenBmp)
        g.FillRectangle(Brushes.White, rect)
        g.Dispose()
        m_Image.Redraw()
        m_Image.DeleteTracker(RightClickContextMenu.SourceControl.Tag)

    End Sub

    Private Sub イメージに外枠を付加ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles イメージに外枠を付加ToolStripMenuItem.Click

        m_Image.Add外枠()

    End Sub

    Private Sub MainForm_Resize(sender As Object, e As EventArgs) Handles Me.Resize

        ' 起動してキャプチャーを取得
        ' → ウィンドウが小さい
        ' → ウィンドウを広げる
        ' → 続けてキャプチャーを取得
        ' とした場合に、広げる前のサイズに戻ってしまうことの対策。

        ' サイズを保存する。
        If m_bInitialized Then
            My.Settings.幅 = Me.Width
            My.Settings.高さ = Me.Height
            My.Settings.Save()
        End If

        ResizePath()
    End Sub

    Sub ResizePath()

        'lblPath.Left = lblFolder.Left + lblFolder.Width
        'lblFile.Left = lblPath.Left + lblPath.Width + 20
        'txtFileName.Left = lblFile.Left + lblFile.Width
        'txtFileName.Width = ClientSize.Width - txtFileName.Left - btnSave.Width - 5

        ' lblPathDisp.Width = lblFile.Left - lblPathDisp.Left ' ClientSize.Width - lblPathDisp.Left - 15
        Dim nNewSize = SetCompactPath(lblPathDisp, g_sFolder, 100, Me.ClientSize.Width - 500)
        lblPathDisp.Width = nNewSize
        lblPathDisp.Left = m_Image.Right - lblPathDisp.Width
        lblFolder.Left = lblPathDisp.Left - lblFolder.Width
        btnSave.Left = lblFolder.Left - btnSave.Width - 10
        txtFileName.Width = btnSave.Left - txtFileName.Left - 2
        txtFileNameOld.Width = txtFileName.Width

    End Sub
End Class

