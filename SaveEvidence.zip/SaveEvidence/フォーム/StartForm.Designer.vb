﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StartForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(StartForm))
        Me.m_NotifyIcon = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.m_ContextMenuStrip = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.mnuHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.menuFileOpenFolder = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuFileOpenFolder2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.リネームツールを起動ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuFileExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.m_ContextMenuStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'm_NotifyIcon
        '
        Me.m_NotifyIcon.BalloonTipText = "SaveEvidence"
        Me.m_NotifyIcon.ContextMenuStrip = Me.m_ContextMenuStrip
        Me.m_NotifyIcon.Icon = CType(resources.GetObject("m_NotifyIcon.Icon"), System.Drawing.Icon)
        Me.m_NotifyIcon.Text = "SaveEvidence"
        Me.m_NotifyIcon.Visible = True
        '
        'm_ContextMenuStrip
        '
        Me.m_ContextMenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuHelp, Me.ToolStripSeparator1, Me.menuFileOpenFolder, Me.menuFileOpenFolder2, Me.ToolStripMenuItem1, Me.リネームツールを起動ToolStripMenuItem, Me.ToolStripMenuItem2, Me.mnuFileExit})
        Me.m_ContextMenuStrip.Name = "m_ContextMenuStrip"
        Me.m_ContextMenuStrip.Size = New System.Drawing.Size(227, 154)
        '
        'mnuHelp
        '
        Me.mnuHelp.Enabled = False
        Me.mnuHelp.Name = "mnuHelp"
        Me.mnuHelp.Size = New System.Drawing.Size(226, 22)
        Me.mnuHelp.Text = "SaveEvidenceについて(&A)..."
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(223, 6)
        '
        'menuFileOpenFolder
        '
        Me.menuFileOpenFolder.Name = "menuFileOpenFolder"
        Me.menuFileOpenFolder.Size = New System.Drawing.Size(226, 22)
        Me.menuFileOpenFolder.Text = "格納フォルダを開く(&O)"
        '
        'menuFileOpenFolder2
        '
        Me.menuFileOpenFolder2.Name = "menuFileOpenFolder2"
        Me.menuFileOpenFolder2.Size = New System.Drawing.Size(226, 22)
        Me.menuFileOpenFolder2.Text = "最後に保存したフォルダを開く(&P)"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(223, 6)
        '
        'リネームツールを起動ToolStripMenuItem
        '
        Me.リネームツールを起動ToolStripMenuItem.Name = "リネームツールを起動ToolStripMenuItem"
        Me.リネームツールを起動ToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.リネームツールを起動ToolStripMenuItem.Text = "リネームツールを起動(&R)"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(223, 6)
        '
        'mnuFileExit
        '
        Me.mnuFileExit.Name = "mnuFileExit"
        Me.mnuFileExit.Size = New System.Drawing.Size(226, 22)
        Me.mnuFileExit.Text = "終了(&X)"
        '
        'StartForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(331, 326)
        Me.Font = New System.Drawing.Font("Meiryo UI", 9.0!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "StartForm"
        Me.Opacity = 0.0R
        Me.ShowInTaskbar = False
        Me.Text = "StartForm"
        Me.m_ContextMenuStrip.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents m_NotifyIcon As System.Windows.Forms.NotifyIcon
    Friend WithEvents m_ContextMenuStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents mnuFileExit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuFileOpenFolder As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents menuFileOpenFolder2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents リネームツールを起動ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripSeparator

End Class
