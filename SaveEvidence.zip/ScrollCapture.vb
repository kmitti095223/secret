﻿Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Runtime.InteropServices
Imports System.Threading
Imports System.Diagnostics
Imports System.Text
Imports System.Windows.Forms
Imports System.IO
Imports System.Linq

Public Class ScrollCapture
    Shared Function CaptureAndCombine() As Bitmap
        Dim hWnd As IntPtr = BrowserWindowDetector.IsForegroundWindowBrowser()
        If hWnd = IntPtr.Zero Then
            Return Nothing
        End If

        ' ウィンドウを前面に表示
        SetForegroundWindow(hWnd)
        Thread.Sleep(100)

        ' 先頭に移動
        keybd_event(VK_HOME, 0, 0, IntPtr.Zero) ' HOMEキー押下
        Thread.Sleep(100)
        keybd_event(VK_HOME, 0, 2, IntPtr.Zero) ' HOMEキー離す
        Thread.Sleep(500)

        ' キャプチャした画像を保持するリスト
        Dim capturedImages As New List(Of Bitmap)
        Dim previousBitmap As Bitmap = Nothing

        ' スクロールとキャプチャ
        For i As Integer = 1 To 10 ' 最大10ページ分をスクロール
            Dim currentBitmap As Bitmap = CaptureBitmap(hWnd)

            ' 前回の画像と比較して、同じであれば処理を終了
            If previousBitmap IsNot Nothing AndAlso CompareBitmaps(previousBitmap, currentBitmap) Then
                currentBitmap.Dispose() ' メモリ解放
                Exit For
            End If

            ' 前回の画像を解放し、新しい画像を保持
            If previousBitmap IsNot Nothing Then
                previousBitmap.Dispose()
            End If
            previousBitmap = currentBitmap

            ' 新しい画像をリストに追加
            capturedImages.Add(New Bitmap(currentBitmap))

            ' PageDown を送信
            keybd_event(VK_PAGEDOWN, 0, 0, IntPtr.Zero) ' PageDownキー押下
            Thread.Sleep(100)
            keybd_event(VK_PAGEDOWN, 0, 2, IntPtr.Zero) ' PageDownキー離す
            Thread.Sleep(500)
        Next

        ' 先頭に移動
        keybd_event(VK_HOME, 0, 0, IntPtr.Zero) ' HOMEキー押下
        Thread.Sleep(100)
        keybd_event(VK_HOME, 0, 2, IntPtr.Zero) ' HOMEキー離す
        Thread.Sleep(500)

        ' 結合した画像を作成して返す
        Dim combinedImage As Bitmap = CombineImagesVertically(capturedImages)

        ' 個々の画像を解放
        For Each img In capturedImages
            img.Dispose()
        Next

        Return combinedImage
    End Function

    Private Shared Function FindTargetWindow() As IntPtr
        Dim targetTitle As String = "収益認識管理システム"
        Dim foundHwnd As IntPtr = IntPtr.Zero

        EnumWindows(Function(hWnd, lParam)
                        Dim sb As New StringBuilder(256)
                        GetWindowText(hWnd, sb, sb.Capacity)
                        If sb.ToString().Contains(targetTitle) Then
                            foundHwnd = hWnd
                            Return False ' 発見したら検索終了
                        End If
                        Return True
                    End Function, IntPtr.Zero)

        Return foundHwnd
    End Function

    Private Shared Function CaptureBitmap(hWnd As IntPtr) As Bitmap
        Dim rect As Rectangle = GetWindowRectEx(hWnd)
        If rect.Width = 0 Or rect.Height = 0 Then
            Return Nothing
        End If

        Dim bmp As New Bitmap(rect.Width, rect.Height)
        Using g As Graphics = Graphics.FromImage(bmp)
            g.CopyFromScreen(New Point(rect.Left, rect.Top), New Point(0, 0), New Size(rect.Width, rect.Height))
        End Using
        Return bmp
    End Function

    Private Shared Function CompareBitmaps(bmp1 As Bitmap, bmp2 As Bitmap) As Boolean
        ' サイズが異なる場合、異なるとみなす
        If bmp1.Width <> bmp2.Width Or bmp1.Height <> bmp2.Height Then
            Return False
        End If

        ' ビットマップデータの比較
        For y As Integer = 0 To bmp1.Height - 1 Step 10 ' 10ピクセルごとに間引き
            For x As Integer = 0 To bmp1.Width - 1 Step 10
                If bmp1.GetPixel(x, y) <> bmp2.GetPixel(x, y) Then
                    Return False
                End If
            Next
        Next

        Return True
    End Function

    ' 複数の画像を縦に結合する
    Private Shared Function CombineImagesVertically(images As List(Of Bitmap)) As Bitmap
        If images.Count = 0 Then
            Return Nothing
        End If

        ' 全体のサイズを計算 (幅は最も広いもの、高さは合計)
        Dim totalWidth As Integer = images.Max(Function(img) img.Width)
        Dim totalHeight As Integer = images.Sum(Function(img) img.Height)

        ' 結合するビットマップの作成
        Dim finalImage As New Bitmap(totalWidth, totalHeight)

        Using g As Graphics = Graphics.FromImage(finalImage)
            g.Clear(Color.Black) ' 背景を黒で塗りつぶす (必要に応じて変更可)

            ' 各画像を結合
            Dim currentY As Integer = 0
            For Each img In images
                g.DrawImage(img, 0, currentY)
                currentY += img.Height
            Next
        End Using

        Return finalImage
    End Function

    ' ウィンドウ矩形を取得する
    Private Shared Function GetWindowRectEx(hWnd As IntPtr) As Rectangle
        Dim rect As New RECT()
        If GetWindowRect(hWnd, rect) Then
            Return New Rectangle(rect.Left, rect.Top, rect.Right - rect.Left, rect.Bottom - rect.Top)
        End If
        Return Rectangle.Empty
    End Function

    <DllImport("user32.dll")>
    Private Shared Function EnumWindows(lpEnumFunc As EnumWindowsProc, lParam As IntPtr) As Boolean
    End Function

    Private Delegate Function EnumWindowsProc(hWnd As IntPtr, lParam As IntPtr) As Boolean

    <DllImport("user32.dll", CharSet:=CharSet.Auto)>
    Private Shared Function GetWindowText(hWnd As IntPtr, lpString As StringBuilder, cch As Integer) As Integer
    End Function

    <DllImport("user32.dll")>
    Private Shared Function GetWindowRect(hWnd As IntPtr, ByRef lpRect As RECT) As Boolean
    End Function

    <StructLayout(LayoutKind.Sequential)>
    Private Structure RECT
        Public Left As Integer
        Public Top As Integer
        Public Right As Integer
        Public Bottom As Integer
    End Structure

    <DllImport("user32.dll")>
    Private Shared Sub SetForegroundWindow(hWnd As IntPtr)
    End Sub

    <DllImport("user32.dll")>
    Private Shared Sub keybd_event(bVk As Byte, bScan As Byte, dwFlags As Integer, dwExtraInfo As IntPtr)
    End Sub

    Private Const VK_HOME As Byte = &H24
    Private Const VK_PAGEDOWN As Byte = &H22
End Class