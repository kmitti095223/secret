﻿Public Class RecentFileList

    Public m_arrFilePath As New List(Of String)

    '''============================================================================================
    ''' <summary>
    ''' 初期処理
    ''' </summary>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Sub New()

    End Sub

    '''============================================================================================
    ''' <summary>
    ''' 終了処理
    ''' </summary>
    ''' <remarks></remarks>
    '''============================================================================================
    Protected Overrides Sub Finalize()

        MyBase.Finalize()

    End Sub

    '''============================================================================================
    ''' <summary>
    ''' ファイルパス追加
    ''' </summary>
    ''' <param name="sFilePath"></param>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Sub Add(ByVal sFilePath As String)

        ' ファイルパスを追加する。
        m_arrFilePath.Insert(0, sFilePath)

    End Sub

    '''============================================================================================
    ''' <summary>
    ''' ファイルパス取得
    ''' </summary>
    ''' <param name="nIndex"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Function GetAt(ByVal nIndex As String)

        Debug.Assert(nIndex < m_arrFilePath.Count)
        Return m_arrFilePath(nIndex)

    End Function

    '''============================================================================================
    ''' <summary>
    ''' ファイルパス削除
    ''' </summary>
    ''' <param name="nIndex"></param>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Sub RemoveAt(ByVal nIndex As String)

        m_arrFilePath.RemoveAt(nIndex)

    End Sub

    '''============================================================================================
    ''' <summary>
    ''' ファイル数取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    '''============================================================================================
    Public Function Count()

        Return m_arrFilePath.Count

    End Function

    Public Sub CreateFileList(ByVal sPath As String)

        m_arrFilePath.Clear()

        Dim arrFileList As String() = System.IO.Directory.GetFiles(sPath)
        Dim arrFileList2 As New List(Of String)
        For Each s As String In arrFileList
            If s.EndsWith(".png", StringComparison.OrdinalIgnoreCase) Then
                arrFileList2.Add(System.IO.File.GetLastWriteTime(s).ToString("yyyy年MM月dd日_HH時mm分ss秒_") & s)
            End If
        Next
        arrFileList2.Sort()
        arrFileList2.Reverse()

        For Each s As String In arrFileList2
            Debug.Print(s)
            m_arrFilePath.Add(s.Substring(22))
        Next

    End Sub

End Class
