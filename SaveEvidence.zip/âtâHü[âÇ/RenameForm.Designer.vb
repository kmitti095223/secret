﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RenameForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstFiles = New System.Windows.Forms.ListView()
        Me.OldFileName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.NewFileName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.btnRename = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtOld = New System.Windows.Forms.TextBox()
        Me.txtNew = New System.Windows.Forms.TextBox()
        Me.lbl説明 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lstFiles
        '
        Me.lstFiles.AllowDrop = True
        Me.lstFiles.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstFiles.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.OldFileName, Me.NewFileName})
        Me.lstFiles.FullRowSelect = True
        Me.lstFiles.GridLines = True
        Me.lstFiles.Location = New System.Drawing.Point(16, 70)
        Me.lstFiles.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.lstFiles.Name = "lstFiles"
        Me.lstFiles.Size = New System.Drawing.Size(647, 363)
        Me.lstFiles.TabIndex = 3
        Me.lstFiles.UseCompatibleStateImageBehavior = False
        Me.lstFiles.View = System.Windows.Forms.View.Details
        '
        'OldFileName
        '
        Me.OldFileName.Text = "変更前"
        '
        'NewFileName
        '
        Me.NewFileName.Text = "変更後"
        '
        'btnRename
        '
        Me.btnRename.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnRename.Location = New System.Drawing.Point(580, 5)
        Me.btnRename.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnRename.Name = "btnRename"
        Me.btnRename.Size = New System.Drawing.Size(84, 58)
        Me.btnRename.TabIndex = 2
        Me.btnRename.Text = "リネーム(&R)"
        Me.btnRename.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(14, 11)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 15)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "変更前"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(14, 42)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(43, 15)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "変更後"
        '
        'txtOld
        '
        Me.txtOld.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtOld.Location = New System.Drawing.Point(69, 8)
        Me.txtOld.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtOld.Name = "txtOld"
        Me.txtOld.Size = New System.Drawing.Size(503, 23)
        Me.txtOld.TabIndex = 0
        '
        'txtNew
        '
        Me.txtNew.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNew.Location = New System.Drawing.Point(69, 39)
        Me.txtNew.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtNew.Name = "txtNew"
        Me.txtNew.Size = New System.Drawing.Size(503, 23)
        Me.txtNew.TabIndex = 1
        '
        'lbl説明
        '
        Me.lbl説明.AutoSize = True
        Me.lbl説明.Location = New System.Drawing.Point(50, 135)
        Me.lbl説明.Name = "lbl説明"
        Me.lbl説明.Size = New System.Drawing.Size(158, 15)
        Me.lbl説明.TabIndex = 4
        Me.lbl説明.Text = "ここにファイルをドラッグしてください"
        '
        'RenameForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(681, 451)
        Me.Controls.Add(Me.lbl説明)
        Me.Controls.Add(Me.txtNew)
        Me.Controls.Add(Me.txtOld)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnRename)
        Me.Controls.Add(Me.lstFiles)
        Me.Font = New System.Drawing.Font("Meiryo UI", 9.0!)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MinimumSize = New System.Drawing.Size(464, 365)
        Me.Name = "RenameForm"
        Me.Text = "リネームツール"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lstFiles As System.Windows.Forms.ListView
    Friend WithEvents btnRename As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtOld As System.Windows.Forms.TextBox
    Friend WithEvents txtNew As System.Windows.Forms.TextBox
    Friend WithEvents OldFileName As System.Windows.Forms.ColumnHeader
    Friend WithEvents NewFileName As System.Windows.Forms.ColumnHeader
    Friend WithEvents lbl説明 As System.Windows.Forms.Label

End Class
