﻿Public Class SettingForm

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click, Button3.Click, Button2.Click
        ColorDialog1.Color = Color.Aqua
        ColorDialog1.ShowDialog(Me)
    End Sub
End Class