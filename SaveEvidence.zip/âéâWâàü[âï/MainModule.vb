﻿Imports System.Runtime.InteropServices

Module MainModule

    Public g_StartFormHandle As IntPtr
    Public g_sFolder As String = ""
    Public g_sLastFolder As String = ""
    Public g_RecentFileList As New RecentFileList
    Public g_RecentFileIndex As Integer = -1
    Public g_MainForm As MainForm = Nothing
    Public g_Property As New PropertyClass(True)

    Public g_bテキスト枠サイズをテキストに合わせる As Boolean

    Public Enum SaveMode
        All
        WindowOnly
        Clipboard
        Scroll
    End Enum

    Public Sub ShowForm(ByVal nMode As SaveMode, ByVal bAutoSave As Boolean)

        Dim ScreenBmp As Bitmap = Nothing

        Select Case nMode
            Case SaveMode.All
                ' 画面全体をコピーする
                ScreenBmp = New Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height)
                Dim g As Graphics = Graphics.FromImage(ScreenBmp)
                g.CopyFromScreen(New Point(0, 0), New Point(0, 0), ScreenBmp.Size)
                g.Dispose()
                g = Nothing

            Case SaveMode.WindowOnly
                ' アクティブウインドウのみをコピーする
                Dim rect As Rectangle = GetActiveWindowRect()
                If rect.Width = 0 Or rect.Height = 0 Then
                    Return
                End If
                ScreenBmp = New Bitmap(rect.Width, rect.Height)
                Dim g As Graphics = Graphics.FromImage(ScreenBmp)
                g.CopyFromScreen(New Point(rect.Left, rect.Top), New Point(0, 0), New Size(rect.Width, rect.Height))
                g.Dispose()
                g = Nothing
            Case SaveMode.Clipboard
                ' クリップボードのイメージをコピーする
                ScreenBmp = Clipboard.GetImage()
                If ScreenBmp Is Nothing Then
                    ' MsgBox("クリップボードにイメージがコピーされていません。", MsgBoxStyle.Exclamation)
                    Exit Sub
                End If

            Case SaveMode.Scroll
                ScreenBmp = ScrollCapture.CaptureAndCombine()
                If ScreenBmp Is Nothing Then
                    MsgBox("収益認識のウィンドウが見つかりません。。", MsgBoxStyle.Exclamation)
                    Exit Sub
                End If

            Case Else
                Debug.Assert(False)
        End Select

        If g_MainForm IsNot Nothing Then

            g_MainForm.Activate()
            Dim rc As DialogResult =
               MsgBox("既にSaveEvidenceが起動されています。" & vbCrLf &
                      "表示中のイメージを破棄してキャプチャしたイメージを表示しますか？",
                      MsgBoxStyle.Exclamation Or MsgBoxStyle.YesNo Or MsgBoxStyle.DefaultButton2)
            If rc <> vbYes Then
                Exit Sub
            End If

            g_MainForm.m_bForceClose = True
            g_MainForm.Dispose()

        End If

        g_MainForm = New MainForm()
        g_MainForm.SetBmp(ScreenBmp)
        g_MainForm.m_bAutoSave = bAutoSave
        g_MainForm.ShowDialog()
        If g_MainForm IsNot Nothing Then
            g_MainForm.Dispose()
        End If
        g_MainForm = Nothing

        ScreenBmp = Nothing

        System.GC.Collect()

    End Sub

    Private Function GetActiveWindowRect() As Rectangle

        'アクティブなウィンドウを取得
        Dim hWnd As IntPtr = GetForegroundWindow()
        Dim winRect As New RECT

        Try
            ' スタートフォームを拾ってしまった場合はキャプチャしない
            If hWnd = g_StartFormHandle Then
                Return New Rectangle(0, 0, 0, 0)
            End If


            Dim nRc As Integer = DwmGetWindowAttribute(hWnd, 9, winRect, 16)
            If nRc <> 0 Then
                GetWindowRect(hWnd, winRect)
            End If

            Return New Rectangle(winRect.left, winRect.top, winRect.right - winRect.left, winRect.bottom - winRect.top)
        Catch
            GetWindowRect(hWnd, winRect)
            Return New Rectangle(winRect.left, winRect.top, winRect.right - winRect.left, winRect.bottom - winRect.top)
        End Try

    End Function


    Public Function GetWindowRectEx(hWnd As IntPtr) As Rectangle

        'アクティブなウィンドウを取得
        Dim winRect As New RECT

        Try
            Dim nRc As Integer = DwmGetWindowAttribute(hWnd, 9, winRect, 16)
            If nRc <> 0 Then
                GetWindowRect(hWnd, winRect)
            End If

            Return New Rectangle(winRect.left, winRect.top, winRect.right - winRect.left, winRect.bottom - winRect.top)
        Catch
            GetWindowRect(hWnd, winRect)
            Return New Rectangle(winRect.left, winRect.top, winRect.right - winRect.left, winRect.bottom - winRect.top)
        End Try

    End Function

End Module
