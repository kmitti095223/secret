﻿Public Class ScrollPictureBox

    Public Event ChangeFileName(ByVal sFilePath As String)
    Private Sub m_Image_ChangeFileName(sFilePath As String) Handles m_Image.ChangeFileName
        ScrollPictureBox_Resize(Nothing, Nothing)
        RaiseEvent ChangeFileName(sFilePath)
    End Sub

    Public Sub SetBmp(ByVal bmp As Bitmap)

        m_Image.SetBmp(bmp)
        ScrollPictureBox_Resize(Nothing, Nothing)

    End Sub

    Private Sub ScrollPictureBox_Resize(sender As Object, e As EventArgs) Handles Me.Resize

        If m_Image.m_ScreenBmp Is Nothing Then
            Exit Sub
        End If

        ' 描画を停止
        SuspendLayout()

        If m_Image.m_ScreenBmp.Height > (Screen.FromControl(Me).Bounds.Height) Then
            ' 縦スクロールモード
            m_Image.Dock = DockStyle.None
            m_Image.Width = Me.ClientSize.Width
            'm_Image.Width = Me.ClientSize.Width - SystemInformation.VerticalScrollBarWidth
            m_Image.Height = CInt(m_Image.m_ScreenBmp.Height * (m_Image.Width / m_Image.m_ScreenBmp.Width)) ' 高さを計算
        Else
            ' フィットモード
            m_Image.Dock = DockStyle.Fill
            m_Image.Width = Me.ClientSize.Width
        End If

        ' 描画を再開
        ResumeLayout()

    End Sub

    Public Function GetImage() As Image
        Return m_Image.Image
    End Function

    Public Function GetScreenBmp() As Bitmap
        Return m_Image.m_ScreenBmp
    End Function

    Public Sub SetDrawMouseRect(ByVal b As Boolean)
        m_Image.m_bDrawMouseRect = b
    End Sub

    ' Clear()
    Public Sub Clear()
        m_Image.Clear()  ' 子クラスのClear()を呼び出し
    End Sub

    ' Save()
    Public Sub Save(ByVal sFilePath As String)
        m_Image.Save(sFilePath)  ' 子クラスのSave()を呼び出し
    End Sub

    ' SetMouseRect()
    Public Sub SetMouseRect(ByVal sMouseRect As String)
        m_Image.SetMouseRect(sMouseRect)  ' 子クラスのSetMouseRect()を呼び出し
    End Sub

    ' GetMouseRect()
    Public Function GetMouseRect() As String
        Return m_Image.GetMouseRect()  ' 子クラスのGetMouseRect()を呼び出し
    End Function

    ' DeleteTracker()
    Public Sub DeleteTracker(ByVal nIndex As Integer)
        m_Image.DeleteTracker(nIndex)  ' 子クラスのDeleteTracker()を呼び出し
    End Sub

    ' DeleteAllTracker()
    Public Sub DeleteAllTracker()
        m_Image.DeleteAllTracker()  ' 子クラスのDeleteAllTracker()を呼び出し
    End Sub

    Public Function GetTrackerCount()
        Return m_Image.GetTrackerCount
    End Function

    Public Function GetTracker(ByVal nIndex As Integer) As TrackerItem
        Return m_Image.GetTracker(nIndex)
    End Function


    ' Redraw()
    Public Sub Redraw()
        m_Image.Redraw()  ' 子クラスのRedraw()を呼び出し
    End Sub

    ' ScreenPosToImagePos()
    Public Function ScreenPosToImagePos(ByVal pos As Point) As Point
        Return m_Image.ScreenPosToImagePos(pos)  ' 子クラスのScreenPosToImagePos()を呼び出し
    End Function

    ' ScreenRectToImageRect()
    Public Function ScreenRectToImageRect(ByVal rect As Rectangle) As Rectangle
        Return m_Image.ScreenRectToImageRect(rect)  ' 子クラスのScreenRectToImageRect()を呼び出し
    End Function

    ' ImagePosToScreenPos()
    Public Function ImagePosToScreenPos(ByVal pos As Point) As Point
        Return m_Image.ImagePosToScreenPos(pos)  ' 子クラスのImagePosToScreenPos()を呼び出し
    End Function

    ' ImageRectToScreenRect()
    Public Function ImageRectToScreenRect(ByVal rect As Rectangle) As Rectangle
        Return m_Image.ImageRectToScreenRect(rect)  ' 子クラスのImageRectToScreenRect()を呼び出し
    End Function

    ' GetScale()
    Public Function GetScale() As Double
        Return m_Image.GetScale()  ' 子クラスのGetScale()を呼び出し
    End Function


    ' ShowMario()
    Public Sub ShowMario(ByVal bMode As Boolean)
        m_Image.ShowMario(bMode)  ' 子クラスのShowMario()を呼び出し
    End Sub

    ' CloseMario()
    Public Sub CloseMario()
        m_Image.CloseMario()  ' 子クラスのCloseMario()を呼び出し
    End Sub

    ' MyKeyDown()
    Public Sub MyKeyDown(ByVal KeyCode As Keys, ByVal bCtrl As Boolean, ByVal bAlt As Boolean, ByVal bShift As Boolean)
        m_Image.MyKeyDown(KeyCode, bCtrl, bAlt, bShift)  ' 子クラスのMyKeyDown()を呼び出し
    End Sub

    ' MyKeyUp()
    Public Sub MyKeyUp(ByVal KeyCode As Keys)
        m_Image.MyKeyUp(KeyCode)  ' 子クラスのMyKeyUp()を呼び出し
    End Sub

    ' MyLostFocus()
    Public Sub MyLostFocus()
        m_Image.MyLostFocus()  ' 子クラスのMyLostFocus()を呼び出し
    End Sub

    ' CreateImage()
    Public Shared Function CreateImage(ByVal filename As String) As Bitmap
        Return PictureBoxEx.CreateImage(filename)  ' 子クラスのCreateImage()を呼び出し
    End Function

    ' GetSelectecRectImage()
    Public Function GetSelectecRectImage() As System.Drawing.Image
        Return m_Image.GetSelectecRectImage()  ' 子クラスのGetSelectecRectImage()を呼び出し
    End Function

    ' Add外枠()
    Public Sub Add外枠()
        m_Image.Add外枠()  ' 子クラスのAdd外枠()を呼び出し
    End Sub

End Class
