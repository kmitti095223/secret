﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
        Me.txtFileName = New System.Windows.Forms.TextBox()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.lblFolder = New System.Windows.Forms.Label()
        Me.menuFile = New System.Windows.Forms.MenuStrip()
        Me.mnuファイル = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFile保存 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuFile名前を付けて保存 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuFile終了 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuエビデンス = New System.Windows.Forms.ToolStripMenuItem()
        Me.番号をカウントアップCtToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripSeparator()
        Me.前のイメージToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.次のイメージToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuエビデンス_クリップボードにコピー = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuエビデンス_クリップボードにコピー_選択範囲 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuエビデンス_クリップボードのイメージを貼り付け = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnu図形 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnu図形_削除 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnu図形_全て削除 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnu図形_最新に反映 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.テキスト枠サイズをテキストに合わせるToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.イメージに外枠を付加ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnu図形_設定 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSetting = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnu設定_格納フォルダ変更 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuSetting最前面表示 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSetting自動で番号をカウントアップ = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSettingマウス矩形保存 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuファイル名0詰め2桁 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuSetttingスタートアップに登録 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnu設定_ショートカットキー変更 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuSettting〇リオ = New System.Windows.Forms.ToolStripMenuItem()
        Me.ヘルプToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtFileNameOld = New System.Windows.Forms.TextBox()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.RightClickContextMenu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.図形を削除ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.図形内のイメージをクリアToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblFile = New System.Windows.Forms.Label()
        Me.lblPathDisp = New System.Windows.Forms.LinkLabel()
        Me.m_Image = New SaveEvidence.ScrollPictureBox()
        Me.m_ImageOld = New SaveEvidence.ScrollPictureBox()
        Me.設定ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripSeparator()
        Me.menuFile.SuspendLayout()
        Me.RightClickContextMenu.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtFileName
        '
        Me.txtFileName.Font = New System.Drawing.Font("Yu Gothic UI", 9.0!)
        Me.txtFileName.Location = New System.Drawing.Point(66, 28)
        Me.txtFileName.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtFileName.Name = "txtFileName"
        Me.txtFileName.Size = New System.Drawing.Size(440, 23)
        Me.txtFileName.TabIndex = 3
        '
        'btnSave
        '
        Me.btnSave.Font = New System.Drawing.Font("Yu Gothic UI", 9.0!)
        Me.btnSave.Location = New System.Drawing.Point(512, 27)
        Me.btnSave.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(50, 23)
        Me.btnSave.TabIndex = 5
        Me.btnSave.Text = "保存"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'lblFolder
        '
        Me.lblFolder.AutoSize = True
        Me.lblFolder.Font = New System.Drawing.Font("Yu Gothic UI", 9.0!)
        Me.lblFolder.ForeColor = System.Drawing.Color.Black
        Me.lblFolder.Location = New System.Drawing.Point(580, 31)
        Me.lblFolder.Name = "lblFolder"
        Me.lblFolder.Size = New System.Drawing.Size(78, 15)
        Me.lblFolder.TabIndex = 6
        Me.lblFolder.Text = "格納フォルダ："
        '
        'menuFile
        '
        Me.menuFile.BackColor = System.Drawing.SystemColors.Control
        Me.menuFile.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuファイル, Me.mnuエビデンス, Me.mnu図形, Me.mnuSetting, Me.ヘルプToolStripMenuItem})
        Me.menuFile.Location = New System.Drawing.Point(0, 0)
        Me.menuFile.Name = "menuFile"
        Me.menuFile.Padding = New System.Windows.Forms.Padding(7, 2, 0, 2)
        Me.menuFile.Size = New System.Drawing.Size(784, 24)
        Me.menuFile.TabIndex = 0
        Me.menuFile.Text = "MenuStrip1"
        '
        'mnuファイル
        '
        Me.mnuファイル.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile保存, Me.ToolStripMenuItem1, Me.mnuFile名前を付けて保存, Me.ToolStripSeparator5, Me.mnuFile終了})
        Me.mnuファイル.Name = "mnuファイル"
        Me.mnuファイル.Size = New System.Drawing.Size(67, 20)
        Me.mnuファイル.Text = "ファイル(&F)"
        '
        'mnuFile保存
        '
        Me.mnuFile保存.Name = "mnuFile保存"
        Me.mnuFile保存.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.mnuFile保存.Size = New System.Drawing.Size(177, 22)
        Me.mnuFile保存.Text = "保存(&S)"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(174, 6)
        '
        'mnuFile名前を付けて保存
        '
        Me.mnuFile名前を付けて保存.Name = "mnuFile名前を付けて保存"
        Me.mnuFile名前を付けて保存.ShortcutKeyDisplayString = ""
        Me.mnuFile名前を付けて保存.Size = New System.Drawing.Size(177, 22)
        Me.mnuFile名前を付けて保存.Text = "名前を付けて保存(&A)"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(174, 6)
        '
        'mnuFile終了
        '
        Me.mnuFile終了.Name = "mnuFile終了"
        Me.mnuFile終了.Size = New System.Drawing.Size(177, 22)
        Me.mnuFile終了.Text = "終了(&X)"
        '
        'mnuエビデンス
        '
        Me.mnuエビデンス.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.番号をカウントアップCtToolStripMenuItem, Me.ToolStripMenuItem3, Me.ToolStripMenuItem5, Me.前のイメージToolStripMenuItem, Me.次のイメージToolStripMenuItem, Me.ToolStripMenuItem4, Me.mnuエビデンス_クリップボードにコピー, Me.mnuエビデンス_クリップボードにコピー_選択範囲, Me.mnuエビデンス_クリップボードのイメージを貼り付け})
        Me.mnuエビデンス.Name = "mnuエビデンス"
        Me.mnuエビデンス.ShortcutKeyDisplayString = "Alt+→"
        Me.mnuエビデンス.Size = New System.Drawing.Size(76, 20)
        Me.mnuエビデンス.Text = "エビデンス(&E)"
        '
        '番号をカウントアップCtToolStripMenuItem
        '
        Me.番号をカウントアップCtToolStripMenuItem.Name = "番号をカウントアップCtToolStripMenuItem"
        Me.番号をカウントアップCtToolStripMenuItem.ShortcutKeyDisplayString = "PageUp"
        Me.番号をカウントアップCtToolStripMenuItem.Size = New System.Drawing.Size(300, 22)
        Me.番号をカウントアップCtToolStripMenuItem.Text = "番号をカウントアップ"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.ShortcutKeyDisplayString = "PageDown"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(300, 22)
        Me.ToolStripMenuItem3.Text = "番号をカウントダウン"
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(297, 6)
        '
        '前のイメージToolStripMenuItem
        '
        Me.前のイメージToolStripMenuItem.Name = "前のイメージToolStripMenuItem"
        Me.前のイメージToolStripMenuItem.ShortcutKeyDisplayString = "Alt+←"
        Me.前のイメージToolStripMenuItem.Size = New System.Drawing.Size(300, 22)
        Me.前のイメージToolStripMenuItem.Text = "前のイメージ"
        '
        '次のイメージToolStripMenuItem
        '
        Me.次のイメージToolStripMenuItem.Name = "次のイメージToolStripMenuItem"
        Me.次のイメージToolStripMenuItem.ShortcutKeyDisplayString = "Alt+→"
        Me.次のイメージToolStripMenuItem.Size = New System.Drawing.Size(300, 22)
        Me.次のイメージToolStripMenuItem.Text = "次のイメージ"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(297, 6)
        '
        'mnuエビデンス_クリップボードにコピー
        '
        Me.mnuエビデンス_クリップボードにコピー.Name = "mnuエビデンス_クリップボードにコピー"
        Me.mnuエビデンス_クリップボードにコピー.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
            Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.mnuエビデンス_クリップボードにコピー.Size = New System.Drawing.Size(300, 22)
        Me.mnuエビデンス_クリップボードにコピー.Text = "クリップボードにコピー"
        '
        'mnuエビデンス_クリップボードにコピー_選択範囲
        '
        Me.mnuエビデンス_クリップボードにコピー_選択範囲.Name = "mnuエビデンス_クリップボードにコピー_選択範囲"
        Me.mnuエビデンス_クリップボードにコピー_選択範囲.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
            Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.mnuエビデンス_クリップボードにコピー_選択範囲.Size = New System.Drawing.Size(300, 22)
        Me.mnuエビデンス_クリップボードにコピー_選択範囲.Text = "クリップボードにコピー(選択範囲)"
        '
        'mnuエビデンス_クリップボードのイメージを貼り付け
        '
        Me.mnuエビデンス_クリップボードのイメージを貼り付け.Name = "mnuエビデンス_クリップボードのイメージを貼り付け"
        Me.mnuエビデンス_クリップボードのイメージを貼り付け.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
            Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
        Me.mnuエビデンス_クリップボードのイメージを貼り付け.Size = New System.Drawing.Size(300, 22)
        Me.mnuエビデンス_クリップボードのイメージを貼り付け.Text = "クリップボードのイメージを貼り付け"
        '
        'mnu図形
        '
        Me.mnu図形.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu図形_削除, Me.mnu図形_全て削除, Me.mnu図形_最新に反映, Me.ToolStripSeparator7, Me.テキスト枠サイズをテキストに合わせるToolStripMenuItem, Me.イメージに外枠を付加ToolStripMenuItem, Me.ToolStripSeparator4, Me.mnu図形_設定})
        Me.mnu図形.Name = "mnu図形"
        Me.mnu図形.Size = New System.Drawing.Size(59, 20)
        Me.mnu図形.Text = "図形(&D)"
        '
        'mnu図形_削除
        '
        Me.mnu図形_削除.Name = "mnu図形_削除"
        Me.mnu図形_削除.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Delete), System.Windows.Forms.Keys)
        Me.mnu図形_削除.Size = New System.Drawing.Size(276, 22)
        Me.mnu図形_削除.Text = "図形を削除(&D)"
        '
        'mnu図形_全て削除
        '
        Me.mnu図形_全て削除.Name = "mnu図形_全て削除"
        Me.mnu図形_全て削除.ShortcutKeys = CType((System.Windows.Forms.Keys.Shift Or System.Windows.Forms.Keys.Delete), System.Windows.Forms.Keys)
        Me.mnu図形_全て削除.Size = New System.Drawing.Size(276, 22)
        Me.mnu図形_全て削除.Text = "全ての図形を削除(A)"
        '
        'mnu図形_最新に反映
        '
        Me.mnu図形_最新に反映.Name = "mnu図形_最新に反映"
        Me.mnu図形_最新に反映.ShortcutKeyDisplayString = "F8"
        Me.mnu図形_最新に反映.ShortcutKeys = System.Windows.Forms.Keys.F8
        Me.mnu図形_最新に反映.Size = New System.Drawing.Size(276, 22)
        Me.mnu図形_最新に反映.Text = "現在の図形を最新のイメージに反映(&F)"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(273, 6)
        '
        'テキスト枠サイズをテキストに合わせるToolStripMenuItem
        '
        Me.テキスト枠サイズをテキストに合わせるToolStripMenuItem.Name = "テキスト枠サイズをテキストに合わせるToolStripMenuItem"
        Me.テキスト枠サイズをテキストに合わせるToolStripMenuItem.Size = New System.Drawing.Size(276, 22)
        Me.テキスト枠サイズをテキストに合わせるToolStripMenuItem.Text = "テキスト枠サイズをテキストに合わせる"
        '
        'イメージに外枠を付加ToolStripMenuItem
        '
        Me.イメージに外枠を付加ToolStripMenuItem.Name = "イメージに外枠を付加ToolStripMenuItem"
        Me.イメージに外枠を付加ToolStripMenuItem.Size = New System.Drawing.Size(276, 22)
        Me.イメージに外枠を付加ToolStripMenuItem.Text = "イメージに外枠を付加"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(273, 6)
        '
        'mnu図形_設定
        '
        Me.mnu図形_設定.Name = "mnu図形_設定"
        Me.mnu図形_設定.Size = New System.Drawing.Size(276, 22)
        Me.mnu図形_設定.Text = "設定(&S)..."
        '
        'mnuSetting
        '
        Me.mnuSetting.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu設定_格納フォルダ変更, Me.ToolStripSeparator1, Me.mnuSetting最前面表示, Me.mnuSetting自動で番号をカウントアップ, Me.mnuSettingマウス矩形保存, Me.mnuファイル名0詰め2桁, Me.ToolStripMenuItem2, Me.mnuSetttingスタートアップに登録, Me.mnu設定_ショートカットキー変更, Me.ToolStripSeparator3, Me.mnuSettting〇リオ})
        Me.mnuSetting.Name = "mnuSetting"
        Me.mnuSetting.Size = New System.Drawing.Size(57, 20)
        Me.mnuSetting.Text = "設定(&S)"
        '
        'mnu設定_格納フォルダ変更
        '
        Me.mnu設定_格納フォルダ変更.Name = "mnu設定_格納フォルダ変更"
        Me.mnu設定_格納フォルダ変更.Size = New System.Drawing.Size(281, 22)
        Me.mnu設定_格納フォルダ変更.Text = "格納フォルダ変更(&F)..."
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(278, 6)
        '
        'mnuSetting最前面表示
        '
        Me.mnuSetting最前面表示.Name = "mnuSetting最前面表示"
        Me.mnuSetting最前面表示.Size = New System.Drawing.Size(281, 22)
        Me.mnuSetting最前面表示.Text = "最前面に表示(&T)"
        '
        'mnuSetting自動で番号をカウントアップ
        '
        Me.mnuSetting自動で番号をカウントアップ.Name = "mnuSetting自動で番号をカウントアップ"
        Me.mnuSetting自動で番号をカウントアップ.Size = New System.Drawing.Size(281, 22)
        Me.mnuSetting自動で番号をカウントアップ.Text = "自動で番号をカウントアップ(&A)"
        '
        'mnuSettingマウス矩形保存
        '
        Me.mnuSettingマウス矩形保存.Name = "mnuSettingマウス矩形保存"
        Me.mnuSettingマウス矩形保存.Size = New System.Drawing.Size(281, 22)
        Me.mnuSettingマウス矩形保存.Text = "マウスで描いた矩形を保存する(&M)"
        '
        'mnuファイル名0詰め2桁
        '
        Me.mnuファイル名0詰め2桁.Name = "mnuファイル名0詰め2桁"
        Me.mnuファイル名0詰め2桁.Size = New System.Drawing.Size(281, 22)
        Me.mnuファイル名0詰め2桁.Text = "ファイル名の数字部分を0詰め2桁に変換(&P)"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(278, 6)
        '
        'mnuSetttingスタートアップに登録
        '
        Me.mnuSetttingスタートアップに登録.Enabled = False
        Me.mnuSetttingスタートアップに登録.Name = "mnuSetttingスタートアップに登録"
        Me.mnuSetttingスタートアップに登録.Size = New System.Drawing.Size(281, 22)
        Me.mnuSetttingスタートアップに登録.Text = "スタートアップに登録(&R)"
        '
        'mnu設定_ショートカットキー変更
        '
        Me.mnu設定_ショートカットキー変更.Name = "mnu設定_ショートカットキー変更"
        Me.mnu設定_ショートカットキー変更.Size = New System.Drawing.Size(281, 22)
        Me.mnu設定_ショートカットキー変更.Text = "ショートカットキー変更(&S)..."
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(278, 6)
        '
        'mnuSettting〇リオ
        '
        Me.mnuSettting〇リオ.Name = "mnuSettting〇リオ"
        Me.mnuSettting〇リオ.Size = New System.Drawing.Size(281, 22)
        Me.mnuSettting〇リオ.Text = "〇リオ！(&G)"
        '
        'ヘルプToolStripMenuItem
        '
        Me.ヘルプToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuHelp})
        Me.ヘルプToolStripMenuItem.Name = "ヘルプToolStripMenuItem"
        Me.ヘルプToolStripMenuItem.Size = New System.Drawing.Size(65, 20)
        Me.ヘルプToolStripMenuItem.Text = "ヘルプ(&H)"
        '
        'mnuHelp
        '
        Me.mnuHelp.Enabled = False
        Me.mnuHelp.Name = "mnuHelp"
        Me.mnuHelp.Size = New System.Drawing.Size(207, 22)
        Me.mnuHelp.Text = "SaveEvidenceについて(&A)..."
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Location = New System.Drawing.Point(0, 24)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(790, 2)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        '
        'txtFileNameOld
        '
        Me.txtFileNameOld.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtFileNameOld.Font = New System.Drawing.Font("Yu Gothic UI", 9.0!)
        Me.txtFileNameOld.Location = New System.Drawing.Point(66, 28)
        Me.txtFileNameOld.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtFileNameOld.Name = "txtFileNameOld"
        Me.txtFileNameOld.ReadOnly = True
        Me.txtFileNameOld.Size = New System.Drawing.Size(440, 23)
        Me.txtFileNameOld.TabIndex = 4
        Me.txtFileNameOld.Visible = False
        '
        'RightClickContextMenu
        '
        Me.RightClickContextMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.設定ToolStripMenuItem, Me.ToolStripMenuItem6, Me.図形を削除ToolStripMenuItem, Me.図形内のイメージをクリアToolStripMenuItem})
        Me.RightClickContextMenu.Name = "RightClickContextMenu"
        Me.RightClickContextMenu.Size = New System.Drawing.Size(191, 98)
        '
        '図形を削除ToolStripMenuItem
        '
        Me.図形を削除ToolStripMenuItem.Name = "図形を削除ToolStripMenuItem"
        Me.図形を削除ToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.図形を削除ToolStripMenuItem.Text = "図形を削除"
        '
        '図形内のイメージをクリアToolStripMenuItem
        '
        Me.図形内のイメージをクリアToolStripMenuItem.Name = "図形内のイメージをクリアToolStripMenuItem"
        Me.図形内のイメージをクリアToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.図形内のイメージをクリアToolStripMenuItem.Text = "図形内のイメージをクリア"
        '
        'lblFile
        '
        Me.lblFile.AutoSize = True
        Me.lblFile.Font = New System.Drawing.Font("Yu Gothic UI", 9.0!)
        Me.lblFile.ForeColor = System.Drawing.Color.Black
        Me.lblFile.Location = New System.Drawing.Point(2, 31)
        Me.lblFile.Name = "lblFile"
        Me.lblFile.Size = New System.Drawing.Size(65, 15)
        Me.lblFile.TabIndex = 2
        Me.lblFile.Text = "ファイル名："
        '
        'lblPathDisp
        '
        Me.lblPathDisp.BackColor = System.Drawing.Color.Transparent
        Me.lblPathDisp.Font = New System.Drawing.Font("Yu Gothic UI", 9.0!)
        Me.lblPathDisp.Location = New System.Drawing.Point(652, 31)
        Me.lblPathDisp.Name = "lblPathDisp"
        Me.lblPathDisp.Size = New System.Drawing.Size(127, 13)
        Me.lblPathDisp.TabIndex = 7
        Me.lblPathDisp.TabStop = True
        Me.lblPathDisp.Text = "C:\temp\ST"
        '
        'm_Image
        '
        Me.m_Image.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.m_Image.Location = New System.Drawing.Point(5, 52)
        Me.m_Image.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.m_Image.Name = "m_Image"
        Me.m_Image.Size = New System.Drawing.Size(774, 505)
        Me.m_Image.TabIndex = 13
        '
        'm_ImageOld
        '
        Me.m_ImageOld.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.m_ImageOld.BackColor = System.Drawing.SystemColors.ControlDark
        Me.m_ImageOld.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.m_ImageOld.Location = New System.Drawing.Point(5, 52)
        Me.m_ImageOld.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.m_ImageOld.Name = "m_ImageOld"
        Me.m_ImageOld.Size = New System.Drawing.Size(774, 505)
        Me.m_ImageOld.TabIndex = 18
        Me.m_ImageOld.TabStop = False
        Me.m_ImageOld.Tag = "m_ImageOld"
        Me.m_ImageOld.Visible = False
        '
        '設定ToolStripMenuItem
        '
        Me.設定ToolStripMenuItem.Name = "設定ToolStripMenuItem"
        Me.設定ToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.設定ToolStripMenuItem.Text = "設定"
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(187, 6)
        '
        'MainForm
        '
        Me.AcceptButton = Me.btnSave
        Me.AllowDrop = True
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(784, 561)
        Me.Controls.Add(Me.m_Image)
        Me.Controls.Add(Me.lblPathDisp)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.txtFileNameOld)
        Me.Controls.Add(Me.txtFileName)
        Me.Controls.Add(Me.lblFile)
        Me.Controls.Add(Me.lblFolder)
        Me.Controls.Add(Me.menuFile)
        Me.Controls.Add(Me.m_ImageOld)
        Me.Font = New System.Drawing.Font("Meiryo UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.MainMenuStrip = Me.menuFile
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MinimumSize = New System.Drawing.Size(800, 600)
        Me.Name = "MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SaveEvidence"
        Me.menuFile.ResumeLayout(False)
        Me.menuFile.PerformLayout()
        Me.RightClickContextMenu.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtFileName As System.Windows.Forms.TextBox
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents lblFolder As System.Windows.Forms.Label
    Friend WithEvents menuFile As System.Windows.Forms.MenuStrip
    Friend WithEvents mnuファイル As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuFile終了 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents mnuSetting As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSettingマウス矩形保存 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSetting最前面表示 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuSetttingスタートアップに登録 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuエビデンス As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 番号をカウントアップCtToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 前のイメージToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 次のイメージToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripMenuItem5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnu図形 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu図形_削除 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu図形_全て削除 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuエビデンス_クリップボードにコピー As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu設定_格納フォルダ変更 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ヘルプToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSetting自動で番号をカウントアップ As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSettting〇リオ As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents m_ImageOld As SaveEvidence.ScrollPictureBox
    Friend WithEvents txtFileNameOld As System.Windows.Forms.TextBox
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents mnuFile保存 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuエビデンス_クリップボードのイメージを貼り付け As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu図形_最新に反映 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuファイル名0詰め2桁 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFile名前を付けて保存 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuエビデンス_クリップボードにコピー_選択範囲 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents テキスト枠サイズをテキストに合わせるToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RightClickContextMenu As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents 図形を削除ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 図形内のイメージをクリアToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents イメージに外枠を付加ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu設定_ショートカットキー変更 As ToolStripMenuItem
    Friend WithEvents mnu図形_設定 As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As ToolStripSeparator
    Friend WithEvents lblFile As Label
    Friend WithEvents lblPathDisp As LinkLabel
    Friend WithEvents m_Image As ScrollPictureBox
    Friend WithEvents 設定ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem6 As ToolStripSeparator
End Class
