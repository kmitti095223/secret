﻿Option Explicit On

Public Class PropertyForm

    Public m_Data As PropertyClass

    Private Sub PropertyForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
         PropertyGrid1.SelectedObject = m_Data
    End Sub

    Private Sub btnOK_Click(sender As System.Object, e As System.EventArgs) Handles btnOK.Click
        Close()
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click

        Dim tmp As New PropertyClass(False)

        m_Data.四角の太さ = tmp.四角の太さ
        m_Data.四角の色 = tmp.四角の色

        m_Data.テキスト枠の太さ = tmp.テキスト枠の太さ
        m_Data.テキスト枠の色 = tmp.テキスト枠の色
        m_Data.テキスト枠の文字色 = tmp.テキスト枠の文字色
        m_Data.テキスト枠の背景色 = tmp.テキスト枠の背景色
        m_Data.テキスト枠の透明度 = tmp.テキスト枠の透明度
        m_Data.テキスト枠のフォント = tmp.テキスト枠のフォント

        m_Data.矢印線の太さ = tmp.矢印線の太さ
        m_Data.矢印線の色 = tmp.矢印線の色

        PropertyGrid1.Refresh()

    End Sub

End Class