﻿Option Explicit On
Option Strict On

Imports System.IO

Public Class RenameForm

    '''============================================================================================
    ''' <summary>
    ''' フォームロード処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    '''============================================================================================
    Private Sub MainForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        txtOld.Text = My.Settings.Rename変更前
        txtNew.Text = My.Settings.Rename変更後

        Dim arrCmds() As String = System.Environment.GetCommandLineArgs()
        For i As Integer = 1 To arrCmds.Length - 1
            AddFilePath(arrCmds(i))
        Next

        UpdateListView()

    End Sub

    '''============================================================================================
    ''' <summary>
    ''' フォームクローズ処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    '''============================================================================================
    Private Sub MainForm_FormClosing(sender As System.Object, e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        My.Settings.Rename変更前 = txtOld.Text
        My.Settings.Rename変更後 = txtNew.Text
        My.Settings.Save()
    End Sub

    '''============================================================================================
    ''' <summary>
    ''' ドラッグドロップのファイル判定処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    '''============================================================================================
    Private Sub lstFiles_DragEnter( _
            ByVal sender As Object, ByVal e As DragEventArgs) Handles lstFiles.DragEnter

        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            e.Effect = DragDropEffects.Copy
        Else
            e.Effect = DragDropEffects.None
        End If

    End Sub

    '''============================================================================================
    ''' <summary>
    ''' ドラッグ処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    '''============================================================================================
    Private Sub lstFiles_DragDrop( _
            ByVal sender As Object, ByVal e As DragEventArgs) Handles lstFiles.DragDrop

        lbl説明.Visible = False
        lstFiles.Items.Clear()

        Dim arrFileNames As String() = CType(e.Data.GetData(DataFormats.FileDrop, False), String())

        For i As Integer = 0 To arrFileNames.Length - 2
            For j As Integer = i + 1 To arrFileNames.Length - 1
                If String.Compare(arrFileNames(i), arrFileNames(j), True) > 0 Then
                    Dim sWk As String = arrFileNames(i)
                    arrFileNames(i) = arrFileNames(j)
                    arrFileNames(j) = sWk
                End If
            Next
        Next

        For Each sFilePath In arrFileNames
            AddFilePath(sFilePath)
        Next

        UpdateListView()

    End Sub

    '''============================================================================================
    ''' <summary>
    ''' フォームリサイズ処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    '''============================================================================================
    Private Sub MainForm_Resize(sender As System.Object, e As System.EventArgs) Handles MyBase.Resize
        lstFiles.Columns(0).Width = CInt((lstFiles.Width - 22) / 2)
        lstFiles.Columns(1).Width = lstFiles.Columns(0).Width
    End Sub

    '''============================================================================================
    ''' <summary>
    ''' テキストボックス変更処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    '''============================================================================================
    Private Sub txt_TextChanged(sender As System.Object, e As System.EventArgs) _
        Handles txtOld.TextChanged, txtNew.TextChanged
        UpdateListView()
    End Sub

    '''============================================================================================
    ''' <summary>
    ''' リストビュー更新処理
    ''' </summary>
    ''' <remarks></remarks>
    '''============================================================================================
    Private Sub UpdateListView()

        For Each item As ListViewItem In lstFiles.Items
            If txtOld.Text <> "" Then
                item.SubItems(1).Text = item.SubItems(0).Text.Replace(txtOld.Text, txtNew.Text)
            Else
                item.SubItems(1).Text = item.SubItems(0).Text
            End If
            If item.SubItems(1).Text <> item.SubItems(0).Text Then
                item.SubItems(1).ForeColor = Color.Red
            Else
                item.SubItems(1).ForeColor = Color.Black
            End If
        Next

    End Sub

    '''============================================================================================
    ''' <summary>
    ''' リストビューファイル追加処理
    ''' </summary>
    ''' <param name="sFilePath"></param>
    ''' <remarks></remarks>
    '''============================================================================================
    Private Sub AddFilePath(ByVal sFilePath As String)
        Dim item As ListViewItem = lstFiles.Items.Add(Path.GetFileName(sFilePath))
        item.Tag = sFilePath
        item.SubItems.Add("")
        item.UseItemStyleForSubItems = False
    End Sub

    '''============================================================================================
    ''' <summary>
    ''' リネーム処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    '''============================================================================================
    Private Sub btnRename_Click(sender As System.Object, e As System.EventArgs) Handles btnRename.Click

        If lstFiles.Items.Count = 0 Then
            Exit Sub
        End If

        Dim rc As MsgBoxResult = _
            MsgBox("リネームを行います。よろしいですか？", MsgBoxStyle.Exclamation Or MsgBoxStyle.YesNo)
        If rc <> vbYes Then
            Exit Sub
        End If

        For Each item As ListViewItem In lstFiles.Items

            If item.SubItems(1).Text = item.SubItems(0).Text Then
                Continue For
            End If

            Try
                File.Move(Path.GetDirectoryName(item.Tag.ToString) & "\" & item.SubItems(0).Text, _
                          Path.GetDirectoryName(item.Tag.ToString) & "\" & item.SubItems(1).Text)
                item.SubItems(0).Text = item.SubItems(1).Text
                item.SubItems(0).ForeColor = Color.Blue
            Catch
                MsgBox("ファイルのリネームに失敗しました。" & vbCrLf & _
                       "　変更前：" & item.SubItems(0).Text & vbCrLf & _
                       "　変更後：" & item.SubItems(1).Text & vbCrLf, MsgBoxStyle.Exclamation)
            End Try

        Next

        UpdateListView()
        MsgBox("終了しました。", MsgBoxStyle.Information)

    End Sub

    '''============================================================================================
    ''' <summary>
    ''' テキストボックス選択処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    '''============================================================================================
    Private Sub txt_Enter(sender As System.Object, e As System.EventArgs) Handles txtOld.Enter, txtNew.Enter
        CType(sender, TextBox).SelectAll()
    End Sub

End Class
