﻿Public Class ShortcutKeySettingForm

    Private Declare Function RegisterHotKey Lib "user32" (ByVal hwnd As IntPtr, ByVal id As Integer,
                                                          ByVal fsModifiers As Integer, ByVal vk As Keys) As Integer
    Private Declare Function UnregisterHotKey Lib "user32" (ByVal hwnd As IntPtr, ByVal id As Integer) As Integer
    Private Declare Function GlobalAddAtom Lib "kernel32" Alias "GlobalAddAtomA" (ByVal lpString As String) As Short
    Private Declare Function GlobalDeleteAtom Lib "kernel32" (ByVal nAtom As Short) As Short

    Const SHORTCUT_MAX As Integer = 12
    Const NO_SELECT As String = "(指定なし)"

    Public Shared m_ShortcutKey(SHORTCUT_MAX) As ShortcutKey
    ' 0:ウィンドウ1
    ' 1:ウィンドウ2
    ' 2:ウィンドウ3(自動保存)
    ' 3:ウィンドウ1
    ' 4:ウィンドウ2
    ' 5:ウィンドウ3(自動保存)
    ' 6:クリップボード1
    ' 7:クリップボード2
    ' 8:クリップボード3(自動保存)
    ' 9:書式削除
    ' 10:パスオープン
    ' 11:パスオープン2

    Public Shared g_lstHotkeyID As New List(Of Short)

    Private m_lstModifierKey As List(Of ComboBox)
    Private m_lstVirtualKey As List(Of ComboBox)

    Public Shared Sub Initialize()

        ' ホットキーを登録する。
        m_ShortcutKey(0) = New ShortcutKey(My.Settings.ショートカットキーウィンドウ1)
        m_ShortcutKey(1) = New ShortcutKey(My.Settings.ショートカットキーウィンドウ2)
        m_ShortcutKey(2) = New ShortcutKey(My.Settings.ショートカットキーウィンドウ3)
        m_ShortcutKey(3) = New ShortcutKey(My.Settings.ショートカットキー全体1)
        m_ShortcutKey(4) = New ShortcutKey(My.Settings.ショートカットキー全体2)
        m_ShortcutKey(5) = New ShortcutKey(My.Settings.ショートカットキー全体3)
        m_ShortcutKey(6) = New ShortcutKey(My.Settings.ショートカットキークリップボード1)
        m_ShortcutKey(7) = New ShortcutKey(My.Settings.ショートカットキークリップボード2)
        m_ShortcutKey(8) = New ShortcutKey(My.Settings.ショートカットキークリップボード3)
        m_ShortcutKey(9) = New ShortcutKey(My.Settings.ショートカットキー書式削除)
        m_ShortcutKey(10) = New ShortcutKey(My.Settings.ショートカットキーパスオープン)
        m_ShortcutKey(11) = New ShortcutKey(My.Settings.ショートカットキーパスオープン2)
        m_ShortcutKey(12) = New ShortcutKey("Ctrl+Alt+A")

    End Sub

    Public Shared Sub RegisterHotKey()
        ' ホットキーを登録する
        For i As Integer = 0 To m_ShortcutKey.Length - 1
            If m_ShortcutKey(i).GetKeyValue <> 0 Then
                RegHotKey(m_ShortcutKey(i).GetModKey, m_ShortcutKey(i).GetVirtualKey)
            End If
        Next
    End Sub

    Public Shared Sub UnregisterHotKey()
        ' ホットキーの登録を解除し、アトムを削除する
        For i As Integer = 0 To g_lstHotkeyID.Count - 1
            UnregisterHotKey(StartForm.Handle, g_lstHotkeyID(i))
            GlobalDeleteAtom(g_lstHotkeyID(i))
        Next
        g_lstHotkeyID.Clear()
    End Sub

    Private Sub ShortcutKeySettingForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        m_lstModifierKey = New List(Of ComboBox)
        m_lstVirtualKey = New List(Of ComboBox)

        For i As Integer = 0 To SHORTCUT_MAX

            ' 仮想キー
            m_lstVirtualKey.Add(FindControlByFieldName("cboVirtualKey" + i.ToString()))
            m_lstVirtualKey(i).Text = m_ShortcutKey(i).GetVirtualKeyStr

            ' 併用キー
            m_lstModifierKey.Add(FindControlByFieldName("cboModifierKey" + i.ToString()))
            AddHandler m_lstModifierKey(i).SelectedIndexChanged, AddressOf ModifierKey_SelectedIndexChanged

            Dim s As String = m_ShortcutKey(i).GetModKeyStr()
            m_lstModifierKey(i).Text = s
            If m_lstModifierKey(i).SelectedIndex < 0 Then
                m_lstModifierKey(i).Text = NO_SELECT
            End If

        Next

    End Sub

    Private Sub ModifierKey_SelectedIndexChanged(sender As Object, e As EventArgs)

        Dim nCtrlIndex As Integer = -1

        For i As Integer = 0 To m_lstModifierKey.Count - 1
            If m_lstModifierKey(i).Equals(sender) Then
                nCtrlIndex = i
                Exit For
            End If
        Next

        If sender.Text <> NO_SELECT Then
            m_lstVirtualKey(nCtrlIndex).Enabled = True
        Else
            m_lstVirtualKey(nCtrlIndex).Enabled = False
            m_lstVirtualKey(nCtrlIndex).Text = ""
        End If

    End Sub

    Private Sub btn設定_Click(sender As Object, e As EventArgs) Handles btn設定.Click

        For i As Integer = 0 To SHORTCUT_MAX

            If sender.Text <> NO_SELECT Then
                m_ShortcutKey(i).SetKeyStr(m_lstModifierKey(i).Text & "+" & m_lstVirtualKey(i).Text)
            Else
                m_ShortcutKey(i).SetKeyStr("")
            End If

        Next

        UnregisterHotKey()
        RegisterHotKey()

        My.Settings.ショートカットキーウィンドウ1 = m_ShortcutKey(0).GetKeyStr()
        My.Settings.ショートカットキーウィンドウ2 = m_ShortcutKey(1).GetKeyStr()
        My.Settings.ショートカットキーウィンドウ3 = m_ShortcutKey(2).GetKeyStr()
        My.Settings.ショートカットキー全体1 = m_ShortcutKey(3).GetKeyStr()
        My.Settings.ショートカットキー全体2 = m_ShortcutKey(4).GetKeyStr()
        My.Settings.ショートカットキー全体3 = m_ShortcutKey(5).GetKeyStr()
        My.Settings.ショートカットキークリップボード1 = m_ShortcutKey(6).GetKeyStr()
        My.Settings.ショートカットキークリップボード2 = m_ShortcutKey(7).GetKeyStr()
        My.Settings.ショートカットキークリップボード3 = m_ShortcutKey(8).GetKeyStr()
        My.Settings.ショートカットキー書式削除 = m_ShortcutKey(9).GetKeyStr()
        My.Settings.ショートカットキーパスオープン = m_ShortcutKey(10).GetKeyStr()
        My.Settings.ショートカットキーパスオープン2 = m_ShortcutKey(11).GetKeyStr()
        My.Settings.Save()

        Close()

    End Sub

    Public Function GetKeyValue(ByVal nIndex As Integer) As Integer
        Return m_ShortcutKey(nIndex).GetKeyValue()
    End Function

    Private Sub btnキャンセル_Click(sender As Object, e As EventArgs) Handles btnキャンセル.Click
        Close()
    End Sub

    Private Sub btn標準に戻す_Click(sender As Object, e As EventArgs) Handles btn標準に戻す.Click

    End Sub

    ' ホットキー登録
    Private Shared Sub RegHotKey(ByVal fsModifiers As Integer, ByVal vk As Keys)
        Dim hotkeyIndex As Integer = g_lstHotkeyID.Count + 1
        Dim hotkeyID As Short = GlobalAddAtom("GlobalHotKey" & hotkeyIndex.ToString & StartForm.GetHashCode().ToString())
        RegisterHotKey(StartForm.Handle, hotkeyID, fsModifiers, vk)
        g_lstHotkeyID.Add(hotkeyIndex)

    End Sub

    ''' <summary>
    ''' フォームに配置されているコントロールを名前で探す
    ''' （フォームクラスのフィールドをフィールド名で探す）
    ''' </summary>
    ''' <param name="name">コントロール（フィールド）の名前</param>
    ''' <returns>見つかった時は、コントロールのオブジェクト。
    ''' 見つからなかった時は、null(VB.NETではNothing)。</returns>
    Private Function FindControlByFieldName(ByVal name As String) As Object
        'まずプロパティ名を探し、見つからなければフィールド名を探す
        Dim t As System.Type = Me.GetType()

        Dim pi As System.Reflection.PropertyInfo =
            t.GetProperty(name,
                System.Reflection.BindingFlags.Public Or
                System.Reflection.BindingFlags.NonPublic Or
                System.Reflection.BindingFlags.Instance Or
                System.Reflection.BindingFlags.DeclaredOnly)

        If Not pi Is Nothing Then
            Return pi.GetValue(Me, Nothing)
        End If

        Dim fi As System.Reflection.FieldInfo =
            t.GetField(name,
                System.Reflection.BindingFlags.Public Or
                System.Reflection.BindingFlags.NonPublic Or
                System.Reflection.BindingFlags.Instance Or
                System.Reflection.BindingFlags.DeclaredOnly)

        If fi Is Nothing Then
            Return Nothing
        End If

        Return fi.GetValue(Me)
    End Function

End Class