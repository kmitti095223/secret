﻿Option Explicit On

Public Class PictureBoxEx

    Public m_ScreenBmp As Bitmap = Nothing

    Dim m_Trackers As New TrackerMng

    Dim m_表示倍率 As Double = 0
    Dim m_表示位置X座標 As Integer = 0

    Public m_bDrawMouseRect As Boolean = True

    Private m_Mario As Mario = Nothing

    Public Event ChangeFileName(ByVal sFilePath As String)

    Public Sub SetBmp(ByVal bmp As Bitmap)

        m_ScreenBmp = New Bitmap(bmp)
        m_Trackers.DeleteAll()
        m_Trackers.SetImageSize(New Size(m_ScreenBmp.Width, m_ScreenBmp.Height))
        Redraw()

    End Sub

    Public Sub Clear()
        Image = Nothing
    End Sub

    Public Sub Save(ByVal sFilePath As String)
        Call Image.Save(sFilePath, System.Drawing.Imaging.ImageFormat.Png)

        ' ファイル名を保存する。
        sFilePath = sFilePath.Substring(0, sFilePath.LastIndexOf("."))

    End Sub

    Public Sub SetMouseRect(ByVal sMouseRect As String)
        m_Trackers.SetString(sMouseRect)
    End Sub

    Public Function GetMouseRect() As String
        Return m_Trackers.GetString
    End Function


    Public Sub DeleteTracker(ByVal nIndex As Integer)
        m_Trackers.Delete(nIndex)
        Redraw()
    End Sub

    Public Sub DeleteAllTracker()
        m_Trackers.DeleteAll()
        Redraw()
    End Sub

    Public Function GetTrackerCount()
        Return m_Trackers.GetCount
    End Function

    Public Function GetTracker(ByVal nIndex As Integer) As TrackerItem
        Return m_Trackers.GetAt(nIndex)
    End Function

    Public Sub Redraw()

        If m_ScreenBmp Is Nothing Then
            Exit Sub
        End If
        Image = m_ScreenBmp.Clone()

        If ((m_ScreenBmp.Width < ClientSize.Width) And
            (m_ScreenBmp.Height < ClientSize.Height)) Then
            SizeMode = PictureBoxSizeMode.CenterImage
        Else
            SizeMode = PictureBoxSizeMode.Zoom
        End If


        Dim g As Graphics = Graphics.FromImage(Image)
        m_Trackers.Draw(g)

        ' リソースを解放する
        g.Dispose()
        g = Nothing

        Refresh()

        System.GC.Collect()

    End Sub

    Private Sub picImage_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseDown

        ' マウス矩形描画無しの場合ここで終了する。
        If Not m_bDrawMouseRect Then
            Exit Sub
        End If

        If m_Trackers.MouseDown(ScreenPosToImagePos(New Point(e.X, e.Y)), e.Button) Then
            Redraw()
        End If


    End Sub

    Private Sub picImage_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseMove

        ' マウス矩形描画無しの場合ここで終了する。
        If Not m_bDrawMouseRect Then
            Exit Sub
        End If

        ' イメージなしの場合はここで終了する。
        If Image Is Nothing Then
            Exit Sub
        End If

        Dim pos As Point = ScreenPosToImagePos(New Point(e.X, e.Y))

        If m_Trackers.MouseMove(pos) Then
            Redraw()
        Else
            Me.Cursor = m_Trackers.GetMouseCursor(pos)
        End If

    End Sub

    Private Sub picImage_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseUp

        ' マウス矩形描画無しの場合ここで終了する。
        If Not m_bDrawMouseRect Then
            Exit Sub
        End If


        If m_Trackers.MouseUp(ScreenPosToImagePos(New Point(e.X, e.Y))) Then
            Redraw()
        End If

    End Sub


    Private Sub picImage_MouseDoubleClick(sender As System.Object, e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseDoubleClick

        ' マウス矩形描画無しの場合ここで終了する。
        If Not m_bDrawMouseRect Then
            Exit Sub
        End If

        If m_Trackers.MouseUp(ScreenPosToImagePos(New Point(e.X, e.Y))) Then
            Redraw()
        End If


        If m_Trackers.MouseDoubleClick(ScreenPosToImagePos(New Point(e.X, e.Y)), e.Button) Then
            Redraw()
            Return
        End If


        'If (Control.ModifierKeys And Keys.Control) = Keys.Control Then

        '    ' クリック位置に四角を書く
        '    Const RECT_SIZE As Integer = 24
        '    Dim pos As Point = ScreenPosToImagePos(New Point(e.X, e.Y))
        '    pos -= New Point(1, 1) ' 微調整 (ちょっとずらした方がしっくりくる)
        '    m_Trackers.Add(New Rectangle(pos.X - (RECT_SIZE / 2), pos.Y - (RECT_SIZE / 2), RECT_SIZE, RECT_SIZE))

        'Else
        ' クリック位置のアイテムを選択！

        Dim bmp As New Bitmap(Image)

        Dim displayedImageSize As Size = ClientSize
        Dim originalImageSize As Size = Image.Size

        ' 縮小比率を計算
        Dim scaleX As Double = originalImageSize.Width / displayedImageSize.Width
        Dim scaleY As Double = originalImageSize.Height / displayedImageSize.Height

        ' 表示画像のクリックされた位置を元の画像の座標に変換
        Dim pos As Point = ScreenPosToImagePos(New Point(e.X, e.Y))

        Dim rect As Rectangle
        If ImageRect.CheckRect(bmp, pos, rect) Then

            Debug.Print(rect.ToString)
            'rect = ImageRectToScreenRect(rect)

            m_Trackers.Add(rect)

            Return
        Else

            ' クリック位置に四角を書く
            Const RECT_SIZE As Integer = 24
            pos = ScreenPosToImagePos(New Point(e.X, e.Y))
            ' pos -= New Point(1, 1) ' 微調整 (ちょっとずらした方がしっくりくる)
            m_Trackers.Add(New Rectangle(pos.X - (RECT_SIZE / 2), pos.Y - (RECT_SIZE / 2), RECT_SIZE, RECT_SIZE))

        End If
        'End If

    End Sub

    ' 矩形補正
    Private Sub NormalizeRect(ByRef rect As Rectangle)

        Dim tmpRect As Rectangle = rect
        rect = New Rectangle(Math.Min(tmpRect.Left, tmpRect.Right),
                               Math.Min(tmpRect.Top, tmpRect.Bottom),
                               Math.Max(tmpRect.Left, tmpRect.Right) - Math.Min(tmpRect.Left, tmpRect.Right),
                               Math.Max(tmpRect.Top, tmpRect.Bottom) - Math.Min(tmpRect.Top, tmpRect.Bottom))
    End Sub

    ' 座標変換処理(ピクチャーボックス上の座標→イメージ上の座標)
    Public Function ScreenPosToImagePos(ByVal pos As Point) As Point

        ' 表示倍率と表示位置を計算
        Dim dScale As Double = Math.Min(CDbl(ClientRectangle.Width) / CDbl(Image.Width),
                                         CDbl(ClientRectangle.Height) / CDbl(Image.Height))

        ' ピクチャーボックスよりイメージが小さい場合は100％として扱う。
        If SizeMode = PictureBoxSizeMode.CenterImage Then
            dScale = 1
        End If

        Dim ShowImageSize As Size = New Size(Image.Width * dScale, Image.Height * dScale)
        Dim LeftTop As Point
        LeftTop.X = IIf(ShowImageSize.Width < ClientRectangle.Width, (ClientRectangle.Width - ShowImageSize.Width) / 2, 0)
        LeftTop.Y = IIf(ShowImageSize.Height < ClientRectangle.Height, (ClientRectangle.Height - ShowImageSize.Height) / 2, 0)

        ' マウスクリック座標をイメージ上の座標に変換して返却。
        Return New Point((pos.X - LeftTop.X) / dScale, (pos.Y - LeftTop.Y) / dScale)

    End Function

    ' 座標変換処理(ピクチャーボックス上の座標→イメージ上の座標)
    Public Function ScreenRectToImageRect(ByVal rect As Rectangle) As Rectangle

        ' 動作確認未
        Debug.Assert(False)
        Dim lt As Point = ScreenPosToImagePos(LeftTop(rect))
        Dim rb As Point = ScreenPosToImagePos(RightBottom(rect))

        Return New Rectangle(lt.X, lt.Y, rb.X - lt.X, rb.Y - lt.Y)

    End Function

    ' 座標変換処理(ピクチャーボックス上の座標→イメージ上の座標)
    Public Function ImagePosToScreenPos(ByVal pos As Point) As Point
        On Error Resume Next ' 2020.12.09 何故かImage=Nothingになって落ちたので追加

        ' 2022.05.15 上でもやっぱり落ちたので追加
        If Image Is Nothing Then
            Return New Point(0, 0)
        End If

        ' 表示倍率と表示位置を計算
        Dim dScale As Double = Math.Min(CDbl(ClientRectangle.Width) / CDbl(Image.Width),
                                         CDbl(ClientRectangle.Height) / CDbl(Image.Height))

        ' ピクチャーボックスよりイメージが小さい場合は100％として扱う。
        If SizeMode = PictureBoxSizeMode.CenterImage Then
            dScale = 1
        End If

        Dim ShowImageSize As Size = New Size(Image.Width * dScale, Image.Height * dScale)
        Dim LeftTop As Point
        LeftTop.X = IIf(ShowImageSize.Width < ClientRectangle.Width, (ClientRectangle.Width - ShowImageSize.Width) / 2, 0)
        LeftTop.Y = IIf(ShowImageSize.Height < ClientRectangle.Height, (ClientRectangle.Height - ShowImageSize.Height) / 2, 0)

        ' マウスクリック座標をイメージ上の座標に変換して返却。
        Return New Point((pos.X * dScale) + LeftTop.X, (pos.Y * dScale) + LeftTop.Y)

    End Function

    ' 座標変換処理(ピクチャーボックス上の座標→イメージ上の座標)
    Public Function ImageRectToScreenRect(ByVal rect As Rectangle) As Rectangle

        Dim lt As Point = ImagePosToScreenPos(LeftTop(rect))
        Dim rb As Point = ImagePosToScreenPos(RightBottom(rect))

        Return New Rectangle(lt.X, lt.Y, rb.X - lt.X, rb.Y - lt.Y)

    End Function

    Public Function GetScale() As Double
        Return Math.Min(CDbl(ClientRectangle.Width) / CDbl(Image.Width),
                                         CDbl(ClientRectangle.Height) / CDbl(Image.Height))
    End Function

    Private Sub MainForm_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint
        If m_Mario IsNot Nothing Then
            m_Mario.Paint(e.Graphics)
        End If
    End Sub

    Public Sub ShowMario(ByVal bMode As Boolean)
        m_Mario = New Mario
        m_Mario.Initialize(Me, bMode, Me)
    End Sub


    Public Sub CloseMario()
        If m_Mario IsNot Nothing Then
            m_Mario.Terminate()
            m_Mario = Nothing
        End If
    End Sub

    Public Sub MyKeyDown(ByVal KeyCode As Keys, ByVal bCtrl As Boolean, ByVal bAlt As Boolean, ByVal bShift As Boolean)

        If m_Mario IsNot Nothing Then
            m_Mario.KeyDown(KeyCode)
        End If

        ' 矩形移動
        If m_Mario Is Nothing Then

            Dim x As Integer = 0
            Dim y As Integer = 0

            Select Case KeyCode
                Case Keys.Left
                    x = -1
                Case Keys.Right
                    x = 1
                Case Keys.Up
                    y = -1
                Case Keys.Down
                    y = 1
            End Select

            If (x <> 0) Or (y <> 0) Then

                Dim bRedraw As Boolean = False

                If bShift And bCtrl And (Not bAlt) Then
                    bRedraw = m_Trackers.ResizeRect(x, y)
                ElseIf (Not bShift) And bCtrl And (Not bAlt) Then
                    bRedraw = m_Trackers.MoveRect(x, y)
                End If

                If bRedraw Then
                    Redraw()
                End If
            End If

        End If

    End Sub

    Public Sub MyKeyUp(ByVal KeyCode As Keys)
        If m_Mario IsNot Nothing Then
            m_Mario.KeyUp(KeyCode)
        End If
    End Sub
    Public Sub MyLostFocus()
        If m_Mario IsNot Nothing Then
            m_Mario.LostFocus()
        End If
    End Sub


    Private Sub PictureBoxEx_DragEnter(sender As Object, e As DragEventArgs) Handles Me.DragEnter

        'コントロール内にドラッグされたとき実行される
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then

            Dim sFilePath As String() = CType(e.Data.GetData(DataFormats.FileDrop, False), String())
            Select Case System.IO.Path.GetExtension(sFilePath(0)).ToLower
                Case ".bmp", ".jpg", ".png", ".jpeg", ".tif", ".tiff"
                    e.Effect = DragDropEffects.Copy
                Case Else
            End Select

        Else
            'ファイル以外は受け付けない
            e.Effect = DragDropEffects.None
        End If

    End Sub

    Private Sub PictureBoxEx_DragDrop(sender As Object, e As DragEventArgs) Handles Me.DragDrop

        Try
            'コントロール内にドロップされたとき実行される
            'ドロップされたすべてのファイル名を取得する
            Dim sFilePath As String() = CType(e.Data.GetData(DataFormats.FileDrop, False), String())
            RaiseEvent ChangeFileName(sFilePath(0))

            Dim bmp As Bitmap = CreateImage(sFilePath(0))
            SetBmp(bmp)

        Catch
        End Try

    End Sub


    'http://dobon.net/vb/dotnet/graphics/drawpicture2.html
    ''' <summary>
    ''' 指定したファイルをロックせずに、System.Drawing.Imageを作成する。
    ''' </summary>
    ''' <param name="filename">作成元のファイルのパス</param>
    ''' <returns>作成したSystem.Drawing.Image。</returns>
    Public Shared Function CreateImage(ByVal filename As String) As Bitmap
        Dim fs As New System.IO.FileStream(filename, System.IO.FileMode.Open, System.IO.FileAccess.Read)
        Dim img As Bitmap = Bitmap.FromStream(fs)
        fs.Close()
        Return img
    End Function

    Public Function GetSelectecRectImage() As System.Drawing.Image

        If m_Trackers.GetCount() = 0 Then
            Return Image
        End If

        Dim bmp As Bitmap = Image
        Dim rect As Rectangle = m_Trackers.GetSelectedRect()
        Dim LineWidth As Integer = Math.Ceiling(g_Property.四角の太さ / 2)
        rect = New Rectangle(rect.Left + LineWidth,
                             rect.Top + LineWidth,
                             rect.Width - LineWidth * 2,
                             rect.Height - LineWidth * 2)

        Return bmp.Clone(rect, bmp.PixelFormat)

    End Function

    Public Sub Add外枠()

        Dim g As Graphics = Graphics.FromImage(m_ScreenBmp)
        Dim rect As New Rectangle(0, 0, m_ScreenBmp.Width - 1, m_ScreenBmp.Height - 1)

        Dim p As New Pen(Brushes.Gainsboro)
        g.DrawRectangle(p, rect)

        Dim rect2 As New Rectangle(0, 0, m_ScreenBmp.Width - 2, m_ScreenBmp.Height - 2)
        Dim p2 As New Pen(Brushes.DimGray)
        g.DrawRectangle(p2, rect2)

        g.FillRectangle(Brushes.White, m_ScreenBmp.Width - 1, 0, 1, 1)
        g.FillRectangle(Brushes.White, 0, m_ScreenBmp.Height - 1, 1, 1)

        g.Dispose()
        Redraw()

    End Sub

    Private Sub PictureBoxEx_Resize(sender As Object, e As EventArgs) Handles Me.Resize

        If m_ScreenBmp Is Nothing Then
            Exit Sub
        End If

        If ((m_ScreenBmp.Width < ClientSize.Width) And
            (m_ScreenBmp.Height < ClientSize.Height)) Then
            SizeMode = PictureBoxSizeMode.CenterImage
        Else
            SizeMode = PictureBoxSizeMode.Zoom
        End If

    End Sub

    Public Function IsChange() As Boolean
        Return m_Trackers.ischange
    End Function


    Public Function RemoveBitmapRegion(ByVal topY As Integer, ByVal bottomY As Integer) As Bitmap

        Dim bmp As Bitmap = m_ScreenBmp

        ' 引数チェック
        If bmp Is Nothing OrElse topY < 0 OrElse bottomY >= bmp.Height OrElse topY > bottomY Then
            Return Nothing
        End If

        Dim grayBandHeight As Integer = 20
        Dim deletedHeight As Integer = bottomY - topY + 1
        Dim remainingHeight As Integer = bmp.Height - deletedHeight

        ' 削除により全体が消える場合
        If remainingHeight <= 0 Then
            Return Nothing
        End If

        ' グレー領域を挿入する条件
        Dim insertGray = (topY > 0 AndAlso bottomY < bmp.Height - 1)

        ' 新しい画像の高さ
        Dim newHeight As Integer = remainingHeight + If(insertGray, grayBandHeight, 0)
        Dim newBmp As New Bitmap(bmp.Width, newHeight)

        Using g As Graphics = Graphics.FromImage(newBmp)
            Dim yOffset As Integer = 0

            ' 上部を描画
            If topY > 0 Then
                Dim srcRect As New Rectangle(0, 0, bmp.Width, topY)
                Dim destPoint As New Point(0, 0)
                g.DrawImage(bmp, destPoint.X, destPoint.Y, srcRect, GraphicsUnit.Pixel)
                yOffset += topY
            End If

            ' グレー帯を描画（条件付き）
            If insertGray Then
                g.FillRectangle(Brushes.Gray, 0, yOffset, bmp.Width, grayBandHeight)
                yOffset += grayBandHeight
            End If

            ' 下部を描画
            If bottomY < bmp.Height - 1 Then
                Dim bottomPartHeight As Integer = bmp.Height - (bottomY + 1)
                Dim srcRect As New Rectangle(0, bottomY + 1, bmp.Width, bottomPartHeight)
                Dim destPoint As New Point(0, yOffset)
                g.DrawImage(bmp, destPoint.X, destPoint.Y, srcRect, GraphicsUnit.Pixel)
            End If
        End Using

        Return newBmp
    End Function


End Class
