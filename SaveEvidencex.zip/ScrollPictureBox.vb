﻿Public Class ScrollPictureBox

    Public Event ChangeFileName(ByVal sFilePath As String)
    Private m_BitmapSize As Size = Nothing

    Private Sub m_Image_ChangeFileName(sFilePath As String) Handles m_PictureBox.ChangeFileName
        ScrollPictureBox_Resize(Nothing, Nothing)
        RaiseEvent ChangeFileName(sFilePath)
    End Sub

    Public Sub SetBmp(ByVal bmp As Bitmap)

        m_BitmapSize = bmp.Size()
        AutoScrollPosition = New Point(0, 0)
        ScrollPictureBox_Resize(Nothing, Nothing)

        m_PictureBox.SetBmp(bmp)

    End Sub

    Private Sub ScrollPictureBox_Resize(sender As Object, e As EventArgs) Handles Me.Resize

        If m_BitmapSize = Nothing Then
            Exit Sub
        End If

        ' 描画を停止
        SuspendLayout()

        Me.AutoScroll = False
        If m_BitmapSize.Height > (GetMaxScreenHeight() * 1.1) Then
            ' 縦スクロールモード
            m_PictureBox.Dock = DockStyle.None

            ' 表示倍率と表示位置を計算
            Dim panelEffectiveWidth As Integer
            panelEffectiveWidth = ClientSize.Width
            If Not VerticalScroll.Visible Then
                panelEffectiveWidth -= SystemInformation.VerticalScrollBarWidth
            End If

            Dim dScale As Double = CDbl(panelEffectiveWidth) / CDbl(m_BitmapSize.Width)

            ' ピクチャーボックスよりイメージが小さい場合は100％として扱う。
            If dScale > 1 Then
                dScale = 1
            End If

            m_PictureBox.Width = panelEffectiveWidth
            m_PictureBox.Height = CInt(m_BitmapSize.Height * dScale) ' 高さを計算

            Me.AutoScroll = True
        Else
            ' フィットモード
            m_PictureBox.Dock = DockStyle.Fill
            m_PictureBox.Width = Me.ClientSize.Width
        End If

        ' 描画を再開
        ResumeLayout()

    End Sub

    Public Function GetImage() As Image
        Return m_PictureBox.Image
    End Function

    Public Function GetScreenBmp() As Bitmap
        Return m_PictureBox.m_ScreenBmp
    End Function

    Public Sub SetDrawMouseRect(ByVal b As Boolean)
        ' m_PictureBox.m_bDrawMouseRect = b
    End Sub

    ' Clear()
    Public Sub Clear()
        m_PictureBox.Clear()  ' 子クラスのClear()を呼び出し
    End Sub

    ' Save()
    Public Sub Save(ByVal sFilePath As String)
        m_PictureBox.Save(sFilePath)  ' 子クラスのSave()を呼び出し
    End Sub

    ' SetMouseRect()
    Public Sub SetMouseRect(ByVal sMouseRect As String)
        m_PictureBox.SetMouseRect(sMouseRect)  ' 子クラスのSetMouseRect()を呼び出し
    End Sub

    ' GetMouseRect()
    Public Function GetMouseRect() As String
        Return m_PictureBox.GetMouseRect()  ' 子クラスのGetMouseRect()を呼び出し
    End Function

    ' DeleteTracker()
    Public Sub DeleteTracker(ByVal nIndex As Integer)
        m_PictureBox.DeleteTracker(nIndex)  ' 子クラスのDeleteTracker()を呼び出し
    End Sub

    ' DeleteAllTracker()
    Public Sub DeleteAllTracker()
        m_PictureBox.DeleteAllTracker()  ' 子クラスのDeleteAllTracker()を呼び出し
    End Sub

    Public Function GetTrackerCount()
        Return m_PictureBox.GetTrackerCount
    End Function

    Public Function GetTracker(ByVal nIndex As Integer) As TrackerItem
        Return m_PictureBox.GetTracker(nIndex)
    End Function


    ' Redraw()
    Public Sub Redraw()
        m_PictureBox.Redraw()  ' 子クラスのRedraw()を呼び出し
    End Sub

    ' ScreenPosToImagePos()
    Public Function ScreenPosToImagePos(ByVal pos As Point) As Point
        Return m_PictureBox.ScreenPosToImagePos(pos)  ' 子クラスのScreenPosToImagePos()を呼び出し
    End Function

    ' ScreenRectToImageRect()
    Public Function ScreenRectToImageRect(ByVal rect As Rectangle) As Rectangle
        Return m_PictureBox.ScreenRectToImageRect(rect)  ' 子クラスのScreenRectToImageRect()を呼び出し
    End Function

    ' ImagePosToScreenPos()
    Public Function ImagePosToScreenPos(ByVal pos As Point) As Point
        Return m_PictureBox.ImagePosToScreenPos(pos)  ' 子クラスのImagePosToScreenPos()を呼び出し
    End Function

    ' ImageRectToScreenRect()
    Public Function ImageRectToScreenRect(ByVal rect As Rectangle) As Rectangle
        Return m_PictureBox.ImageRectToScreenRect(rect)  ' 子クラスのImageRectToScreenRect()を呼び出し
    End Function

    ' GetScale()
    Public Function GetScale() As Double
        Return m_PictureBox.GetScale()  ' 子クラスのGetScale()を呼び出し
    End Function


    ' ShowMario()
    Public Sub ShowMario(ByVal bMode As Boolean)
        m_PictureBox.ShowMario(bMode)  ' 子クラスのShowMario()を呼び出し
    End Sub

    ' CloseMario()
    Public Sub CloseMario()
        m_PictureBox.CloseMario()  ' 子クラスのCloseMario()を呼び出し
    End Sub

    ' MyKeyDown()
    Public Sub MyKeyDown(ByVal KeyCode As Keys, ByVal bCtrl As Boolean, ByVal bAlt As Boolean, ByVal bShift As Boolean)
        m_PictureBox.MyKeyDown(KeyCode, bCtrl, bAlt, bShift)  ' 子クラスのMyKeyDown()を呼び出し
    End Sub

    ' MyKeyUp()
    Public Sub MyKeyUp(ByVal KeyCode As Keys)
        m_PictureBox.MyKeyUp(KeyCode)  ' 子クラスのMyKeyUp()を呼び出し
    End Sub

    ' MyLostFocus()
    Public Sub MyLostFocus()
        m_PictureBox.MyLostFocus()  ' 子クラスのMyLostFocus()を呼び出し
    End Sub

    ' CreateImage()
    Public Shared Function CreateImage(ByVal filename As String) As Bitmap
        Return PictureBoxEx.CreateImage(filename)  ' 子クラスのCreateImage()を呼び出し
    End Function

    ' GetSelectecRectImage()
    Public Function GetSelectecRectImage() As System.Drawing.Image
        Return m_PictureBox.GetSelectecRectImage()  ' 子クラスのGetSelectecRectImage()を呼び出し
    End Function

    ' Add外枠()
    Public Sub Add外枠()
        m_PictureBox.Add外枠()  ' 子クラスのAdd外枠()を呼び出し
    End Sub

    Public Function IsChange() As Boolean
        Return m_PictureBox.GetTrackerCount() > 0
    End Function

    Public Function RemoveBitmapRegionWithGray(ByVal rect As Rectangle) As Boolean

        Dim bmp As Bitmap = m_PictureBox.RemoveBitmapRegion(rect.Top, rect.Bottom)

        If bmp IsNot Nothing Then



            ' スクロール位置を保存
            Dim savedScroll As Point = AutoScrollPosition

            SetBmp(bmp)

            ' スクロール位置を復元（注意：負の値で指定する）
            AutoScrollPosition = New Point(-savedScroll.X, -savedScroll.Y)

            Return True
        Else
            Return False
        End If
    End Function

End Class
