﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ShortcutKeySettingForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
		Me.GroupBox1 = New System.Windows.Forms.GroupBox()
		Me.Label4 = New System.Windows.Forms.Label()
		Me.Label3 = New System.Windows.Forms.Label()
		Me.Label11 = New System.Windows.Forms.Label()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.Label14 = New System.Windows.Forms.Label()
		Me.Label13 = New System.Windows.Forms.Label()
		Me.Label12 = New System.Windows.Forms.Label()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.cboVirtualKey2 = New System.Windows.Forms.ComboBox()
		Me.cboVirtualKey1 = New System.Windows.Forms.ComboBox()
		Me.cboVirtualKey0 = New System.Windows.Forms.ComboBox()
		Me.cboModifierKey2 = New System.Windows.Forms.ComboBox()
		Me.cboModifierKey1 = New System.Windows.Forms.ComboBox()
		Me.cboModifierKey0 = New System.Windows.Forms.ComboBox()
		Me.GroupBox2 = New System.Windows.Forms.GroupBox()
		Me.Label15 = New System.Windows.Forms.Label()
		Me.Label16 = New System.Windows.Forms.Label()
		Me.Label17 = New System.Windows.Forms.Label()
		Me.Label18 = New System.Windows.Forms.Label()
		Me.Label19 = New System.Windows.Forms.Label()
		Me.Label20 = New System.Windows.Forms.Label()
		Me.Label21 = New System.Windows.Forms.Label()
		Me.Label22 = New System.Windows.Forms.Label()
		Me.cboVirtualKey5 = New System.Windows.Forms.ComboBox()
		Me.cboVirtualKey4 = New System.Windows.Forms.ComboBox()
		Me.cboVirtualKey3 = New System.Windows.Forms.ComboBox()
		Me.cboModifierKey5 = New System.Windows.Forms.ComboBox()
		Me.cboModifierKey4 = New System.Windows.Forms.ComboBox()
		Me.cboModifierKey3 = New System.Windows.Forms.ComboBox()
		Me.GroupBox3 = New System.Windows.Forms.GroupBox()
		Me.Label5 = New System.Windows.Forms.Label()
		Me.Label6 = New System.Windows.Forms.Label()
		Me.Label7 = New System.Windows.Forms.Label()
		Me.Label8 = New System.Windows.Forms.Label()
		Me.Label9 = New System.Windows.Forms.Label()
		Me.Label10 = New System.Windows.Forms.Label()
		Me.Label23 = New System.Windows.Forms.Label()
		Me.Label24 = New System.Windows.Forms.Label()
		Me.cboVirtualKey8 = New System.Windows.Forms.ComboBox()
		Me.cboVirtualKey7 = New System.Windows.Forms.ComboBox()
		Me.cboVirtualKey6 = New System.Windows.Forms.ComboBox()
		Me.cboModifierKey8 = New System.Windows.Forms.ComboBox()
		Me.cboModifierKey7 = New System.Windows.Forms.ComboBox()
		Me.cboModifierKey6 = New System.Windows.Forms.ComboBox()
		Me.GroupBox4 = New System.Windows.Forms.GroupBox()
		Me.Label29 = New System.Windows.Forms.Label()
		Me.Label26 = New System.Windows.Forms.Label()
		Me.Label27 = New System.Windows.Forms.Label()
		Me.Label28 = New System.Windows.Forms.Label()
		Me.Label25 = New System.Windows.Forms.Label()
		Me.Label30 = New System.Windows.Forms.Label()
		Me.Label31 = New System.Windows.Forms.Label()
		Me.Label32 = New System.Windows.Forms.Label()
		Me.cboVirtualKey11 = New System.Windows.Forms.ComboBox()
		Me.cboVirtualKey10 = New System.Windows.Forms.ComboBox()
		Me.cboModifierKey11 = New System.Windows.Forms.ComboBox()
		Me.cboVirtualKey9 = New System.Windows.Forms.ComboBox()
		Me.cboModifierKey10 = New System.Windows.Forms.ComboBox()
		Me.cboModifierKey9 = New System.Windows.Forms.ComboBox()
		Me.btn設定 = New System.Windows.Forms.Button()
		Me.btnキャンセル = New System.Windows.Forms.Button()
		Me.btn標準に戻す = New System.Windows.Forms.Button()
		Me.cboModifierKey12 = New System.Windows.Forms.ComboBox()
		Me.cboVirtualKey12 = New System.Windows.Forms.ComboBox()
		Me.Label33 = New System.Windows.Forms.Label()
		Me.Label34 = New System.Windows.Forms.Label()
		Me.GroupBox1.SuspendLayout()
		Me.GroupBox2.SuspendLayout()
		Me.GroupBox3.SuspendLayout()
		Me.GroupBox4.SuspendLayout()
		Me.SuspendLayout()
		'
		'GroupBox1
		'
		Me.GroupBox1.Controls.Add(Me.Label4)
		Me.GroupBox1.Controls.Add(Me.Label3)
		Me.GroupBox1.Controls.Add(Me.Label11)
		Me.GroupBox1.Controls.Add(Me.Label1)
		Me.GroupBox1.Controls.Add(Me.Label14)
		Me.GroupBox1.Controls.Add(Me.Label13)
		Me.GroupBox1.Controls.Add(Me.Label12)
		Me.GroupBox1.Controls.Add(Me.Label2)
		Me.GroupBox1.Controls.Add(Me.cboVirtualKey2)
		Me.GroupBox1.Controls.Add(Me.cboVirtualKey1)
		Me.GroupBox1.Controls.Add(Me.cboVirtualKey0)
		Me.GroupBox1.Controls.Add(Me.cboModifierKey2)
		Me.GroupBox1.Controls.Add(Me.cboModifierKey1)
		Me.GroupBox1.Controls.Add(Me.cboModifierKey0)
		Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
		Me.GroupBox1.Name = "GroupBox1"
		Me.GroupBox1.Size = New System.Drawing.Size(377, 117)
		Me.GroupBox1.TabIndex = 0
		Me.GroupBox1.TabStop = False
		Me.GroupBox1.Text = "ウィンドウをキャプチャ"
		'
		'Label4
		'
		Me.Label4.AutoSize = True
		Me.Label4.Location = New System.Drawing.Point(11, 85)
		Me.Label4.Name = "Label4"
		Me.Label4.Size = New System.Drawing.Size(91, 12)
		Me.Label4.TabIndex = 10
		Me.Label4.Text = "キー3 (自動保存)"
		'
		'Label3
		'
		Me.Label3.AutoSize = True
		Me.Label3.Location = New System.Drawing.Point(11, 59)
		Me.Label3.Name = "Label3"
		Me.Label3.Size = New System.Drawing.Size(31, 12)
		Me.Label3.TabIndex = 6
		Me.Label3.Text = "キー2"
		'
		'Label11
		'
		Me.Label11.Location = New System.Drawing.Point(292, 15)
		Me.Label11.Name = "Label11"
		Me.Label11.Size = New System.Drawing.Size(69, 12)
		Me.Label11.TabIndex = 1
		Me.Label11.Text = "キー"
		Me.Label11.TextAlign = System.Drawing.ContentAlignment.TopCenter
		'
		'Label1
		'
		Me.Label1.Location = New System.Drawing.Point(169, 15)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(102, 12)
		Me.Label1.TabIndex = 0
		Me.Label1.Text = "併用キー"
		Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
		'
		'Label14
		'
		Me.Label14.AutoSize = True
		Me.Label14.Location = New System.Drawing.Point(277, 85)
		Me.Label14.Name = "Label14"
		Me.Label14.Size = New System.Drawing.Size(11, 12)
		Me.Label14.TabIndex = 12
		Me.Label14.Text = "+"
		'
		'Label13
		'
		Me.Label13.AutoSize = True
		Me.Label13.Location = New System.Drawing.Point(277, 59)
		Me.Label13.Name = "Label13"
		Me.Label13.Size = New System.Drawing.Size(11, 12)
		Me.Label13.TabIndex = 8
		Me.Label13.Text = "+"
		'
		'Label12
		'
		Me.Label12.AutoSize = True
		Me.Label12.Location = New System.Drawing.Point(277, 33)
		Me.Label12.Name = "Label12"
		Me.Label12.Size = New System.Drawing.Size(11, 12)
		Me.Label12.TabIndex = 4
		Me.Label12.Text = "+"
		'
		'Label2
		'
		Me.Label2.AutoSize = True
		Me.Label2.Location = New System.Drawing.Point(11, 33)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(31, 12)
		Me.Label2.TabIndex = 2
		Me.Label2.Text = "キー1"
		'
		'cboVirtualKey2
		'
		Me.cboVirtualKey2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboVirtualKey2.FormattingEnabled = True
		Me.cboVirtualKey2.Items.AddRange(New Object() {"", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "*", "+", "-"})
		Me.cboVirtualKey2.Location = New System.Drawing.Point(294, 82)
		Me.cboVirtualKey2.Name = "cboVirtualKey2"
		Me.cboVirtualKey2.Size = New System.Drawing.Size(67, 20)
		Me.cboVirtualKey2.TabIndex = 13
		'
		'cboVirtualKey1
		'
		Me.cboVirtualKey1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboVirtualKey1.FormattingEnabled = True
		Me.cboVirtualKey1.Items.AddRange(New Object() {"", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "*", "+", "-"})
		Me.cboVirtualKey1.Location = New System.Drawing.Point(294, 56)
		Me.cboVirtualKey1.Name = "cboVirtualKey1"
		Me.cboVirtualKey1.Size = New System.Drawing.Size(67, 20)
		Me.cboVirtualKey1.TabIndex = 9
		'
		'cboVirtualKey0
		'
		Me.cboVirtualKey0.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboVirtualKey0.FormattingEnabled = True
		Me.cboVirtualKey0.Items.AddRange(New Object() {"", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "*", "+", "-"})
		Me.cboVirtualKey0.Location = New System.Drawing.Point(294, 30)
		Me.cboVirtualKey0.Name = "cboVirtualKey0"
		Me.cboVirtualKey0.Size = New System.Drawing.Size(67, 20)
		Me.cboVirtualKey0.TabIndex = 5
		'
		'cboModifierKey2
		'
		Me.cboModifierKey2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboModifierKey2.FormattingEnabled = True
		Me.cboModifierKey2.Items.AddRange(New Object() {"Ctrl", "Shift", "Alt", "Ctrl+Shift", "Ctrl+Alt", "Shift+Alt", "Ctrl+Shift+Alt", "(指定なし)"})
		Me.cboModifierKey2.Location = New System.Drawing.Point(171, 82)
		Me.cboModifierKey2.Name = "cboModifierKey2"
		Me.cboModifierKey2.Size = New System.Drawing.Size(100, 20)
		Me.cboModifierKey2.TabIndex = 11
		'
		'cboModifierKey1
		'
		Me.cboModifierKey1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboModifierKey1.FormattingEnabled = True
		Me.cboModifierKey1.Items.AddRange(New Object() {"Ctrl", "Shift", "Alt", "Ctrl+Shift", "Ctrl+Alt", "Shift+Alt", "Ctrl+Shift+Alt", "(指定なし)"})
		Me.cboModifierKey1.Location = New System.Drawing.Point(171, 56)
		Me.cboModifierKey1.Name = "cboModifierKey1"
		Me.cboModifierKey1.Size = New System.Drawing.Size(100, 20)
		Me.cboModifierKey1.TabIndex = 7
		'
		'cboModifierKey0
		'
		Me.cboModifierKey0.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboModifierKey0.FormattingEnabled = True
		Me.cboModifierKey0.Items.AddRange(New Object() {"Ctrl", "Shift", "Alt", "Ctrl+Shift", "Ctrl+Alt", "Shift+Alt", "Ctrl+Shift+Alt", "(指定なし)"})
		Me.cboModifierKey0.Location = New System.Drawing.Point(171, 30)
		Me.cboModifierKey0.Name = "cboModifierKey0"
		Me.cboModifierKey0.Size = New System.Drawing.Size(100, 20)
		Me.cboModifierKey0.TabIndex = 3
		'
		'GroupBox2
		'
		Me.GroupBox2.Controls.Add(Me.Label15)
		Me.GroupBox2.Controls.Add(Me.Label16)
		Me.GroupBox2.Controls.Add(Me.Label17)
		Me.GroupBox2.Controls.Add(Me.Label18)
		Me.GroupBox2.Controls.Add(Me.Label19)
		Me.GroupBox2.Controls.Add(Me.Label20)
		Me.GroupBox2.Controls.Add(Me.Label21)
		Me.GroupBox2.Controls.Add(Me.Label22)
		Me.GroupBox2.Controls.Add(Me.cboVirtualKey5)
		Me.GroupBox2.Controls.Add(Me.cboVirtualKey4)
		Me.GroupBox2.Controls.Add(Me.cboVirtualKey3)
		Me.GroupBox2.Controls.Add(Me.cboModifierKey5)
		Me.GroupBox2.Controls.Add(Me.cboModifierKey4)
		Me.GroupBox2.Controls.Add(Me.cboModifierKey3)
		Me.GroupBox2.Location = New System.Drawing.Point(12, 135)
		Me.GroupBox2.Name = "GroupBox2"
		Me.GroupBox2.Size = New System.Drawing.Size(377, 117)
		Me.GroupBox2.TabIndex = 1
		Me.GroupBox2.TabStop = False
		Me.GroupBox2.Text = "スクリーン全体をキャプチャ"
		'
		'Label15
		'
		Me.Label15.AutoSize = True
		Me.Label15.Location = New System.Drawing.Point(11, 85)
		Me.Label15.Name = "Label15"
		Me.Label15.Size = New System.Drawing.Size(91, 12)
		Me.Label15.TabIndex = 10
		Me.Label15.Text = "キー3 (自動保存)"
		'
		'Label16
		'
		Me.Label16.AutoSize = True
		Me.Label16.Location = New System.Drawing.Point(11, 59)
		Me.Label16.Name = "Label16"
		Me.Label16.Size = New System.Drawing.Size(31, 12)
		Me.Label16.TabIndex = 6
		Me.Label16.Text = "キー2"
		'
		'Label17
		'
		Me.Label17.Location = New System.Drawing.Point(292, 15)
		Me.Label17.Name = "Label17"
		Me.Label17.Size = New System.Drawing.Size(69, 12)
		Me.Label17.TabIndex = 1
		Me.Label17.Text = "キー"
		Me.Label17.TextAlign = System.Drawing.ContentAlignment.TopCenter
		'
		'Label18
		'
		Me.Label18.Location = New System.Drawing.Point(169, 15)
		Me.Label18.Name = "Label18"
		Me.Label18.Size = New System.Drawing.Size(102, 12)
		Me.Label18.TabIndex = 0
		Me.Label18.Text = "併用キー"
		Me.Label18.TextAlign = System.Drawing.ContentAlignment.TopCenter
		'
		'Label19
		'
		Me.Label19.AutoSize = True
		Me.Label19.Location = New System.Drawing.Point(277, 85)
		Me.Label19.Name = "Label19"
		Me.Label19.Size = New System.Drawing.Size(11, 12)
		Me.Label19.TabIndex = 12
		Me.Label19.Text = "+"
		'
		'Label20
		'
		Me.Label20.AutoSize = True
		Me.Label20.Location = New System.Drawing.Point(277, 59)
		Me.Label20.Name = "Label20"
		Me.Label20.Size = New System.Drawing.Size(11, 12)
		Me.Label20.TabIndex = 8
		Me.Label20.Text = "+"
		'
		'Label21
		'
		Me.Label21.AutoSize = True
		Me.Label21.Location = New System.Drawing.Point(277, 33)
		Me.Label21.Name = "Label21"
		Me.Label21.Size = New System.Drawing.Size(11, 12)
		Me.Label21.TabIndex = 4
		Me.Label21.Text = "+"
		'
		'Label22
		'
		Me.Label22.AutoSize = True
		Me.Label22.Location = New System.Drawing.Point(11, 33)
		Me.Label22.Name = "Label22"
		Me.Label22.Size = New System.Drawing.Size(31, 12)
		Me.Label22.TabIndex = 2
		Me.Label22.Text = "キー1"
		'
		'cboVirtualKey5
		'
		Me.cboVirtualKey5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboVirtualKey5.FormattingEnabled = True
		Me.cboVirtualKey5.Items.AddRange(New Object() {"", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "*", "+", "-"})
		Me.cboVirtualKey5.Location = New System.Drawing.Point(294, 82)
		Me.cboVirtualKey5.Name = "cboVirtualKey5"
		Me.cboVirtualKey5.Size = New System.Drawing.Size(67, 20)
		Me.cboVirtualKey5.TabIndex = 13
		'
		'cboVirtualKey4
		'
		Me.cboVirtualKey4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboVirtualKey4.FormattingEnabled = True
		Me.cboVirtualKey4.Items.AddRange(New Object() {"", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "*", "+", "-"})
		Me.cboVirtualKey4.Location = New System.Drawing.Point(294, 56)
		Me.cboVirtualKey4.Name = "cboVirtualKey4"
		Me.cboVirtualKey4.Size = New System.Drawing.Size(67, 20)
		Me.cboVirtualKey4.TabIndex = 9
		'
		'cboVirtualKey3
		'
		Me.cboVirtualKey3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboVirtualKey3.FormattingEnabled = True
		Me.cboVirtualKey3.Items.AddRange(New Object() {"", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "*", "+", "-"})
		Me.cboVirtualKey3.Location = New System.Drawing.Point(294, 30)
		Me.cboVirtualKey3.Name = "cboVirtualKey3"
		Me.cboVirtualKey3.Size = New System.Drawing.Size(67, 20)
		Me.cboVirtualKey3.TabIndex = 5
		'
		'cboModifierKey5
		'
		Me.cboModifierKey5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboModifierKey5.FormattingEnabled = True
		Me.cboModifierKey5.Items.AddRange(New Object() {"Ctrl", "Shift", "Alt", "Ctrl+Shift", "Ctrl+Alt", "Shift+Alt", "Ctrl+Shift+Alt", "(指定なし)"})
		Me.cboModifierKey5.Location = New System.Drawing.Point(171, 82)
		Me.cboModifierKey5.Name = "cboModifierKey5"
		Me.cboModifierKey5.Size = New System.Drawing.Size(100, 20)
		Me.cboModifierKey5.TabIndex = 11
		'
		'cboModifierKey4
		'
		Me.cboModifierKey4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboModifierKey4.FormattingEnabled = True
		Me.cboModifierKey4.Items.AddRange(New Object() {"Ctrl", "Shift", "Alt", "Ctrl+Shift", "Ctrl+Alt", "Shift+Alt", "Ctrl+Shift+Alt", "(指定なし)"})
		Me.cboModifierKey4.Location = New System.Drawing.Point(171, 56)
		Me.cboModifierKey4.Name = "cboModifierKey4"
		Me.cboModifierKey4.Size = New System.Drawing.Size(100, 20)
		Me.cboModifierKey4.TabIndex = 7
		'
		'cboModifierKey3
		'
		Me.cboModifierKey3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboModifierKey3.FormattingEnabled = True
		Me.cboModifierKey3.Items.AddRange(New Object() {"Ctrl", "Shift", "Alt", "Ctrl+Shift", "Ctrl+Alt", "Shift+Alt", "Ctrl+Shift+Alt", "(指定なし)"})
		Me.cboModifierKey3.Location = New System.Drawing.Point(171, 30)
		Me.cboModifierKey3.Name = "cboModifierKey3"
		Me.cboModifierKey3.Size = New System.Drawing.Size(100, 20)
		Me.cboModifierKey3.TabIndex = 3
		'
		'GroupBox3
		'
		Me.GroupBox3.Controls.Add(Me.Label5)
		Me.GroupBox3.Controls.Add(Me.Label6)
		Me.GroupBox3.Controls.Add(Me.Label7)
		Me.GroupBox3.Controls.Add(Me.Label8)
		Me.GroupBox3.Controls.Add(Me.Label9)
		Me.GroupBox3.Controls.Add(Me.Label10)
		Me.GroupBox3.Controls.Add(Me.Label23)
		Me.GroupBox3.Controls.Add(Me.Label24)
		Me.GroupBox3.Controls.Add(Me.cboVirtualKey8)
		Me.GroupBox3.Controls.Add(Me.cboVirtualKey7)
		Me.GroupBox3.Controls.Add(Me.cboVirtualKey6)
		Me.GroupBox3.Controls.Add(Me.cboModifierKey8)
		Me.GroupBox3.Controls.Add(Me.cboModifierKey7)
		Me.GroupBox3.Controls.Add(Me.cboModifierKey6)
		Me.GroupBox3.Location = New System.Drawing.Point(12, 258)
		Me.GroupBox3.Name = "GroupBox3"
		Me.GroupBox3.Size = New System.Drawing.Size(377, 117)
		Me.GroupBox3.TabIndex = 2
		Me.GroupBox3.TabStop = False
		Me.GroupBox3.Text = "クリップボードのイメージを取得"
		'
		'Label5
		'
		Me.Label5.AutoSize = True
		Me.Label5.Location = New System.Drawing.Point(11, 85)
		Me.Label5.Name = "Label5"
		Me.Label5.Size = New System.Drawing.Size(91, 12)
		Me.Label5.TabIndex = 10
		Me.Label5.Text = "キー3 (自動保存)"
		'
		'Label6
		'
		Me.Label6.AutoSize = True
		Me.Label6.Location = New System.Drawing.Point(11, 59)
		Me.Label6.Name = "Label6"
		Me.Label6.Size = New System.Drawing.Size(31, 12)
		Me.Label6.TabIndex = 6
		Me.Label6.Text = "キー2"
		'
		'Label7
		'
		Me.Label7.Location = New System.Drawing.Point(292, 15)
		Me.Label7.Name = "Label7"
		Me.Label7.Size = New System.Drawing.Size(69, 12)
		Me.Label7.TabIndex = 1
		Me.Label7.Text = "キー"
		Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopCenter
		'
		'Label8
		'
		Me.Label8.Location = New System.Drawing.Point(169, 15)
		Me.Label8.Name = "Label8"
		Me.Label8.Size = New System.Drawing.Size(102, 12)
		Me.Label8.TabIndex = 0
		Me.Label8.Text = "併用キー"
		Me.Label8.TextAlign = System.Drawing.ContentAlignment.TopCenter
		'
		'Label9
		'
		Me.Label9.AutoSize = True
		Me.Label9.Location = New System.Drawing.Point(277, 85)
		Me.Label9.Name = "Label9"
		Me.Label9.Size = New System.Drawing.Size(11, 12)
		Me.Label9.TabIndex = 12
		Me.Label9.Text = "+"
		'
		'Label10
		'
		Me.Label10.AutoSize = True
		Me.Label10.Location = New System.Drawing.Point(277, 59)
		Me.Label10.Name = "Label10"
		Me.Label10.Size = New System.Drawing.Size(11, 12)
		Me.Label10.TabIndex = 8
		Me.Label10.Text = "+"
		'
		'Label23
		'
		Me.Label23.AutoSize = True
		Me.Label23.Location = New System.Drawing.Point(277, 33)
		Me.Label23.Name = "Label23"
		Me.Label23.Size = New System.Drawing.Size(11, 12)
		Me.Label23.TabIndex = 4
		Me.Label23.Text = "+"
		'
		'Label24
		'
		Me.Label24.AutoSize = True
		Me.Label24.Location = New System.Drawing.Point(11, 33)
		Me.Label24.Name = "Label24"
		Me.Label24.Size = New System.Drawing.Size(31, 12)
		Me.Label24.TabIndex = 2
		Me.Label24.Text = "キー1"
		'
		'cboVirtualKey8
		'
		Me.cboVirtualKey8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboVirtualKey8.FormattingEnabled = True
		Me.cboVirtualKey8.Items.AddRange(New Object() {"", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "*", "+", "-"})
		Me.cboVirtualKey8.Location = New System.Drawing.Point(294, 82)
		Me.cboVirtualKey8.Name = "cboVirtualKey8"
		Me.cboVirtualKey8.Size = New System.Drawing.Size(67, 20)
		Me.cboVirtualKey8.TabIndex = 13
		'
		'cboVirtualKey7
		'
		Me.cboVirtualKey7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboVirtualKey7.FormattingEnabled = True
		Me.cboVirtualKey7.Items.AddRange(New Object() {"", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "*", "+", "-"})
		Me.cboVirtualKey7.Location = New System.Drawing.Point(294, 56)
		Me.cboVirtualKey7.Name = "cboVirtualKey7"
		Me.cboVirtualKey7.Size = New System.Drawing.Size(67, 20)
		Me.cboVirtualKey7.TabIndex = 9
		'
		'cboVirtualKey6
		'
		Me.cboVirtualKey6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboVirtualKey6.FormattingEnabled = True
		Me.cboVirtualKey6.Items.AddRange(New Object() {"", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "*", "+", "-"})
		Me.cboVirtualKey6.Location = New System.Drawing.Point(294, 30)
		Me.cboVirtualKey6.Name = "cboVirtualKey6"
		Me.cboVirtualKey6.Size = New System.Drawing.Size(67, 20)
		Me.cboVirtualKey6.TabIndex = 5
		'
		'cboModifierKey8
		'
		Me.cboModifierKey8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboModifierKey8.FormattingEnabled = True
		Me.cboModifierKey8.Items.AddRange(New Object() {"Ctrl", "Shift", "Alt", "Ctrl+Shift", "Ctrl+Alt", "Shift+Alt", "Ctrl+Shift+Alt", "(指定なし)"})
		Me.cboModifierKey8.Location = New System.Drawing.Point(171, 82)
		Me.cboModifierKey8.Name = "cboModifierKey8"
		Me.cboModifierKey8.Size = New System.Drawing.Size(100, 20)
		Me.cboModifierKey8.TabIndex = 11
		'
		'cboModifierKey7
		'
		Me.cboModifierKey7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboModifierKey7.FormattingEnabled = True
		Me.cboModifierKey7.Items.AddRange(New Object() {"Ctrl", "Shift", "Alt", "Ctrl+Shift", "Ctrl+Alt", "Shift+Alt", "Ctrl+Shift+Alt", "(指定なし)"})
		Me.cboModifierKey7.Location = New System.Drawing.Point(171, 56)
		Me.cboModifierKey7.Name = "cboModifierKey7"
		Me.cboModifierKey7.Size = New System.Drawing.Size(100, 20)
		Me.cboModifierKey7.TabIndex = 7
		'
		'cboModifierKey6
		'
		Me.cboModifierKey6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboModifierKey6.FormattingEnabled = True
		Me.cboModifierKey6.Items.AddRange(New Object() {"Ctrl", "Shift", "Alt", "Ctrl+Shift", "Ctrl+Alt", "Shift+Alt", "Ctrl+Shift+Alt", "(指定なし)"})
		Me.cboModifierKey6.Location = New System.Drawing.Point(171, 30)
		Me.cboModifierKey6.Name = "cboModifierKey6"
		Me.cboModifierKey6.Size = New System.Drawing.Size(100, 20)
		Me.cboModifierKey6.TabIndex = 3
		'
		'GroupBox4
		'
		Me.GroupBox4.Controls.Add(Me.Label34)
		Me.GroupBox4.Controls.Add(Me.Label29)
		Me.GroupBox4.Controls.Add(Me.Label26)
		Me.GroupBox4.Controls.Add(Me.Label27)
		Me.GroupBox4.Controls.Add(Me.Label28)
		Me.GroupBox4.Controls.Add(Me.Label33)
		Me.GroupBox4.Controls.Add(Me.Label25)
		Me.GroupBox4.Controls.Add(Me.Label30)
		Me.GroupBox4.Controls.Add(Me.Label31)
		Me.GroupBox4.Controls.Add(Me.Label32)
		Me.GroupBox4.Controls.Add(Me.cboVirtualKey12)
		Me.GroupBox4.Controls.Add(Me.cboVirtualKey11)
		Me.GroupBox4.Controls.Add(Me.cboVirtualKey10)
		Me.GroupBox4.Controls.Add(Me.cboModifierKey12)
		Me.GroupBox4.Controls.Add(Me.cboModifierKey11)
		Me.GroupBox4.Controls.Add(Me.cboVirtualKey9)
		Me.GroupBox4.Controls.Add(Me.cboModifierKey10)
		Me.GroupBox4.Controls.Add(Me.cboModifierKey9)
		Me.GroupBox4.Location = New System.Drawing.Point(12, 381)
		Me.GroupBox4.Name = "GroupBox4"
		Me.GroupBox4.Size = New System.Drawing.Size(377, 146)
		Me.GroupBox4.TabIndex = 3
		Me.GroupBox4.TabStop = False
		Me.GroupBox4.Text = "その他"
		'
		'Label29
		'
		Me.Label29.AutoSize = True
		Me.Label29.Location = New System.Drawing.Point(11, 85)
		Me.Label29.Name = "Label29"
		Me.Label29.Size = New System.Drawing.Size(147, 12)
		Me.Label29.TabIndex = 6
		Me.Label29.Text = "パスオープン (親フォルダを開く)"
		'
		'Label26
		'
		Me.Label26.AutoSize = True
		Me.Label26.Location = New System.Drawing.Point(11, 59)
		Me.Label26.Name = "Label26"
		Me.Label26.Size = New System.Drawing.Size(61, 12)
		Me.Label26.TabIndex = 6
		Me.Label26.Text = "パスオープン"
		'
		'Label27
		'
		Me.Label27.Location = New System.Drawing.Point(292, 15)
		Me.Label27.Name = "Label27"
		Me.Label27.Size = New System.Drawing.Size(69, 12)
		Me.Label27.TabIndex = 1
		Me.Label27.Text = "キー"
		Me.Label27.TextAlign = System.Drawing.ContentAlignment.TopCenter
		'
		'Label28
		'
		Me.Label28.Location = New System.Drawing.Point(169, 15)
		Me.Label28.Name = "Label28"
		Me.Label28.Size = New System.Drawing.Size(102, 12)
		Me.Label28.TabIndex = 0
		Me.Label28.Text = "併用キー"
		Me.Label28.TextAlign = System.Drawing.ContentAlignment.TopCenter
		'
		'Label25
		'
		Me.Label25.AutoSize = True
		Me.Label25.Location = New System.Drawing.Point(277, 85)
		Me.Label25.Name = "Label25"
		Me.Label25.Size = New System.Drawing.Size(11, 12)
		Me.Label25.TabIndex = 8
		Me.Label25.Text = "+"
		'
		'Label30
		'
		Me.Label30.AutoSize = True
		Me.Label30.Location = New System.Drawing.Point(277, 59)
		Me.Label30.Name = "Label30"
		Me.Label30.Size = New System.Drawing.Size(11, 12)
		Me.Label30.TabIndex = 8
		Me.Label30.Text = "+"
		'
		'Label31
		'
		Me.Label31.AutoSize = True
		Me.Label31.Location = New System.Drawing.Point(277, 33)
		Me.Label31.Name = "Label31"
		Me.Label31.Size = New System.Drawing.Size(11, 12)
		Me.Label31.TabIndex = 4
		Me.Label31.Text = "+"
		'
		'Label32
		'
		Me.Label32.AutoSize = True
		Me.Label32.Location = New System.Drawing.Point(11, 33)
		Me.Label32.Name = "Label32"
		Me.Label32.Size = New System.Drawing.Size(53, 12)
		Me.Label32.TabIndex = 2
		Me.Label32.Text = "書式削除"
		'
		'cboVirtualKey11
		'
		Me.cboVirtualKey11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboVirtualKey11.FormattingEnabled = True
		Me.cboVirtualKey11.Items.AddRange(New Object() {"", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "*", "+", "-"})
		Me.cboVirtualKey11.Location = New System.Drawing.Point(294, 82)
		Me.cboVirtualKey11.Name = "cboVirtualKey11"
		Me.cboVirtualKey11.Size = New System.Drawing.Size(67, 20)
		Me.cboVirtualKey11.TabIndex = 11
		'
		'cboVirtualKey10
		'
		Me.cboVirtualKey10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboVirtualKey10.FormattingEnabled = True
		Me.cboVirtualKey10.Items.AddRange(New Object() {"", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "*", "+", "-"})
		Me.cboVirtualKey10.Location = New System.Drawing.Point(294, 56)
		Me.cboVirtualKey10.Name = "cboVirtualKey10"
		Me.cboVirtualKey10.Size = New System.Drawing.Size(67, 20)
		Me.cboVirtualKey10.TabIndex = 9
		'
		'cboModifierKey11
		'
		Me.cboModifierKey11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboModifierKey11.FormattingEnabled = True
		Me.cboModifierKey11.Items.AddRange(New Object() {"Ctrl", "Shift", "Alt", "Ctrl+Shift", "Ctrl+Alt", "Shift+Alt", "Ctrl+Shift+Alt", "(指定なし)"})
		Me.cboModifierKey11.Location = New System.Drawing.Point(171, 82)
		Me.cboModifierKey11.Name = "cboModifierKey11"
		Me.cboModifierKey11.Size = New System.Drawing.Size(100, 20)
		Me.cboModifierKey11.TabIndex = 10
		'
		'cboVirtualKey9
		'
		Me.cboVirtualKey9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboVirtualKey9.FormattingEnabled = True
		Me.cboVirtualKey9.Items.AddRange(New Object() {"", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "*", "+", "-"})
		Me.cboVirtualKey9.Location = New System.Drawing.Point(294, 30)
		Me.cboVirtualKey9.Name = "cboVirtualKey9"
		Me.cboVirtualKey9.Size = New System.Drawing.Size(67, 20)
		Me.cboVirtualKey9.TabIndex = 5
		'
		'cboModifierKey10
		'
		Me.cboModifierKey10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboModifierKey10.FormattingEnabled = True
		Me.cboModifierKey10.Items.AddRange(New Object() {"Ctrl", "Shift", "Alt", "Ctrl+Shift", "Ctrl+Alt", "Shift+Alt", "Ctrl+Shift+Alt", "(指定なし)"})
		Me.cboModifierKey10.Location = New System.Drawing.Point(171, 56)
		Me.cboModifierKey10.Name = "cboModifierKey10"
		Me.cboModifierKey10.Size = New System.Drawing.Size(100, 20)
		Me.cboModifierKey10.TabIndex = 7
		'
		'cboModifierKey9
		'
		Me.cboModifierKey9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboModifierKey9.FormattingEnabled = True
		Me.cboModifierKey9.Items.AddRange(New Object() {"Ctrl", "Shift", "Alt", "Ctrl+Shift", "Ctrl+Alt", "Shift+Alt", "Ctrl+Shift+Alt", "(指定なし)"})
		Me.cboModifierKey9.Location = New System.Drawing.Point(171, 30)
		Me.cboModifierKey9.Name = "cboModifierKey9"
		Me.cboModifierKey9.Size = New System.Drawing.Size(100, 20)
		Me.cboModifierKey9.TabIndex = 3
		'
		'btn設定
		'
		Me.btn設定.Location = New System.Drawing.Point(84, 538)
		Me.btn設定.Name = "btn設定"
		Me.btn設定.Size = New System.Drawing.Size(75, 23)
		Me.btn設定.TabIndex = 4
		Me.btn設定.Text = "設定"
		Me.btn設定.UseVisualStyleBackColor = True
		'
		'btnキャンセル
		'
		Me.btnキャンセル.Location = New System.Drawing.Point(246, 538)
		Me.btnキャンセル.Name = "btnキャンセル"
		Me.btnキャンセル.Size = New System.Drawing.Size(75, 23)
		Me.btnキャンセル.TabIndex = 6
		Me.btnキャンセル.Text = "キャンセル"
		Me.btnキャンセル.UseVisualStyleBackColor = True
		'
		'btn標準に戻す
		'
		Me.btn標準に戻す.Enabled = False
		Me.btn標準に戻す.Location = New System.Drawing.Point(165, 538)
		Me.btn標準に戻す.Name = "btn標準に戻す"
		Me.btn標準に戻す.Size = New System.Drawing.Size(75, 23)
		Me.btn標準に戻す.TabIndex = 5
		Me.btn標準に戻す.Text = "標準に戻す"
		Me.btn標準に戻す.UseVisualStyleBackColor = True
		'
		'cboModifierKey12
		'
		Me.cboModifierKey12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboModifierKey12.FormattingEnabled = True
		Me.cboModifierKey12.Items.AddRange(New Object() {"Ctrl", "Shift", "Alt", "Ctrl+Shift", "Ctrl+Alt", "Shift+Alt", "Ctrl+Shift+Alt", "(指定なし)"})
		Me.cboModifierKey12.Location = New System.Drawing.Point(171, 108)
		Me.cboModifierKey12.Name = "cboModifierKey12"
		Me.cboModifierKey12.Size = New System.Drawing.Size(100, 20)
		Me.cboModifierKey12.TabIndex = 10
		'
		'cboVirtualKey12
		'
		Me.cboVirtualKey12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboVirtualKey12.FormattingEnabled = True
		Me.cboVirtualKey12.Items.AddRange(New Object() {"", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "*", "+", "-"})
		Me.cboVirtualKey12.Location = New System.Drawing.Point(294, 108)
		Me.cboVirtualKey12.Name = "cboVirtualKey12"
		Me.cboVirtualKey12.Size = New System.Drawing.Size(67, 20)
		Me.cboVirtualKey12.TabIndex = 11
		'
		'Label33
		'
		Me.Label33.AutoSize = True
		Me.Label33.Location = New System.Drawing.Point(277, 111)
		Me.Label33.Name = "Label33"
		Me.Label33.Size = New System.Drawing.Size(11, 12)
		Me.Label33.TabIndex = 8
		Me.Label33.Text = "+"
		'
		'Label34
		'
		Me.Label34.AutoSize = True
		Me.Label34.Location = New System.Drawing.Point(11, 111)
		Me.Label34.Name = "Label34"
		Me.Label34.Size = New System.Drawing.Size(95, 12)
		Me.Label34.TabIndex = 6
		Me.Label34.Text = "スクロールキャプチャ"
		'
		'ShortcutKeySettingForm
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(404, 570)
		Me.Controls.Add(Me.btn標準に戻す)
		Me.Controls.Add(Me.btnキャンセル)
		Me.Controls.Add(Me.btn設定)
		Me.Controls.Add(Me.GroupBox4)
		Me.Controls.Add(Me.GroupBox3)
		Me.Controls.Add(Me.GroupBox2)
		Me.Controls.Add(Me.GroupBox1)
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
		Me.Name = "ShortcutKeySettingForm"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
		Me.Text = "ショートカットキー設定"
		Me.GroupBox1.ResumeLayout(False)
		Me.GroupBox1.PerformLayout()
		Me.GroupBox2.ResumeLayout(False)
		Me.GroupBox2.PerformLayout()
		Me.GroupBox3.ResumeLayout(False)
		Me.GroupBox3.PerformLayout()
		Me.GroupBox4.ResumeLayout(False)
		Me.GroupBox4.PerformLayout()
		Me.ResumeLayout(False)

	End Sub
	Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents cboVirtualKey0 As ComboBox
    Friend WithEvents cboModifierKey2 As ComboBox
    Friend WithEvents cboModifierKey1 As ComboBox
    Friend WithEvents cboModifierKey0 As ComboBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents cboVirtualKey2 As ComboBox
    Friend WithEvents cboVirtualKey1 As ComboBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents cboVirtualKey5 As ComboBox
    Friend WithEvents cboVirtualKey4 As ComboBox
    Friend WithEvents cboVirtualKey3 As ComboBox
    Friend WithEvents cboModifierKey5 As ComboBox
    Friend WithEvents cboModifierKey4 As ComboBox
    Friend WithEvents cboModifierKey3 As ComboBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents cboVirtualKey8 As ComboBox
    Friend WithEvents cboVirtualKey7 As ComboBox
    Friend WithEvents cboVirtualKey6 As ComboBox
    Friend WithEvents cboModifierKey8 As ComboBox
    Friend WithEvents cboModifierKey7 As ComboBox
    Friend WithEvents cboModifierKey6 As ComboBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents cboVirtualKey10 As ComboBox
    Friend WithEvents cboVirtualKey9 As ComboBox
    Friend WithEvents cboModifierKey10 As ComboBox
    Friend WithEvents cboModifierKey9 As ComboBox
    Friend WithEvents btn設定 As Button
    Friend WithEvents btnキャンセル As Button
    Friend WithEvents btn標準に戻す As Button
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents cboVirtualKey11 As System.Windows.Forms.ComboBox
    Friend WithEvents cboModifierKey11 As System.Windows.Forms.ComboBox
    Friend WithEvents Label34 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents cboVirtualKey12 As ComboBox
    Friend WithEvents cboModifierKey12 As ComboBox
End Class
