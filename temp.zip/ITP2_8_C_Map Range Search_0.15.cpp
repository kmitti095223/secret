#include <iostream>
#include <map>
#include <unordered_map>
#include <set>
#include <cstdio>
#include <cstring>
using namespace std;

const int MAX_BUF = 1 << 24; // 16MB�o�b�t�@
char input_buffer[MAX_BUF];
char output_buffer[MAX_BUF];
int buf_index = 0, out_index = 0;

// ���������ǂݍ���
inline int read_int() {
    int x = 0;
    while (input_buffer[buf_index] < '0' || input_buffer[buf_index] > '9') ++buf_index;
    while (input_buffer[buf_index] >= '0' && input_buffer[buf_index] <= '9') {
        x = x * 10 + (input_buffer[buf_index++] - '0');
    }
    return x;
}

// ����������ǂݍ���
inline void read_string(char* s) {
    while (input_buffer[buf_index] == ' ' || input_buffer[buf_index] == '\n') ++buf_index;
    int i = 0;
    while (input_buffer[buf_index] >= 'a' && input_buffer[buf_index] <= 'z') {
        s[i++] = input_buffer[buf_index++];
    }
    s[i] = '\0';
}

// ���������o��
inline void write_int(int x) {
    char temp[12];
    int pos = 0;
    do {
        temp[pos++] = '0' + (x % 10);
        x /= 10;
    } while (x > 0);
    while (pos > 0) {
        output_buffer[out_index++] = temp[--pos];
    }
    output_buffer[out_index++] = '\n';
}

// ����������o��
inline void write_string(const char* s) {
    while (*s) output_buffer[out_index++] = *s++;
    output_buffer[out_index++] = ' ';
}

// �o�̓t���b�V��
inline void flush_output() {
    fwrite(output_buffer, 1, out_index, stdout);
    out_index = 0;
}

int main() {
    // ���͓ǂݍ���
    int input_size = fread(input_buffer, 1, MAX_BUF - 1, stdin);
    input_buffer[input_size] = '\0';

    int q = read_int();

    unordered_map<string, int> M;
    map<string, int> S; // dump �p�i�����ێ��j
    
    char key[21], L[21], R[21];

    while (q--) {
        int op = read_int();
        if (op == 0) { // insert
            read_string(key);
            int value = read_int();
            M[key] = value;
            S[key] = value;
        } else if (op == 1) { // get
            read_string(key);
            auto it = M.find(key);
            write_int(it != M.end() ? it->second : 0);
        } else if (op == 2) { // delete
            read_string(key);
            M.erase(key);
            S.erase(key);
        } else { // dump
            read_string(L);
            read_string(R);
            for (auto it = S.lower_bound(L); it != S.upper_bound(R); ++it) {
                write_string(it->first.c_str());
                write_int(it->second);
            }
        }
    }
    flush_output();
    return 0;
}