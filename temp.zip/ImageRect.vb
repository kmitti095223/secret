﻿Imports System.Runtime.InteropServices

Public Class ImageRect

    Public Enum Direction
        Up = 1
        Down = 2
        Left = 3
        Right = 4
    End Enum
    Structure ColorPos
        Public pos As Point
        Public col As Color

        ' コンストラクタ（オプション）
        Public Sub New(ByVal pos As Point, ByVal col As Color)
            Me.pos = pos
            Me.col = col
        End Sub
    End Structure


    Public Shared Function CheckRect(ByRef bmp As Bitmap, ByVal pos As Point, ByRef rect As Rectangle) As Boolean

        ' 画像のサイズを取得
        Dim width As Integer = bmp.Width
        Dim height As Integer = bmp.Height

        Dim pixelColor As Color

        Dim lstColorL As New List(Of ColorPos)
        Dim lstColorR As New List(Of ColorPos)
        Dim lstColorT As New List(Of ColorPos)
        Dim lstColorB As New List(Of ColorPos)

        rect = Rectangle.Empty
        Dim count As Integer = 0

        ' 左探索
        For x As Integer = pos.X - 1 To 0 Step -1

            If Check(True, bmp, New Point(x, pos.Y), pixelColor) Then
                AddList(lstColorL, New Point(x, pos.Y), pixelColor)
                rect.X = x
                count += 1
                Exit For
            End If
        Next

        ' 右探索
        For x As Integer = pos.X + 1 To bmp.Width - 1

            If Check(True, bmp, New Point(x, pos.Y), pixelColor) Then
                AddList(lstColorL, New Point(x, pos.Y), pixelColor)
                rect.Width = x - rect.X
                count += 1
                Exit For
            End If
        Next

        ' 上探索
        For y As Integer = pos.Y - 1 To 0 Step -1

            If Check(False, bmp, New Point(pos.X, y), pixelColor) Then
                AddList(lstColorL, New Point(pos.X, y), pixelColor)
                rect.Y = y
                count += 1
                Exit For
            End If
        Next

        ' 下探索
        For y As Integer = pos.Y + 1 To bmp.Height - 1

            If Check(False, bmp, New Point(pos.X, y), pixelColor) Then
                AddList(lstColorL, New Point(pos.X, y), pixelColor)
                rect.Height = y - rect.Y
                count += 1
                Exit For
            End If
        Next

        Dim expandBy As Integer = 3
        Dim newX As Integer = Math.Max(0, rect.X - expandBy)
        Dim newY As Integer = Math.Max(0, rect.Y - expandBy)

        Dim newWidth As Integer = Math.Min(bmp.Width - newX, rect.Width + expandBy * 2)
        Dim newHeight As Integer = Math.Min(bmp.Height - newY, rect.Height + expandBy * 2)

        rect = New Rectangle(newX, newY, newWidth, newHeight)
        Debug.Print(rect.ToString)

        '  If rect.Left =0 Or rect.Right = 0 Or 

        Return count = 4
    End Function

    Private Shared Function Check(ByVal bVertical As Boolean, ByRef bmp As Bitmap, ByVal pos As Point, ByRef pixelColor As Color) As Boolean

        pixelColor = bmp.GetPixel(pos.X, pos.Y)
        Debug.Print("Check .. " & pos.ToString() & vbTab & pixelColor.ToString)

        'Dim r = AreColorsSimilar(Color.FromArgb(100, 100, 150), Color.White)

        ' 白は対象外
        If AreColorsSimilar(pixelColor, Color.White) Then
            Return False
        End If

        If bVertical Then

            ' 縦線チェック
            For y As Integer = pos.Y - 3 To pos.Y + 3

                ' 縦線でなければNG
                If Not AreColorsSimilar(bmp.GetPixel(pos.X, y), pixelColor) Then
                    Return False
                End If
            Next

            'For y As Integer = pos.Y - 3 To pos.Y + 3


            '    Dim count As Integer = 0
            '    For x As Integer = pos.X - 3 To pos.X + 3
            '        If bmp.GetPixel(pos.X, y) = pixelColor Then
            '            count = count + 1
            '        End If
            '    Next
            '    If count = 7 Then
            '        Return False
            '    End If
            'Next

        Else

            ' 横線チェック
            For x As Integer = pos.X - 3 To pos.X + 3

                ' 縦線でなければNG
                If Not AreColorsSimilar(bmp.GetPixel(x, pos.Y), pixelColor) Then
                    Return False
                End If
            Next

        End If

        Return True
    End Function

    Shared Sub AddList(ByRef lstColor As List(Of ColorPos), ByVal pos As Point, ByVal pixelColor As Color)
        If lstColor.Count = 0 Then
            lstColor.Add(New ColorPos(pos, pixelColor))
        Else
            If pixelColor <> lstColor(lstColor.Count - 1).col Then
                lstColor.Add(New ColorPos(pos, pixelColor))
            End If
        End If
    End Sub

    Shared Function AreColorsSimilar(color1 As Color, color2 As Color, Optional threshold As Double = 30) As Boolean

        ' R, G, Bの値をDouble型にキャストして差分を計算
        Dim rDifference As Double = CDbl(color1.R) - CDbl(color2.R)
        Dim gDifference As Double = CDbl(color1.G) - CDbl(color2.G)
        Dim bDifference As Double = CDbl(color1.B) - CDbl(color2.B)

        ' ユークリッド距離を計算
        Dim distance As Double = Math.Sqrt(rDifference ^ 2 + gDifference ^ 2 + bDifference ^ 2)

        ' Debug.Print(distance.ToString)

        Return distance < threshold

    End Function

End Class
