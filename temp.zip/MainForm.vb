﻿
Public Class MainForm

    Dim m_sFolder As String
    Dim m_bDrawRect As Boolean = False
    Dim m_Rect As Rectangle


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        m_sFolder = Application.StartupPath & "\Test\"

        PictureBox1.Image = Image.FromFile(m_sFolder & "TEST1.png") ' test.png のパスを指定


        '        Exec("TEST1.png", "TEST1_out.png", New Point(100, 430))
        '        End
    End Sub

    Sub Exec(ByVal sInFile As String, ByVal sOutFile As String, ByVal pos As Point)

        sInFile = m_sFolder & sInFile
        sOutFile = m_sFolder & sOutFile

        ' 画像ファイルを読み込む
        Dim bmp As New Bitmap(sInFile)

        Dim rect As Rectangle

        Dim rc As Boolean = ImageRect.CheckRect(bmp, pos, rect)
        If rc Then
            Using g As Graphics = Graphics.FromImage(bmp)
                Using pen As New Pen(Color.Red)
                    g.DrawRectangle(pen, rect)
                    bmp.Save(sOutFile, System.Drawing.Imaging.ImageFormat.Png)
                End Using
            End Using
        End If

        Debug.Print("END")

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub PictureBox1_DoubleClick(sender As Object, e As EventArgs) Handles PictureBox1.DoubleClick

        Dim bmp As Bitmap = PictureBox1.Image

        Dim mouseEvent As MouseEventArgs = DirectCast(e, MouseEventArgs)
        Dim x As Integer = mouseEvent.X
        Dim y As Integer = mouseEvent.Y


        m_bDrawRect = ImageRect.CheckRect(bmp, New Point(mouseEvent.X, mouseEvent.Y), m_Rect)
        Refresh()

    End Sub

    Private Sub PictureBox1_Paint(sender As Object, e As PaintEventArgs) Handles PictureBox1.Paint

        If m_bDrawRect Then
            Using pen As New Pen(Color.Red, 1)
                e.Graphics.DrawRectangle(pen, m_Rect)
            End Using
        End If

    End Sub
End Class
