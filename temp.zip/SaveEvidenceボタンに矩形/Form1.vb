﻿Public Class Form1

    Const FOLDER = "C:\Users\yuji\Desktop\JunkProgram\SaveEvidenceボタンに矩形\Test\"


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Exec("TEST1.png", "TEST1_out.png", New Point(172, 440))

    End Sub

    Sub Exec(ByVal sInFile As String, ByVal sOutFile As String, ByVal pos As Point)

        sInFile = FOLDER & sInFile
        sOutFile = FOLDER & sOutFile

        ' 画像ファイルを読み込む
        Dim bmp As New Bitmap(sInFile)

        Dim cls As New ImageRect

        cls.CheckRect(bmp, pos)

        Debug.Print("END")

    End Sub
End Class
