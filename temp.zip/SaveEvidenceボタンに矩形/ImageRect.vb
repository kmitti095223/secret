﻿Public Class ImageRect

    Public Enum Direction
        Up = 1
        Down = 2
        Left = 3
        Right = 4
    End Enum
    Structure ColorPos
        Public pos As Point
        Public col As Color

        ' コンストラクタ（オプション）
        Public Sub New(ByVal pos As Point, ByVal col As Color)
            Me.pos = pos
            Me.col = col
        End Sub
    End Structure


    Public Function CheckRect(ByRef bmp As Bitmap, ByVal pos As Point)

        ' 画像のサイズを取得
        Dim width As Integer = bmp.Width
        Dim height As Integer = bmp.Height


        Dim lstColorL As New List(Of ColorPos)
        Dim lstColorR As New List(Of ColorPos)
        Dim lstColorT As New List(Of ColorPos)
        Dim lstColorB As New List(Of ColorPos)

        ' 左探索
        For x As Integer = pos.X - 1 To 0 Step -1

            If Check(True, bmp, pos) Then
                If lstColorL.Count = 0 Then
                    lstColorL.Add(New ColorPos(New Point(x, pos.Y), pixelColor))
                Else
                    If pixelColor <> lstColorL(lstColorL.Count - 1).col Then
                        lstColorL.Add(New ColorPos(New Point(x, pos.Y), pixelColor))
                    End If
                End If
            End If
        Next

        ' 右探索
        For x As Integer = pos.X + 1 To bmp.Width - 1

            Dim pixelColor As Color = bmp.GetPixel(x, pos.Y)
            If pixelColor <> bmp.GetPixel(x, pos.Y - 3) OrElse
               pixelColor <> bmp.GetPixel(x, pos.Y - 2) OrElse
               pixelColor <> bmp.GetPixel(x, pos.Y - 1) OrElse
               pixelColor <> bmp.GetPixel(x, pos.Y + 1) OrElse
               pixelColor <> bmp.GetPixel(x, pos.Y + 2) OrElse
               pixelColor <> bmp.GetPixel(x, pos.Y + 3) Then
                Continue For
            End If

            If lstColorR.Count = 0 Then
                lstColorR.Add(New ColorPos(New Point(x, pos.Y), pixelColor))
            Else
                If pixelColor <> lstColorR(lstColorR.Count - 1).col Then
                    lstColorR.Add(New ColorPos(New Point(x, pos.Y), pixelColor))
                End If
            End If

        Next

        ' 上探索
        For y As Integer = pos.Y - 1 To 0 Step -1

            Dim pixelColor As Color = bmp.GetPixel(pos.X, y)
            If pixelColor <> bmp.GetPixel(pos.X - 3, y) OrElse
               pixelColor <> bmp.GetPixel(pos.X - 2, y) OrElse
               pixelColor <> bmp.GetPixel(pos.X - 1, y) OrElse
               pixelColor <> bmp.GetPixel(pos.X + 1, y) OrElse
               pixelColor <> bmp.GetPixel(pos.X + 2, y) OrElse
               pixelColor <> bmp.GetPixel(pos.X + 3, y) Then
                Continue For
            End If

            If lstColorT.Count = 0 Then
                lstColorT.Add(New ColorPos(New Point(pos.X, y), pixelColor))
            Else
                If pixelColor <> lstColorT(lstColorT.Count - 1).col Then
                    lstColorT.Add(New ColorPos(New Point(pos.X, y), pixelColor))
                End If
            End If

        Next

        ' 下探索
        For y As Integer = pos.Y + 1 To bmp.Height - 1

            Dim pixelColor As Color = bmp.GetPixel(pos.X, y)
            If pixelColor <> bmp.GetPixel(pos.X - 3, y) OrElse
               pixelColor <> bmp.GetPixel(pos.X - 2, y) OrElse
               pixelColor <> bmp.GetPixel(pos.X - 1, y) OrElse
               pixelColor <> bmp.GetPixel(pos.X + 1, y) OrElse
               pixelColor <> bmp.GetPixel(pos.X + 2, y) OrElse
               pixelColor <> bmp.GetPixel(pos.X + 3, y) Then
                Continue For
            End If

            If lstColorB.Count = 0 Then
                lstColorB.Add(New ColorPos(New Point(pos.X, y), pixelColor))
            Else
                If pixelColor <> lstColorB(lstColorB.Count - 1).col Then
                    lstColorB.Add(New ColorPos(New Point(pos.X, y), pixelColor))
                End If
            End If

        Next
    End Function

    Private Function Check(ByVal bVertical As Boolean, ByRef bmp As Bitmap, ByVal pos As Point) As Boolean

        Dim pixelColor As Color = bmp.GetPixel(pos.X, pos.Y)

        If bVertical Then

            For y As Integer = pos.Y - 3 To pos.Y + 3

                ' 縦線でなければNG
                If bmp.GetPixel(pos.X, y) <> pixelColor Then
                    Return False
                End If

                Dim count As Integer = 0
                For x As Integer = pos.X - 3 To pos.X + 3
                    If bmp.GetPixel(pos.X, y) = pixelColor Then
                        count = count + 1
                    End If
                Next
                If count = 7 Then
                    Return False
                End If
            Next

        Else

        End If

        Return True
    End Function


End Class
