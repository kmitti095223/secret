﻿//=============================================================================
// インクルード
//=============================================================================
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <set>

#ifndef WINDOWS_DEBUG
#include <unistd.h>
#else
#include <io.h>
#endif

#ifdef WINDOWS_DEBUG
#include <windows.h>
LARGE_INTEGER m_Freq, m_Start, m_End;
int nCount1 = 0, nCount2 = 0;
#endif

//=============================================================================
// 定義
//=============================================================================
// 文字コードを数値に変換
#define CHAR_TO_INDEX(c)	(c - 'a' + 1)

// setの定義
typedef std::set<char*, bool (*)(const char*, const char*)> MYSET;

//=============================================================================
// 文字列長取得 (半角スペース、改行、NULLまでの長さ)
//=============================================================================
inline int GetLen(const char* p) {
	for (int i = 0;; i++) {
		if (*p++ < '0') {
			return i;
		}
	}
}

inline int GetLenLf(const char* p) {
	for (int i = 0;; i++) {
		if (*p++ == '\n') {
			return i;
		}
	}
}

inline int StrCmp(const char* p1, const char* p2) {
	for (int i = 0;; i++) {
		if (p1[i] < '0') {
			if (p2[i] < '0')
				return 0;
			else
				return -1;
		}

		if (p2[i] < '0') {
			if (p1[i] < '0')
				return 0;
			else
				return 1;
		}

		if (p1[i] != p2[i])
		{
			return p1[i] > p2[i] ? 1 : -1;
		}
	}
}
typedef struct
{
	char	*pPtr;
	int		nKeyLen;
	int		nTotalLen;
	int		nValueLen;
} INF;

//=============================================================================
// 文字列の先頭3文字から配列インデックスを決定
//=============================================================================
inline int GetIndex(char* mac_p) {

	int nLen = GetLen(mac_p);
	int nIndex = 0;

	if (nLen >= 3) {
		nIndex += (CHAR_TO_INDEX(*mac_p) << 10);
		nIndex += (CHAR_TO_INDEX(*(mac_p + 1)) << 5);
		nIndex += (CHAR_TO_INDEX(*(mac_p + 2)));
	}
	else if (nLen >= 2) {
		nIndex += (CHAR_TO_INDEX(*mac_p) << 10);
		nIndex += (CHAR_TO_INDEX(*(mac_p + 1)) << 5);
	}
	else {
		nIndex += (CHAR_TO_INDEX(*mac_p) << 10);
	}
	return nIndex;
}

//=============================================================================
// 次の文字列のアドレスを取得
//=============================================================================
inline char* GetNext(char* p)
{
	for (int i = 0;; i++) {
		if (*p < '0') {
			return (p + 1);
		}
		p++;
	}
}

//=============================================================================
// メイン処理
//=============================================================================
int main(void) {

#ifdef WINDOWS_DEBUG // デバッグ用処理時間計測
	QueryPerformanceFrequency(&m_Freq);
	QueryPerformanceCounter(&m_Start);
#endif

	//--------------------------------------------------------
	// 変数定義、初期処理
	//--------------------------------------------------------
	// 標準入力読み込み
	const int MAX_SIZE = 10 * 1000 * 1000; // 10MBで足りるはず
	char* pAll = (char*)malloc(MAX_SIZE);
	int i = read(0, pAll, MAX_SIZE);
	pAll[i] = '\n';

	// 標準入力のアドレス範囲を取得
	char* pAllS = pAll;
	char* pAllE = pAll + MAX_SIZE;

	// データ数を取得
	int nCount = atoi(pAll);
	char* p = strchr(pAll, '\n') + 1;

	// 配列を作成
	const int TABLE_SIZE = 32768;
	INF* ppTable = new INF[TABLE_SIZE];
	memset(ppTable, 0, sizeof(INF) * TABLE_SIZE);

	// 出力バッファ作成 (10MBで足りるはず)
	char* szResult = new char[10 * 1000 * 1000];
	char* pResult = szResult;

	// set用比較関数定義
	bool (*Compare)(const char*, const char*) = [](const char* l, const char* r) {
		return StrCmp(l, r) < 0;
	};

	//--------------------------------------------------------
	// メイン処理 (データ数分ループ)
	//--------------------------------------------------------
	for (i = 0; i < nCount; i++) {

		switch (*p) {
		case '0': // insert
		{
			p += 2;
			int nIndex = GetIndex(p);
			char* p2 = GetNext(p);
			// *(p2 - 1) = 0;

			if (ppTable[nIndex].pPtr == 0) {
				// 配列にデータが無い場合
				ppTable[nIndex].pPtr = p;
			}
			else if ((ppTable[nIndex].pPtr >= pAllS) && (ppTable[nIndex].pPtr <= pAllE)) {

				// 配列にchar*が入っている場合
				if (StrCmp(p, ppTable[nIndex].pPtr) == 0) {
					// 同じものがあれば上書き
					ppTable[nIndex].pPtr = p;
				}
				else {
					// 違うものが入っていればset化
					MYSET* pSetWk = new MYSET(Compare);
					pSetWk->insert(ppTable[nIndex].pPtr);
					pSetWk->insert(p);
					ppTable[nIndex].pPtr = (char*)pSetWk;
				}
			}
			else {
				// 配列にset*が入っている場合、上書きする。(消してから入れる)
				((MYSET*)ppTable[nIndex].pPtr)->erase(p);
				((MYSET*)ppTable[nIndex].pPtr)->insert(p);
			}

			ppTable[nIndex].nKeyLen = p2 - p;

			p = GetNext(p2);
			// *(p - 1) = 0;

			ppTable[nIndex].nValueLen =  p - p2;
			ppTable[nIndex].nTotalLen  = ppTable[nIndex].nKeyLen + ppTable[nIndex].nValueLen;
			
			break;
		}
		case '1': // get
		{
			p += 2;
			int nIndex = GetIndex(p);
			char* p2 = GetNext(p);
			*(p2 - 1) = 0;

			if (ppTable[nIndex].pPtr == 0) {
				// 配列にデータが無い場合、0を出力
				memcpy(pResult, "0\n", 2);
				pResult += 2;
			}
			else if ((ppTable[nIndex].pPtr >= pAllS) && (ppTable[nIndex].pPtr <= pAllE))
			{
				// 配列にchar*が入っている場合、出力対象であれば出力
				if (StrCmp(p, ppTable[nIndex].pPtr) == 0) {
					memcpy(pResult, ppTable[nIndex].pPtr+ ppTable[nIndex].nKeyLen, ppTable[nIndex].nValueLen);
					pResult += ppTable[nIndex].nValueLen;
				}
				else {
					memcpy(pResult, "0\n", 2);
					pResult += 2;
				}
			}
			else
			{
				// 配列にset*が入っている場合、出力対象をSetから取得して出力
				auto itr = ((MYSET*)ppTable[nIndex].pPtr)->find(p);
				if (itr == ((MYSET*)ppTable[nIndex].pPtr)->end()) {

					memcpy(pResult, "0\n", 2);
					pResult += 2;
				}
				else {
					sprintf(pResult, "%s\n", *itr + GetLen(*itr) + 1);
					pResult += (GetLenLf(pResult) + 1);
				}
			}

			p = p2;
			break;
		}
		case '2': // delete
		{
			p += 2;
			int nIndex = GetIndex(p);
			char* p2 = GetNext(p);
			*(p2 - 1) = 0;

			if (ppTable[nIndex].pPtr == 0)
			{
				// 配列にデータが無い場合、何もしない
			}
			else if ((ppTable[nIndex].pPtr >= pAllS) && (ppTable[nIndex].pPtr <= pAllE)) {

				// 配列にchar*が入っている場合、削除対象と同じであればクリア
				if (StrCmp(p, ppTable[nIndex].pPtr) == 0) {
					ppTable[nIndex].pPtr = 0;
				}
			}
			else
			{
				// 配列にset*が入っている場合、setから削除
				((MYSET*)ppTable[nIndex].pPtr)->erase(p);
			}

			p = p2;
			break;
		}
		case '3': // dump
		{
			p += 2;
			int nIndex = GetIndex(p);
			char* pS = p;
			char* pE = strchr(pS, ' ');
			*pE = 0;
			pE++;
			p = strchr(pE, '\n');
			*p = 0;
			p++;

			int nIndexS = nIndex;
			int nIndexE = GetIndex(pE);

			for (int j = nIndexS; j <= nIndexE; j++)
			{
				if (ppTable[j].pPtr == 0) {
					// 配列にデータが無い場合、何もしない
					continue;
				}
				else if ((ppTable[j].pPtr >= pAllS) && (ppTable[j].pPtr <= pAllE)) {
					
					// 配列にchar*が入っている場合、文字列が範囲内であれば出力
					if ((StrCmp(ppTable[j].pPtr, pS) >= 0)
						&& (StrCmp(ppTable[j].pPtr, pE) <= 0)) {

						memcpy(pResult, ppTable[j].pPtr, ppTable[j].nTotalLen);
						pResult += ppTable[j].nTotalLen;
					}
				}
				else {
					// 配列にset*が入っている場合、文字列が範囲内であれば出力
					for (auto itr = ((MYSET*)ppTable[j].pPtr)->begin(); itr != ((MYSET*)ppTable[j].pPtr)->end(); ++itr) {

						const char* pItr = *itr;

						if (StrCmp(pItr, pS) >= 0) {
							if (StrCmp(pItr, pE) <= 0) {
								memcpy(pResult, pItr, GetLenLf(pItr) + 1);
								pResult += (GetLenLf(pResult) + 1);
							}
							else {
								break;
							}
						}
					}
				}
			}

			// 結果を出力(バッファをはみ出さないようdumpごとに出力)
			if (pResult != szResult) {
				*(pResult - 1) = 0;
				puts(szResult);
				pResult = szResult;
			}

			break;
		}
		default:
			assert(0);
			break;
		}
	}

	// 結果を出力
	if (pResult != szResult) {
		*(pResult - 1) = 0;
		puts(szResult);
	}

#ifdef WINDOWS_DEBUG // デバッグ用処理時間計測
	QueryPerformanceCounter(&m_End);
	printf("実行時間:%dms\n", (int)((double)(m_End.QuadPart - m_Start.QuadPart) * 1000.0 / m_Freq.QuadPart));
	printf("nCount1=%d  nCount2=%d\n", nCount1, nCount2);
	while (1) getchar();
#endif
}
