﻿#include <cstring>
#include <iostream>
#include <map>
#include <cstdio>

#ifdef WINDOWS_DEBUG
#include <windows.h>
LARGE_INTEGER m_Freq, m_Start, m_End;
int nCount1 = 0, nCount2 = 0;
#endif

using namespace std;

struct cmp_str {
    bool operator()(const char* a, const char* b) const {
        return strcmp(a, b) < 0;
    }
};

const int MAX_BUF = 1 << 24; // バッファサイズ16MB
char input_buffer[MAX_BUF];  // 入力バッファ
int buf_index = 0;           // 入力バッファの現在位置
char output_buffer[MAX_BUF]; // 出力バッファ
int output_index = 0;        // 出力バッファの現在位置

map<char*, char*, cmp_str> M[26][26][26]; // 先頭3文字ごとに分割した26×26×26個のmap

inline int read_int() {
    int x = 0;
    while (input_buffer[buf_index] < '0' || input_buffer[buf_index] > '9') {
        ++buf_index;
    }
    while (input_buffer[buf_index] >= '0' && input_buffer[buf_index] <= '9') {
        x = x * 10 + (input_buffer[buf_index] - '0');
        ++buf_index;
    }
    return x;
}

inline char* read_string() {
    while (input_buffer[buf_index] == ' ' || input_buffer[buf_index] == '\n') ++buf_index;
    char* start = &input_buffer[buf_index];
    while (input_buffer[buf_index] > ' ') ++buf_index;
    input_buffer[buf_index] = '\0';
    ++buf_index;
    return start;
}

inline void write_string(const char* str,int n=1) {
    int len = strlen(str);
    if (output_index + len + 1 > MAX_BUF) {
        fwrite(output_buffer, 1, output_index, stdout);
        output_index = 0;
    }
    memcpy(output_buffer + output_index, str, len);
    output_index += len;
    if (n)
        output_buffer[output_index++] = '\n';
    else
    output_buffer[output_index++] = ' ';
}

inline void write_int(int x) {
    char buf[12];
    int index = 0;
    if (x == 0) {
        output_buffer[output_index++] = '0';
        output_buffer[output_index++] = '\n';
        return;
    }
    while (x) {
        buf[index++] = '0' + (x % 10);
        x /= 10;
    }
    while (index) output_buffer[output_index++] = buf[--index];
    output_buffer[output_index++] = '\n';
}

int main() {

#ifdef WINDOWS_DEBUG
    QueryPerformanceFrequency(&m_Freq);
    QueryPerformanceCounter(&m_Start);
#endif

    int input_size = fread(input_buffer, 1, MAX_BUF - 1, stdin);
    if (input_size <= 0) return 1;
    input_buffer[input_size] = '\0';

    int q = read_int();
    while (q--) {
        int op = read_int();
        char* key = read_string();
        int len1 = strlen(key);
        int i1 = key[0] - 'a';
        int i2 = len1>1 ? key[1] - 'a' : 0;
        int i3 = len1>2 ? key[2] - 'a' : 0;

        if (op == 0) {
            char* value = read_string();
            M[i1][i2][i3][key] = value;
        }
        else if (op == 1) {
            auto it = M[i1][i2][i3].find(key);
            write_string(it != M[i1][i2][i3].end() ? it->second : "0");
        }
        else if (op == 2) {
            M[i1][i2][i3].erase(key);
        }
        else if (op == 3) {
            char* R = read_string();
            int len2 = strlen(R);
            int j1 = R[0] - 'a';
            int j2 = len2 > 1 ? R[1] - 'a' : 0;
            int j3 = len2 > 2 ? R[2] - 'a' : 0;
            for (int i = i1; i <= j1; ++i) {
                for (int j = (i == i1 ? i2 : 0); j <= (i == j1 ? j2 : 25); ++j) {
                    for (int k = (i == i1 && j == i2 ? i3 : 0); k <= (i == j1 && j == j2 ? j3 : 25); ++k) {

                        if ((i == i1 || k == i2 || k == i3) ||
                            (i == j1 || k == j2 || k == j3))
                            for (auto it = M[i][j][k].lower_bound(key); it != M[i][j][k].end() && strcmp(it->first, R) <= 0; ++it) {
                                write_string(it->first, 0);
                                write_string(it->second);
                            }
                        else
                            for (auto it = M[i][j][k].begin(); it != M[i][j][k].end(); ++it) {
                                write_string(it->first, 0);
                                write_string(it->second);
                            }
                    }
                }
            }
        }
    }

    if (output_index > 0) {
#ifndef WINDOWS_DEBUG
        fwrite(output_buffer, 1, output_index, stdout);
#endif
    }

#ifdef WINDOWS_DEBUG
    QueryPerformanceCounter(&m_End);
    printf("実行時間:%dms\n", (int)((double)(m_End.QuadPart - m_Start.QuadPart) * 1000.0 / m_Freq.QuadPart));
    printf("nCount1=%d  nCount2=%d\n", nCount1, nCount2);

    while (1) getchar();
#endif

    return 0;
}
