﻿#include <cstring>
#include <iostream>
#include <map>
#include <cstdio>

#ifdef WINDOWS_DEBUG
#include <windows.h>
LARGE_INTEGER m_Freq, m_Start, m_End;
int nCount1 = 0, nCount2 = 0;
#endif

using namespace std;

struct cmp_str {
    bool operator()(const char* a, const char* b) const {
        return memcmp(a, b, 20) < 0;
    }
};

struct TABLE {
    char op;
    int index;
    char key[20 + 1];
    int keylen;
    char value[20 + 1];
    int valuelen;
} t[200000] = { 0 };


const int MAX_BUF = 1 << 24;
char input_buffer[MAX_BUF];
int buf_index = 0;
char output_buffer[MAX_BUF];
int output_index = 0;

map<char*, char*, cmp_str> M[26 * 26 * 26]; // 1次元配列に変更
int Num[26 * 26 * 26] = { 0 }; // 1次元配列に変更 // ★new に変えても変わらない

inline int read_int() {
    int x = 0;
    while (input_buffer[buf_index] < '0' || input_buffer[buf_index] > '9') {
        ++buf_index;
    }
    while (input_buffer[buf_index] >= '0' && input_buffer[buf_index] <= '9') {
        x = x * 10 + (input_buffer[buf_index] - '0');
        ++buf_index;
    }
    return x;
}

inline char* read_string() {
    while (input_buffer[buf_index] == ' ' || input_buffer[buf_index] == '\n') ++buf_index;
    char* start = &input_buffer[buf_index];
    while (input_buffer[buf_index] > ' ') ++buf_index;
    input_buffer[buf_index] = '\0';
    ++buf_index;
    return start;
}

inline void write_string(const char* str, char c = '\n') {
    int len = strlen(str);
    if (output_index + len + 1 > MAX_BUF) {
        fwrite(output_buffer, 1, output_index, stdout);
        output_index = 0;
    }
    memcpy(output_buffer + output_index, str, len);
    output_index += len;
    output_buffer[output_index++] = c;
}

inline void write_string2(const char* str,int len=-1, char c = '\n') {
    if (len == -1) {
       const char* p = str;
        len = 0;
        while (*p++)
            len++;
    }
memcpy(output_buffer + output_index, str, len);
    output_index += len;
    output_buffer[output_index++] = c;
}

int main() {
#ifdef WINDOWS_DEBUG
    QueryPerformanceFrequency(&m_Freq);
    QueryPerformanceCounter(&m_Start);
#endif

    int input_size = fread(input_buffer, 1, MAX_BUF - 1, stdin);
    if (input_size <= 0) return 1;
    input_buffer[input_size] = '\0';

    int map_max = 0;

    int q = read_int();

    int i;
    int j;

    {
        char* p = &input_buffer[buf_index];
        p++;

        for (i = 0; i < q; i++) {
            t[i].op = *p;
            p += 2;

            if (t[i].op == '0' || t[i].op == '3') {
                for (j = 0; *p != ' '; ++j)
                    t[i].key[j] = *p++;
                t[i].keylen = j;
                p += 1;

                for (j = 0; *p != '\n'; ++j)
                    t[i].value[j] = *p++;
                t[i].valuelen = j;
                p += 1;
            }
            else {
                for (j = 0; *p != '\n'; ++j)
                    t[i].key[j] = *p++;
                t[i].keylen = j;
                p += 1;
            }
        }
    }

    j = 0;
    while (q--) {

        char* key = t[j].key;
        int len1 = strlen(key);
        int index = (key[0] - 'a') * 676 + (len1 > 1 ? (key[1] - 'a') * 26 : 0) + (len1 > 2 ? key[2] - 'a' : 0);

        if (t[j].op == '0') {
            //  char* value = read_string();
            M[index][key] = t[j].value;
            Num[index] = 1;
        }
        else if (t[j].op == '1') {

            if (Num[index]) {
                if (M[index].size() > map_max)
                    map_max = M[index].size();
                auto it = M[index].find(key);// 60 ms
                if (it != M[index].end())
                    write_string2(it->second);
                else
                    write_string2("0", 1);
            }
            else
            {
                write_string2("0", 1);
            }
        }
        else if (t[j].op == '2') {
            // 0 ms
            M[index].erase(key);
        }
        else if (t[j].op == '3') {
            // 120 ms
            char* R = t[j].value;// read_string();
            int len2 = strlen(R);
            int end_index = (R[0] - 'a') * 676 + (len2 > 1 ? (R[1] - 'a') * 26 : 0) + (len2 > 2 ? R[2] - 'a' : 0);
            for (i = index; i <= end_index; ++i) {
                if (Num[i]) {
                    if ((i == index) || i == end_index)
                        for (auto it = M[i].lower_bound(key); it != M[i].end() && memcmp(it->first, R, 20) <= 0; ++it) {
                            write_string2(it->first,-1, ' ');
                            write_string2(it->second ,- 1 );
                        }
                    else
                        for (auto it = M[i].begin(); it != M[i].end(); ++it) {
                            write_string2(it->first, - 1,  ' ');
                            write_string2(it->second ,- 1 );
                        }
                }
            }
        }

        j++;
    }

    if (output_index > 0) {
#ifndef WINDOWS_DEBUG
        fwrite(output_buffer, 1, output_index, stdout);
#endif
    }

#ifdef WINDOWS_DEBUG
    QueryPerformanceCounter(&m_End);
    printf("実行時間:%dms\n", (int)((double)(m_End.QuadPart - m_Start.QuadPart) * 1000.0 / m_Freq.QuadPart));
    printf("nCount1=%d  nCount2=%d\n", nCount1, nCount2);

    while (1) getchar();
#endif

    return 0;
}
