﻿#include <cstdio>
#include <cstring>
#include <deque>
#include <string_view>
#include <algorithm>
#include <vector>

constexpr int BUFFER_SIZE = 16 * 1024 * 1024; // 16MBバッファ
char input_buffer[BUFFER_SIZE];
char output_buffer[BUFFER_SIZE];
char* input_ptr = input_buffer;
char* output_ptr = output_buffer;
char* output_end = output_buffer + BUFFER_SIZE;

// 高速入力用
inline char read_char() {
    while (*input_ptr == ' ' || *input_ptr == '\n') ++input_ptr;
    return *input_ptr;
}

inline int read_int() {
    int x = 0;
    while (*input_ptr < '0' || *input_ptr > '9') ++input_ptr;
    while (*input_ptr >= '0' && *input_ptr <= '9') x = x * 10 + (*input_ptr++ - '0');
    return x;
}

inline std::string_view read_string() {
    while (*input_ptr == ' ' || *input_ptr == '\n') ++input_ptr;
    char* start = input_ptr;
    while (*input_ptr > ' ') ++input_ptr;
    return std::string_view(start, input_ptr - start);
}

// 高速出力用
inline void write_output(const char* s, size_t len) {
    if (output_ptr + len >= output_end) {
        fwrite(output_buffer, 1, output_ptr - output_buffer, stdout);
        output_ptr = output_buffer;
    }
    memcpy(output_ptr, s, len);
    output_ptr += len;
}

// FlatMap の定義
struct FlatMap {
    struct Record {
        std::string_view key, value;
        bool operator<(const Record& other) const { return key < other.key; }
    };
    std::deque<Record> data;

    void insert(std::string_view key, std::string_view value) {
        auto it = std::lower_bound(data.begin(), data.end(), key,
            [](const Record& r, std::string_view k) { return r.key < k; });
        if (it != data.end() && it->key == key) {
            it->value = value;
        }
        else {
            data.insert(it, { key, value });
        }
    }

    int get(std::string_view key) {
        auto it = std::lower_bound(data.begin(), data.end(), key,
            [](const Record& r, std::string_view k) { return r.key < k; });
        return (it != data.end() && it->key == key) ? atoi(it->value.data()) : 0;
    }

    void erase(std::string_view key) {
        auto it = std::lower_bound(data.begin(), data.end(), key,
            [](const Record& r, std::string_view k) { return r.key < k; });
        if (it != data.end() && it->key == key) data.erase(it);
    }
};

// 17576個（26*26*26）のFlatMapを管理
constexpr int MAP_SIZE = 26 * 26 * 26;
FlatMap maps[MAP_SIZE];

// 先頭3文字でインデックス計算
inline int get_map_index(std::string_view key) {
    int index = 0;
    for (size_t i = 0; i < key.size() && i < 3; ++i) {
        index = index * 26 + (key[i] - 'a');
    }
    return index;
}

// dump の最適化（lower_bound / upper_bound の最小化）
void dump_optimized(std::string_view L, std::string_view R) {
    int start_index = get_map_index(L);
    int end_index = get_map_index(R);

    for (int i = start_index; i <= end_index; ++i) {
        auto& data = maps[i].data;
        if (data.empty()) continue;

        auto start_it = (i == start_index)
            ? std::lower_bound(data.begin(), data.end(), L,
                [](const FlatMap::Record& r, std::string_view k) { return r.key < k; })
            : data.begin();

        auto end_it = (i == end_index)
            ? std::upper_bound(data.begin(), data.end(), R,
                [](std::string_view k, const FlatMap::Record& r) { return k < r.key; })
            : data.end();

        for (auto it = start_it; it != end_it; ++it) {
            write_output(it->key.data(), it->key.size());
            *output_ptr++ = ' ';
            write_output(it->value.data(), it->value.size());
            *output_ptr++ = '\n';
        }
    }
}

// メイン処理
int main() {
    // Visual C++ でのバッファ設定
    setvbuf(stdin, NULL, _IOFBF, BUFFER_SIZE);
    setvbuf(stdout, NULL, _IOFBF, BUFFER_SIZE);

    // 高速入力
    fread(input_buffer, 1, BUFFER_SIZE, stdin);

    int q = read_int();
    while (q--) {
        int type = read_char() - '0';
        if (type == 0) { // insert
            std::string_view key = read_string();
            std::string_view value = read_string();
            maps[get_map_index(key)].insert(key, value);
        }
        else if (type == 1) { // get
            std::string_view key = read_string();
            int val = maps[get_map_index(key)].get(key);
            output_ptr += sprintf(output_ptr, "%d\n", val);
        }
        else if (type == 2) { // delete
            std::string_view key = read_string();
            maps[get_map_index(key)].erase(key);
        }
        else if (type == 3) { // dump
            std::string_view L = read_string();
            std::string_view R = read_string();
            dump_optimized(L, R);
        }
    }

    // 高速出力
    fwrite(output_buffer, 1, output_ptr - output_buffer, stdout);
    return 0;
}
