﻿//=============================================================================
// インクルード
//=============================================================================
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include <vector>
#include <algorithm>

#include <iostream>
#include <set>
#include <string>

#ifndef WINDOWS_DEBUG
#include <unistd.h>
#else
#include <io.h>
// #define DUMP
#endif

#ifdef WINDOWS_DEBUG
#include <windows.h>
LARGE_INTEGER m_Freq, m_Start, m_End;
int nCount1 = 0, nCount2 = 0;
#endif

int CHAR_TO_INDEX[]
{
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,
16,17,18,19,20,21,22,23,24,25,26
};

int GetLen(const char* p)
{
	int i;
	for (i = 0;; i++)
		if (*p++ < 'a')
			return i;
}

#define GetIndex(mac_p) {								\
	mac_len = GetLen(mac_p);							\
	 if (mac_len >= 3) {							\
		nIndex += (CHAR_TO_INDEX[*mac_p] <<10);		\
		nIndex += (CHAR_TO_INDEX[*(mac_p+1)] <<5);	\
		nIndex += (CHAR_TO_INDEX[*(mac_p+2)] );	\
	} else if (mac_len >= 2) {							\
		nIndex += (CHAR_TO_INDEX[*mac_p] <<10);		\
		nIndex += (CHAR_TO_INDEX[*(mac_p+1)] <<5);	\
	} else {											\
		nIndex += (CHAR_TO_INDEX[*mac_p] <<10);		\
	}													\
}

inline char* GetNext(char* p)
{
	int i;
	for (i = 0;; i++)
	{
		if (*p < '0')
			return (p + 1);
		p++;
	}
}

typedef std::set<char*, bool (*)(const char*, const char*)> MYSET;

int main(void) {

#ifdef WINDOWS_DEBUG // デバッグ用処理時間計測
	QueryPerformanceFrequency(&m_Freq);
	QueryPerformanceCounter(&m_Start);
#endif

	// 標準入力読み込み
	const int MAX_SIZE = (6 + 1) + (((1 + 1) + (20 + 1) + (10 + 1)) * 200000) + 100;
	char* pAll = (char*)malloc(MAX_SIZE);
	int i = read(0, pAll, MAX_SIZE);
	pAll[i] = '\n';

	char* pAllS = pAll;
	char* pAllE = pAll + MAX_SIZE;

	int count;
	count = atoi(pAll);

	//const int TABLE_SIZE = 1048576;
	//#define TABLE_SIZE 1048576
	#define TABLE_SIZE 32768
	char** ppTable = (char**)malloc(sizeof(char*) * TABLE_SIZE);
	memset(ppTable, 0, sizeof(char*) * TABLE_SIZE);

	//int* pTableLen = (int*)malloc(sizeof(int) * 1048576);

	char* szResult = (char*)malloc(9768431 + 1);
	char* pResult = szResult;

	int j = 0;
	char* p = strchr(pAll, '\n') + 1;
	char* p2;
	char* pS, * pE;
	int nIndex, nIndex2;

	bool (*Compare)(const char*, const char*) = [](const char* l, const char* r) { return strcmp(l, r) < 0; };
	MYSET* pSetWk;

	int mac_len;

	// std::set<long long> setPtrList;

	int max_set = 0;

#ifdef DUMP
	int line_no = 1;
#endif

	for (i = 0; i < count; i++)
	{
		p += 2;
		nIndex = 0;
		GetIndex(p);

		//if ((memcmp(p, "rcah", 4) == 0))
		/*if (line_no ==348155)
		{
			int k = 0;
		}*/

		switch (*(p - 2))
		{
		case '0': // insert
			p2 = GetNext(p);
			*(p2 - 1) = 0;
			if (ppTable[nIndex] == 0) {
				ppTable[nIndex] = p;
			}
			else if ((ppTable[nIndex] >= pAllS) && (ppTable[nIndex] <= pAllE)) {
				if (strcmp(p, ppTable[nIndex]) == 0)
				{
					// 同じものがあれば上書き
					ppTable[nIndex] = p;
				}
				else
				{
					// 違うものがあればset化
					pSetWk = new MYSET(Compare);

					pSetWk->insert(ppTable[nIndex]);
					pSetWk->insert(p);
					ppTable[nIndex] = (char*)pSetWk;
				}
			}
			else
			{
				// すでにsetがあれば消してから入れる
				((MYSET*)ppTable[nIndex])->erase(p);
				((MYSET*)ppTable[nIndex])->insert(p);

				// assert(((MYSET*)ppTable[nIndex])->size()<=2);
			}

			p = GetNext(p2);
			*(p - 1) = 0;
			break;

		case '1': // get
			p2 = GetNext(p);
			*(p2 - 1) = 0;

			if (ppTable[nIndex] == 0)
			{
#ifdef DUMP
				printf("%6d 0\n", line_no++);
#endif

				memcpy(pResult, "0\n", 2);
				pResult += 2;
			}
			else if ((ppTable[nIndex] >= pAllS) && (ppTable[nIndex] <= pAllE))
			{
				if (strcmp(p, ppTable[nIndex]) == 0)
				{
#ifdef DUMP
					printf("%6d %s\n", line_no++, ppTable[nIndex] + strlen(ppTable[nIndex]) + 1);
#endif
					sprintf(pResult, "%s\n", ppTable[nIndex] + strlen(ppTable[nIndex]) + 1);
					pResult += strlen(pResult);
				}
				else
				{
					memcpy(pResult, "0\n", 2);
					pResult += 2;
				}
			}
			else
			{
				// すでにsetがあれば取得
				auto itr = ((MYSET*)ppTable[nIndex])->find(p);
				if (itr == ((MYSET*)ppTable[nIndex])->end())
				{
#ifdef DUMP
					printf("%6d 0\n", line_no++);
#endif
					memcpy(pResult, "0\n", 2);
					pResult += 2;
				}
				else
				{
#ifdef DUMP
					printf("%6d %s\n", line_no++, *itr + strlen(*itr) + 1);
#endif
					sprintf(pResult, "%s\n", *itr + strlen(*itr) + 1);
					pResult += strlen(pResult);
				}
			}

			p = p2;
			break;

		case '2': // delete
			p2 = GetNext(p);
			*(p2 - 1) = 0;
			if (ppTable[nIndex] == 0)
			{
				;
			}
			else if ((ppTable[nIndex] >= pAllS) && (ppTable[nIndex] <= pAllE))
			{
				// 同じものがあればクリア
				if (strcmp(p, ppTable[nIndex]) == 0)
				{
					ppTable[nIndex] = 0;
				}
			}
			else
			{
				// すでにsetがあれば削除
				((MYSET*)ppTable[nIndex])->erase(p);
				if (((MYSET*)ppTable[nIndex])->size() == 0)
				{
					ppTable[nIndex] = 0;
				}
			}

			p = p2;
			break;

		case '3': // dump
			pS = p;
			pE = strchr(pS, ' ');
			*pE = 0;
			pE++;
			p = strchr(pE, '\n');
			*p = 0;
			p++;

			nIndex2 = nIndex;

			nIndex = 0;
			GetIndex(pE);

			for (j = nIndex2; j <= nIndex; j++)
			{
				if (ppTable[j] == 0) {
					continue;
				}
				else if ((ppTable[j] >= pAllS) && (ppTable[j] <= pAllE))
				{
					if ((strcmp(ppTable[j], pS) >= 0)
						&& (strcmp(ppTable[j], pE) <= 0))
					{
#ifdef DUMP
						printf("%6d %s %s\n", line_no++, ppTable[j],
							ppTable[j] + strlen(ppTable[j]) + 1);
#endif

						if (0) {
							sprintf(pResult, "%s %s\n", ppTable[j],
								ppTable[j] + strlen(ppTable[j]) + 1);
							pResult += strlen(pResult);
						}
						if (1) {
							// 65万回
							memcpy(pResult, ppTable[j], 32);
							pResult += (strlen(pResult) + 1);
							*(pResult - 1) = ' ';
							pResult += (strlen(pResult) + 1);
							*(pResult - 1) = '\n';
						}
						if (0) {
							int nLen1 = (strlen(ppTable[j]) + 1);
							int nLen2 = (strlen(ppTable[j] + nLen1) + 1);
							memcpy(pResult, ppTable[j], nLen1 + nLen2 - 1);
							pResult += (nLen1 + nLen2);
							*(pResult - nLen2 - 1) = ' ';
							*(pResult - 1) = '\n';
						}
					}
				}
				else
				{
					for (auto itr = ((MYSET*)ppTable[j])->begin(); itr != ((MYSET*)ppTable[j])->end(); ++itr)
					{
						const char* pItr = *itr;
						if ((strcmp(pItr, pS) >= 0) && (strcmp(pItr, pE) <= 0))
						{
							// 2788回
							//sprintf(pResult, "%s %s\n", pItr, pItr + strlen(pItr) + 1);
							//pResult += strlen(pResult);

							memcpy(pResult, pItr, 32);
							pResult += (strlen(pResult) + 1);
							*(pResult - 1) = ' ';
							pResult += (strlen(pResult) + 1);
							*(pResult - 1) = '\n';
						}
					}
				}
			}

			break;

		default:
			i = 0xFFFFFFF;
			break;
		}
	}

#ifdef WINDOWS_DEBUG // デバッグ用処理時間計測
	QueryPerformanceCounter(&m_End);
#endif

#ifndef DUMP
	* (pResult - 1) = 0;
	puts(szResult);
#endif

#ifdef WINDOWS_DEBUG // デバッグ用処理時間計測
	printf("実行時間:%dms\n", (int)((double)(m_End.QuadPart - m_Start.QuadPart) * 1000.0 / m_Freq.QuadPart));
	printf("nCount1=%d  nCount2=%d\n", nCount1, nCount2);

	FILE* fp = fopen("Result.txt", "w");
	fwrite(szResult, 1, pResult - szResult, fp);
	fclose(fp);

	while (1) getchar();
#endif
}
