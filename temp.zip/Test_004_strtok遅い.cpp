﻿//=============================================================================
// インクルード
//=============================================================================
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <set>

#ifndef WINDOWS_DEBUG
#include <unistd.h>
#else
#include <io.h>
#endif

#ifdef WINDOWS_DEBUG
#include <windows.h>
LARGE_INTEGER m_Freq, m_Start, m_End;
int nCount1 = 0, nCount2 = 0;
#endif

//=============================================================================
// 定義
//=============================================================================
// 文字コードを数値に変換
#define CHAR_TO_INDEX(c)	(c - 'a' + 1)

// setの定義
typedef std::set<char*, bool (*)(const char*, const char*)> MYSET;

//=============================================================================
// 文字列長取得 (半角スペース、改行、NULLまでの長さ)
//=============================================================================
inline int GetLen(const char* p) {
	for (int i = 0;; i++) {
		if (*p++ < '0') {
			return i;
		}
	}
}

//=============================================================================
// 文字列の先頭3文字から配列インデックスを決定
//=============================================================================
inline int GetIndex(char* mac_p) {

	int nLen = GetLen(mac_p);
	int nIndex = 0;

	if (nLen >= 3) {
		nIndex += (CHAR_TO_INDEX(*mac_p) << 10);
		nIndex += (CHAR_TO_INDEX(*(mac_p + 1)) << 5);
		nIndex += (CHAR_TO_INDEX(*(mac_p + 2)));
	}
	else if (nLen >= 2) {
		nIndex += (CHAR_TO_INDEX(*mac_p) << 10);
		nIndex += (CHAR_TO_INDEX(*(mac_p + 1)) << 5);
	}
	else {
		nIndex += (CHAR_TO_INDEX(*mac_p) << 10);
	}
	return nIndex;
}

//=============================================================================
// 次の文字列のアドレスを取得
//=============================================================================
inline char* GetNext(char* p)
{
	for (int i = 0;; i++) {
		if (*p < '0') {
			return (p + 1);
		}
		p++;
	}
}

//=============================================================================
// メイン処理
//=============================================================================
int main(void) {

#ifdef WINDOWS_DEBUG // デバッグ用処理時間計測
	QueryPerformanceFrequency(&m_Freq);
	QueryPerformanceCounter(&m_Start);
#endif

	//--------------------------------------------------------
	// 変数定義、初期処理
	//--------------------------------------------------------
	// 標準入力読み込み
	const int MAX_SIZE = 10 * 1000 * 1000; // 10MBで足りるはず
	char* pAll = (char*)malloc(MAX_SIZE);
	int i = read(0, pAll, MAX_SIZE);
	pAll[i] = '\n';

	// 標準入力のアドレス範囲を取得
	char* pAllS = pAll;
	char* pAllE = pAll + MAX_SIZE;

	// データ数を取得
	char* p = strtok(pAll, "\n");
	int nCount = atoi(p);

	// 配列を作成
	const int TABLE_SIZE = 32768;
	char** ppTable = new char* [TABLE_SIZE];
	memset(ppTable, 0, sizeof(char*) * TABLE_SIZE);

	// 出力バッファ作成 (10MBで足りるはず)
	char* szResult = new char[10 * 1000 * 1000];
	char* pResult = szResult;

	// set用比較関数定義
	bool (*Compare)(const char*, const char*) = [](const char* l, const char* r) {
		return strcmp(l, r) < 0;
	};

	//--------------------------------------------------------
	// メイン処理 (データ数分ループ)
	//--------------------------------------------------------
	for (i = 0; i < nCount; i++) {

		p = strtok(0, " ");

		switch (*p) {
		case '0': // insert
		{
			p = strtok(0, " ");
			int nIndex = GetIndex(p);
			char* p2 = strtok(0, "\n");

			if (ppTable[nIndex] == 0) {
				// 配列にデータが無い場合
				ppTable[nIndex] = p;
			}
			else if ((ppTable[nIndex] >= pAllS) && (ppTable[nIndex] <= pAllE)) {

				// 配列にchar*が入っている場合
				if (strcmp(p, ppTable[nIndex]) == 0) {
					// 同じものがあれば上書き
					ppTable[nIndex] = p;
				}
				else {
					// 違うものが入っていればset化
					MYSET* pSetWk = new MYSET(Compare);
					pSetWk->insert(ppTable[nIndex]);
					pSetWk->insert(p);
					ppTable[nIndex] = (char*)pSetWk;
				}
			}
			else {
				// 配列にset*が入っている場合、上書きする。(消してから入れる)
				((MYSET*)ppTable[nIndex])->erase(p);
				((MYSET*)ppTable[nIndex])->insert(p);
			}

			break;
		}
		case '1': // get
		{
			p = strtok(0, "\n");
			int nIndex = GetIndex(p);

			if (ppTable[nIndex] == 0) {
				// 配列にデータが無い場合、0を出力
				memcpy(pResult, "0\n", 2);
				pResult += 2;
				//printf("0\n");
			}
			else if ((ppTable[nIndex] >= pAllS) && (ppTable[nIndex] <= pAllE))
			{
				// 配列にchar*が入っている場合、出力対象であれば出力
				if (strcmp(p, ppTable[nIndex]) == 0) {
					sprintf(pResult, "%s\n", ppTable[nIndex] + strlen(ppTable[nIndex]) + 1);
					pResult += strlen(pResult);
					//printf("%s\n", ppTable[nIndex] + strlen(ppTable[nIndex]) + 1);
				}
				else {
					memcpy(pResult, "0\n", 2);
					pResult += 2;
					//printf("0\n");
				}
			}
			else
			{
				// 配列にset*が入っている場合、出力対象をSetから取得して出力
				auto itr = ((MYSET*)ppTable[nIndex])->find(p);
				if (itr == ((MYSET*)ppTable[nIndex])->end()) {

					memcpy(pResult, "0\n", 2);
					pResult += 2;
					//printf("0\n");
				}
				else {
					sprintf(pResult, "%s\n", *itr + strlen(*itr) + 1);
					pResult += strlen(pResult);
					//printf("%s\n", *itr + strlen(*itr) + 1);
				}
			}

			break;
		}
		case '2': // delete
		{
			p = strtok(0, "\n");
			int nIndex = GetIndex(p);

			if (ppTable[nIndex] == 0)
			{
				// 配列にデータが無い場合、何もしない
			}
			else if ((ppTable[nIndex] >= pAllS) && (ppTable[nIndex] <= pAllE)) {

				// 配列にchar*が入っている場合、削除対象と同じであればクリア
				if (strcmp(p, ppTable[nIndex]) == 0) {
					ppTable[nIndex] = 0;
				}
			}
			else
			{
				// 配列にset*が入っている場合、setから削除
				((MYSET*)ppTable[nIndex])->erase(p);
			}

			break;
		}
		case '3': // dump
		{
			char* pS = strtok(0, " ");
			char* pE = strtok(0, "\n");

			int nIndexS = GetIndex(pS);
			int nIndexE = GetIndex(pE);

			for (int j = nIndexS; j <= nIndexE; j++)
			{
				if (ppTable[j] == 0) {
					// 配列にデータが無い場合、何もしない
					continue;
				}
				else if ((ppTable[j] >= pAllS) && (ppTable[j] <= pAllE)) {
					
					// 配列にchar*が入っている場合、文字列が範囲内であれば出力
					if ((strcmp(ppTable[j], pS) >= 0)
						&& (strcmp(ppTable[j], pE) <= 0)) {

						memcpy(pResult, ppTable[j], 32);
						pResult += (strlen(pResult) + 1);
						*(pResult - 1) = ' ';
						pResult += (strlen(pResult) + 1);
						*(pResult - 1) = '\n';
						//printf("%s %s\n", ppTable[j], ppTable[j] + strlen(ppTable[j]) + 1);
					}
				}
				else {
					// 配列にset*が入っている場合、文字列が範囲内であれば出力
					for (auto itr = ((MYSET*)ppTable[j])->begin(); itr != ((MYSET*)ppTable[j])->end(); ++itr) {

						const char* pItr = *itr;

						if (strcmp(pItr, pS) >= 0) {
							if (strcmp(pItr, pE) <= 0) {
							
								memcpy(pResult, pItr, 32);
								pResult += (strlen(pResult) + 1);
								*(pResult - 1) = ' ';
								pResult += (strlen(pResult) + 1);
								*(pResult - 1) = '\n';
								//printf("%s %s\n", pItr, pItr + strlen(pItr) + 1);
							}
							else {
								break;
							}
						}
					}
				}
			}

			// 結果を出力(バッファをはみ出さないようdumpごとに出力)
			if (pResult != szResult) {
				*(pResult - 1) = 0;
				puts(szResult);
				pResult = szResult;
			}

			break;
		}
		default:
			assert(0);
			break;
		}
	}

	// 結果を出力
	if (pResult != szResult) {
		*(pResult - 1) = 0;
		puts(szResult);
	}

#ifdef WINDOWS_DEBUG // デバッグ用処理時間計測
	QueryPerformanceCounter(&m_End);
	printf("実行時間:%dms\n", (int)((double)(m_End.QuadPart - m_Start.QuadPart) * 1000.0 / m_Freq.QuadPart));
	printf("nCount1=%d  nCount2=%d\n", nCount1, nCount2);
	while (1) getchar();
#endif
}
