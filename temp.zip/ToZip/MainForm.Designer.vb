﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.btnExec = New System.Windows.Forms.Button()
        Me.m_WebMain = New 収益認識管理システム自動化.WebBrowserEx()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.m_WebSub = New 収益認識管理システム自動化.WebView2Ex()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.m_WebIntramart = New 収益認識管理システム自動化.WebView2Ex()
        Me.m_List = New 収益認識管理システム自動化.ProcList()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.m_WebSub, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        CType(Me.m_WebIntramart, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.TabControl1)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.m_List)
        Me.SplitContainer1.Size = New System.Drawing.Size(1390, 699)
        Me.SplitContainer1.SplitterDistance = 1064
        Me.SplitContainer1.TabIndex = 1
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1064, 699)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.btnExec)
        Me.TabPage1.Controls.Add(Me.m_WebMain)
        Me.TabPage1.Controls.Add(Me.Button1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1056, 673)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "収益認識メイン"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'btnExec
        '
        Me.btnExec.Location = New System.Drawing.Point(662, -19)
        Me.btnExec.Name = "btnExec"
        Me.btnExec.Size = New System.Drawing.Size(224, 41)
        Me.btnExec.TabIndex = 4
        Me.btnExec.Text = "Button2"
        Me.btnExec.UseVisualStyleBackColor = True
        '
        'm_WebMain
        '
        Me.m_WebMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.m_WebMain.Location = New System.Drawing.Point(3, 3)
        Me.m_WebMain.MinimumSize = New System.Drawing.Size(20, 20)
        Me.m_WebMain.Name = "m_WebMain"
        Me.m_WebMain.Size = New System.Drawing.Size(1050, 667)
        Me.m_WebMain.TabIndex = 3
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(830, 343)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(300, 102)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.m_WebSub)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1056, 673)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "収益認識サブ"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'm_WebSub
        '
        Me.m_WebSub.AllowExternalDrop = True
        Me.m_WebSub.CreationProperties = Nothing
        Me.m_WebSub.DefaultBackgroundColor = System.Drawing.Color.White
        Me.m_WebSub.Dock = System.Windows.Forms.DockStyle.Fill
        Me.m_WebSub.Location = New System.Drawing.Point(3, 3)
        Me.m_WebSub.Name = "m_WebSub"
        Me.m_WebSub.Size = New System.Drawing.Size(1050, 667)
        Me.m_WebSub.TabIndex = 2
        Me.m_WebSub.ZoomFactor = 1.0R
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.m_WebIntramart)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(1056, 673)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Intramart"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'm_WebIntramart
        '
        Me.m_WebIntramart.AllowExternalDrop = True
        Me.m_WebIntramart.CreationProperties = Nothing
        Me.m_WebIntramart.DefaultBackgroundColor = System.Drawing.Color.White
        Me.m_WebIntramart.Dock = System.Windows.Forms.DockStyle.Fill
        Me.m_WebIntramart.Location = New System.Drawing.Point(0, 0)
        Me.m_WebIntramart.Name = "m_WebIntramart"
        Me.m_WebIntramart.Size = New System.Drawing.Size(1056, 673)
        Me.m_WebIntramart.TabIndex = 2
        Me.m_WebIntramart.ZoomFactor = 1.0R
        '
        'm_List
        '
        Me.m_List.Dock = System.Windows.Forms.DockStyle.Fill
        Me.m_List.FormattingEnabled = True
        Me.m_List.Location = New System.Drawing.Point(0, 0)
        Me.m_List.Name = "m_List"
        Me.m_List.Size = New System.Drawing.Size(322, 699)
        Me.m_List.TabIndex = 0
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1390, 699)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Name = "MainForm"
        Me.Text = "Form1"
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        CType(Me.m_WebSub, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        CType(Me.m_WebIntramart, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents SplitContainer1 As SplitContainer
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents btnExec As Button
    Friend WithEvents m_WebMain As WebBrowserEx
    Friend WithEvents Button1 As Button
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents m_WebSub As WebView2Ex
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents m_WebIntramart As WebView2Ex
    Friend WithEvents m_List As ProcList
End Class
