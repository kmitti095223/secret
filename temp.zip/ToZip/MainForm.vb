﻿Imports System.ComponentModel
Imports Microsoft
Imports System.Security.Policy
Imports Microsoft.Web.WebView2.Core
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports System.Windows.Forms.VisualStyles

Public Class MainForm

    Const PANDA_ID = "ap095223"
    Const PANDA_PASS = "jiopoij8"

    Const 案件名 As String = "上地テスト"

    Const URL_BASE As String = "http://s20o114/shinsyueki_step2_3_ITB/"

    Private Sub FormMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        m_WebIntramart.Initialize()
        m_WebSub.Initialize()

        m_WebMain.ScriptErrorsSuppressed = True

        m_WebIntramart.CoreWebView2.Settings.IsScriptEnabled = True

        '   m_WebMain.Navigate(URL_BASE & "login/KK111G001/KK111G001.aspx")

        m_List.m_WebMain = m_WebMain
        m_List.m_WebIntraMart = m_WebIntramart

        Dim rc As Boolean = m_List.Load(Application.StartupPath & "\test.txt")
        If Not rc Then
            Exit Sub
        End If

        Show()
        btnExec.PerformClick()
        '  m_WebIntraMart.Navigate("http://s20o113.sysad.oki.co.jp/imart/forma/normal/view/regist_application_view/KM331G0011")
    End Sub


    Private Sub m_WebMain_NewWindow(sender As Object, e As CancelEventArgs) Handles m_WebMain.NewWindow

        Dim popupUrl As String = m_WebMain.Document.ActiveElement.GetAttribute("href")

        Dim webBrowser = CType(sender, WebBrowser)
        Dim url = webBrowser.StatusText ' 現在のURLを取得するか、別の方法でURLを取得
        Debug.Print(url)
        '    WebBrowser1.Navigate(url)



        '' 新しいウィンドウで開かれようとするときに発生する
        e.Cancel = True ' 新しいウィンドウをキャンセル
        'Return

        '' 新しいWebBrowserコントロールでナビゲートを続行
        ''Dim webBrowser = CType(sender, WebBrowser)


        ''Dim url = webBrowser.StatusText ' 現在のURLを取得するか、別の方法でURLを取得
        'm_WebMain.Navigate(URL_BASE & "login/KK111G001/KK111G001.aspx")
    End Sub


    Dim flag As Boolean = True

    Private Sub m_WebMain_DocumentCompleted(sender As Object, e As WebBrowserDocumentCompletedEventArgs) Handles m_WebMain.DocumentCompleted

        Dim sUrl As String = m_WebMain.Url.ToString
        Debug.Print("m_WebMain_DocumentCompleted .. " & sUrl)

        ' If sUrl.EndsWith("/login/KK111G001/KK111G001.aspx") Then
        WindowOpenClose無効化(m_WebMain)
        ' End If

        m_List.Exec(sUrl)

        ' ログイン画面 ： 自動ログオン処理
        'If sUrl.EndsWith("/login/KK111G001/KK111G001.aspx") Then
        '    m_WebMain.SetText("LoginControl$UserName", PANDA_ID)
        '    m_WebMain.SetText("LoginControl$Password", PANDA_PASS)
        '    m_WebMain.PushButton("LoginControl$LoginButton")
        '    Return
        'End If

        'If flag Then
        '    flag = False
        '    If sUrl.EndsWith("/app/KK1/KK112G001/KK112G001.aspx?SCREEN_ID=KK112G0011") Then
        '        'm_WebMain.ButtonClickByCaption("契約支援・審査依頼")
        '        m_WebMain.ButtonClickByCaption("契約書・注文書登録")
        '    End If
        'End If


        'If sUrl.EndsWith("/app/KK3/KK331G030/KK331G030.aspx?SCREEN_ID=KK331G0301&ModeNo=0") Then
        '    m_WebMain.ButtonClickByCaption("新規登録")
        'End If


        'If sUrl.EndsWith("app/KK3/KK331G026/KK331G026.aspx?KJ_NO_H=&KJ_NO_S=&KJ_HANSU=&OPERATION=新規登録&SCREEN_ID=KK331G0261&SCREEN_ID_SRC=KK331G0301") Then

        '    ' 契約種別
        '    m_WebMain.SetComboByNo("ctl00$PageMain$KEIYAKU_SHUBETSU_ID", 1)

        '    ' [契約書書式 - 顧客書式]
        '    m_WebMain.SetCheck("PageMain_KEIYAKUSHO_SHOSHIKI_1", True)

        '    ' プロジェクトNo 選択
        '    '  m_WebMain.ButtonClickByName("ctl00$PageMain$BtnhidRedirect0081")


        '    ' 顧客への引渡し方法 - 一括納品
        '    m_WebMain.SetCheck("PageMain_HIKIWATASHI_HOHO_0", True)

        '    '' 契約内容の説明 設定
        '    m_WebMain.SetText("ctl00$PageMain$KEIYAKU_SETSUMEI", 案件名)

        '    ' プロジェクトNo 設定
        '    m_WebMain.SetText("ctl00$PageMain$PJ_NO", "PJ24-AC-000001")

        '    ' プロジェクトNo 表示
        '    m_WebMain.ButtonClickByName("ctl00$PageMain$BtnShow")

        '    SleepEx(5000)

        '    ' 契約担当者 - 氏名
        '    ' m_WebMain.ButtonClickByName("ctl00$PageMain$EIGYO_USER_ID$ButtonQuery")

        'End If

    End Sub

    Private Sub btnExec_Click(sender As Object, e As EventArgs) Handles btnExec.Click
        m_List.Exec()
    End Sub

    Private Sub m_WebMain_Navigating(sender As Object, e As WebBrowserNavigatingEventArgs) Handles m_WebMain.Navigating
        Debug.Print(e.Url.ToString)
    End Sub

    Sub WindowOpenClose無効化(ByRef web As WebBrowser)

        Dim script As String = "
                window.onload = function() {
                    window.open = function() {};
                    window.close = function() {};
                };
            "

        Dim headElement As HtmlElement = web.Document.GetElementsByTagName("head")(0)
        Dim scriptElement As HtmlElement = web.Document.CreateElement("script")
        Debug.Print(scriptElement.GetAttribute("text"))
        scriptElement.SetAttribute("text", script)
        headElement.AppendChild(scriptElement)
    End Sub

    Private Sub SleepEx(ByVal nMilliSeconds As Integer)

        Dim start As DateTime = DateTime.Now
        Dim duration As TimeSpan = TimeSpan.FromSeconds(nMilliSeconds / 1000)

        ' 現在の時間と開始時間との差が3秒未満の間ループを繰り返す
        While (DateTime.Now - start) < duration

            ' DoEventsを呼び出して、UIの応答性を保つ
            Application.DoEvents()

            ' ここにループ中に実行したい処理を追加
            System.Threading.Thread.Sleep(100)

        End While

    End Sub

    Private Sub m_List_TimerEvent(sender As Object) Handles m_List.TimerEvent
        m_List.Exec()
    End Sub
End Class
