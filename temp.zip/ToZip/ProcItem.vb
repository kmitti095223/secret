﻿Imports 収益認識管理システム自動化.ProcItem

Public Class ProcItem

    Public Enum Proc
        Err
        Title
        Pause
        Wait
        MsgBox
        Navigate
        SetTextById
        SetTextByName
        ClickButtonById
        ClickButtonByName
        ClickButtonByCaption
        SetComboById
        SetComboByName
        SetComboByCaption
        SetCheckById
        SetCheckByName
        SetCheckByCaption
    End Enum

    Private ProcItems As New Dictionary(Of Proc, (String, Integer)) From {
        {Proc.Title, ("Title", 0)},
        {Proc.Pause, ("Pause", 0)},
        {Proc.Wait, ("Wait", 1)},
        {Proc.MsgBox, ("MsgBox", 1)},
        {Proc.Navigate, ("Navigate", 1)},
        {Proc.SetTextById, ("SetTextById", 3)},
        {Proc.SetTextByName, ("SetTextByName", 3)},
        {Proc.ClickButtonById, ("ClickButtonById", 2)},
        {Proc.ClickButtonByName, ("ClickButtonByName", 2)},
        {Proc.ClickButtonByCaption, ("ClickButtonByCaption", 2)},
        {Proc.SetComboById, ("SetComboById", 3)},
        {Proc.SetComboByName, ("SetComboByName", 3)},
        {Proc.SetComboByCaption, ("SetComboByCaption", 3)},
        {Proc.SetCheckById, ("SetCheckById", 3)},
        {Proc.SetCheckByName, ("SetCheckByName", 3)},
        {Proc.SetCheckByCaption, ("SetCheckByCaption", 3)}
    }

    Private m_sName As String
    Private m_Proc As Proc
    Private m_arrParam As New List(Of String)
    Private m_bIsError As Boolean = True

    Public m_bTimerEnd As Boolean

    Public Sub New(ByVal sLine As String, ByRef FixedParam As Dictionary(Of String, String))

        sLine = sLine.Trim

        ' タイトル
        If sLine.StartsWith("■") Then
            m_sName = sLine
            m_bIsError = False
            Exit Sub
        End If

        Dim arr As String() = sLine.Split(",")
        If arr.Count < 2 Then
            Exit Sub
        End If

        m_Proc = GetProcFromString(arr(1))
        If m_Proc = Proc.Err Then
            Exit Sub
        End If

        ' パラメータ数チェック
        If (arr.Count - 2) <> ProcItems(m_Proc).Item2 Then
            Exit Sub
        End If

        m_sName = arr(0)
        For i As Integer = 2 To arr.Count - 1

            For Each fixed In FixedParam
                arr(i) = arr(i).Replace(fixed.Key, fixed.Value)
            Next

            m_arrParam.Add(arr(i))
        Next

        m_bIsError = False
    End Sub

    Function Exec(
        ByVal sUrl As String,
        ByRef WebMain As WebBrowserEx,
        ByRef WebIntramart As WebView2Ex,
        ByRef ParamTimer As Timer,
        ByRef IsNextStep As Boolean) As Boolean

        Exec = True
        IsNextStep = True

        Select Case m_Proc
            Case ProcItem.Proc.Title
                ' 何もしない

            Case ProcItem.Proc.Pause
                IsNextStep = False
                Application.DoEvents()

            Case ProcItem.Proc.Wait
                If m_bTimerEnd = False Then
                    ParamTimer.Interval = GetParam(0)
                    ParamTimer.Start()
                    Exec = False
                Else
                    m_bTimerEnd = False
                End If

            Case ProcItem.Proc.MsgBox
                'MessageBox.Show(Me, GetParam(0), "確認", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)


            Case ProcItem.Proc.Navigate
                WebMain.Navigate(GetParam(0))
                Exec = False ' いったん処理を中断

            Case ProcItem.Proc.SetTextById

            Case ProcItem.Proc.SetTextByName
                Debug.Assert(sUrl.EndsWith(GetParam(2)))
                WebMain.SetText(GetParam(0), GetParam(1))

            Case ProcItem.Proc.ClickButtonById

            Case ProcItem.Proc.ClickButtonByName
                Debug.Assert(sUrl.EndsWith(GetParam(1)))
                WebMain.ClickButtonByName(GetParam(0))
                Exec = False ' いったん処理を中断

            Case ProcItem.Proc.ClickButtonByCaption
                Debug.Assert(sUrl.EndsWith(GetParam(1)))
                WebMain.ClickButtonByCaption(GetParam(0))
                Exec = False ' いったん処理を中断

            Case ProcItem.Proc.SetComboById
            Case ProcItem.Proc.SetComboByName
                Debug.Assert(sUrl.EndsWith(GetParam(2)))
                WebMain.SetComboByName(GetParam(0), GetParam(1))

            Case ProcItem.Proc.SetComboByCaption


            Case ProcItem.Proc.SetCheckById
            Case ProcItem.Proc.SetCheckByName
                Debug.Assert(sUrl.EndsWith(GetParam(2)))
                WebMain.SetCheckByName(GetParam(0), GetParam(1))

            Case ProcItem.Proc.SetCheckByCaption
        End Select

    End Function

    Public Overrides Function ToString() As String
        Return "　" & m_sName
    End Function

    Private Function GetProcFromString(procName As String) As Proc

        ' ProcItemsでリバース検索
        For Each kvp In ProcItems
            If kvp.Value.Item1 = procName Then
                Return kvp.Key
            End If
        Next

        ' 該当なしの場合はNothingを返す
        Return Proc.Err

    End Function

    Public Function IsError()
        Return m_bIsError
    End Function

    Public Function GetProc() As Proc
        Return m_Proc
    End Function

    Public Function GetParam(ByVal nIndex As Integer) As String
        Return m_arrParam(nIndex)
    End Function


End Class
