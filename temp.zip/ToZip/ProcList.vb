﻿Imports System.IO
Imports System.Windows.Forms

Public Class ProcList
    Inherits CheckedListBox

    Public m_WebMain As WebBrowserEx
    Public m_WebIntramart As WebView2Ex

    Private m_FixedParam As New Dictionary(Of String, String)

    Private m_Timer As Timer
    Public Event TimerEvent(ByVal sender As Object)

    Private m_Index As Integer = 0

    Public Sub New()
        ' タイマーの初期化
        m_Timer = New Timer()
        AddHandler m_Timer.Tick, AddressOf OnTimerTick
    End Sub


    Public Function Load(ByVal sFilePath As String) As Boolean

        Dim nLineNo As Integer

        If Not File.Exists(sFilePath) Then
            MsgBox("指定されたファイルが見つかりません。", vbExclamation)
            Return False
        End If

        ' ファイルを1行ずつ読み込む
        For Each sLine As String In File.ReadLines(sFilePath)

            ' 行番号
            nLineNo += 1

            ' 前後の半角スペースを削除
            sLine = sLine.Trim()

            ' 空行または先頭が「#」の行を無視
            If String.IsNullOrEmpty(sLine) Or sLine.StartsWith("#") Then
                Continue For
            End If

            ' 先頭が「$」の行は定数
            If sLine.StartsWith("$") Then
                Dim arr As String() = sLine.Split("=")
                If arr.Count <> 2 Then
                    MsgBox(nLineNo & "行目が不正です。", vbExclamation)
                    Return False
                End If
                m_FixedParam.Add(arr(0), arr(1))
                Continue For
            End If

            Dim item As ProcItem = New ProcItem(sLine, m_FixedParam)
            If item.IsError() Then
                MsgBox(nLineNo & "行目が不正です。", vbExclamation)
                Return False
            End If

            Items.Add(item, True)

        Next

        Return True

    End Function
    Public Sub Exec(Optional ByVal sUrl As String = "")
        While ExecSub(sUrl)
        End While
    End Sub

    Public Function ExecSub(ByVal sUrl As String) As Boolean

        Dim bFuncRc As Boolean = True

        Dim nIndex As Integer = GetFirstCheckedItemIndex()
        If nIndex < 0 Then
            bFuncRc = False
            GoTo FUNC_END
        End If

        SelectedIndex = nIndex
        Application.DoEvents()

        Dim prc As ProcItem = CType(Items(nIndex), ProcItem)
        Dim IsNextStep As Boolean
        bFuncRc = prc.Exec(sUrl, m_WebMain, m_WebIntramart, m_Timer, IsNextStep)
        If bFuncRc And IsNextStep Then
            SetItemChecked(nIndex, False)
        End If

FUNC_END:

        If IsNextStep Then
            SetItemChecked(nIndex, False)
            Application.DoEvents()
            m_Index += 1
        End If

        Return bFuncRc
    End Function

    ' 最初にチェックされているアイテムのインデックスを取得
    Private Function GetFirstCheckedItemIndex() As Integer
        For i As Integer = 0 To Items.Count - 1
            If GetItemChecked(i) Then
                Return i
            End If
        Next
        Return -1
    End Function

    Private Sub OnTimerTick(sender As Object, e As EventArgs)

        Dim prc As ProcItem = CType(Items(m_Index), ProcItem)
        prc.m_bTimerEnd = True
        RaiseEvent TimerEvent(Me)

    End Sub

End Class
