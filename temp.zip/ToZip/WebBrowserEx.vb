﻿
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Windows.Forms

Public Class WebBrowserEx
    Inherits System.Windows.Forms.WebBrowser

    '=========================================================================================
    ' 変数定義
    '=========================================================================================
    Protected m_MainForm As MainForm
    Protected m_bFirst As Boolean = True
    Protected m_bUpdateView = False             ' メイン画面更新フラグ

    Protected m_WebBaseで子ウィンドウを開く As Boolean = True

    ''=========================================================================================
    ''
    ''	関数名	 : m_Web_NewWindow2
    ''	機能説明 : 子ウィンドウを表示する処理。
    ''
    ''=========================================================================================
    'Private Sub m_Web_NewWindow2(sender As Object, e As WebBrowserNewWindow2EventArgs) Handles m_Web.NewWindow2

    '    If m_WebBaseで子ウィンドウを開く Then
    '        Dim frmSub As New WebBase
    '        frmSub.Show(Me)
    '        e.ppDisp = frmSub.m_Web.Application
    '        m_Web.RegisterAsBrowser = True
    '    End If

    'End Sub

    '=========================================================================================
    '
    '	関数名	 : SetText
    '	機能説明 : 
    '
    '=========================================================================================
    Public Sub SetText(sName As String, sText As String)
        Dim collection As HtmlElementCollection = Nothing
        Dim element As HtmlElement = Nothing

        collection = Document.All
        element = collection(sName)

        element.SetAttribute("value", sText)
    End Sub

    '=========================================================================================
    '
    '	関数名	 : GetText
    '	機能説明 : 
    '
    '=========================================================================================
    Public Shared Function GetText(document As HtmlDocument, sName As String) As String
        On Error GoTo FUNC_ERR
        Dim collection As HtmlElementCollection = Nothing
        Dim element As HtmlElement = Nothing

        collection = document.All
        element = collection(sName)

        Return element.GetAttribute("value")
FUNC_ERR:
        Return ""
    End Function

    '=========================================================================================
    '
    '	関数名	 : SetComboByName
    '	機能説明 : 
    '
    '=========================================================================================
    Public Sub SetComboByName(sName As String, nNo As Integer)

        Dim collection As HtmlElementCollection = Document.All
        Dim element As HtmlElement = collection(sName)

        element.SetAttribute("SelectedIndex", nNo.ToString())

    End Sub

    '=========================================================================================
    '
    '	関数名	 : SetCombo
    '	機能説明 : 
    '
    '=========================================================================================
    Public Sub SetCombo(sName As String, sText As String)

        Dim collection As HtmlElementCollection = Document.All
        Dim element As HtmlElement = collection(sName)

        ' element.SetAttribute("selected value", sText);
        For i As Integer = 0 To element.All.Count - 1
            If element.All(i).OuterText = sText Then
                element.SetAttribute("SelectedIndex", i.ToString())
                Exit For
            End If
        Next
    End Sub

    '=========================================================================================
    '
    '	関数名	 : PushButton
    '	機能説明 : 
    '
    '=========================================================================================
    Public Sub PushButton(sButtonName As String)
        On Error Resume Next
        Document.All(sButtonName).InvokeMember("click")
    End Sub

    '=========================================================================================
    '
    '	関数名	 : ClickButtonByName
    '	機能説明 : 
    '
    '=========================================================================================
    Public Sub ClickButtonByName(sName As String)

        ' ドキュメント内のすべてのボタンを取得
        Dim buttons As HtmlElementCollection = Document.GetElementsByTagName("input")

        ' 各入力要素をチェック
        For Each button As HtmlElement In buttons
            ' ボタンのタイプが"button" または"submit"で、表示テキストが目標のものであるかを確認
            If (button.GetAttribute("type").ToLower() = "button" Or button.GetAttribute("type").ToLower() = "submit") AndAlso
                   (button.GetAttribute("name") = sName) Then
                ' ボタンが見つかったらクリック
                button.InvokeMember("click")
                Exit For
            End If
        Next

    End Sub

    '=========================================================================================
    '
    '	関数名	 : ClickButtonByCaption
    '	機能説明 : 
    '
    '=========================================================================================
    Public Sub ClickButtonByCaption(sCaptoin As String)

        ' ドキュメント内のすべてのボタンを取得
        Dim buttons As HtmlElementCollection = Document.GetElementsByTagName("input")

        ' 各入力要素をチェック
        For Each button As HtmlElement In buttons
            ' ボタンのタイプが"button" または"submit"で、表示テキストが目標のものであるかを確認
            If (button.GetAttribute("type").ToLower() = "button" Or button.GetAttribute("type").ToLower() = "submit") AndAlso
                   (button.GetAttribute("value") = sCaptoin) Then
                ' ボタンが見つかったらクリック
                button.InvokeMember("click")
                Exit For
            End If
        Next

    End Sub


    Public Function Extract(ByVal sText As String, ByVal sStart As String, ByVal sEnd As String) As List(Of String)

        Dim lstResult As New List(Of String)

        'Regexオブジェクトを作成 
        Dim r As New System.Text.RegularExpressions.Regex(sStart & "(.*?)" & sEnd,
        System.Text.RegularExpressions.RegexOptions.IgnoreCase)

        Dim mc As System.Text.RegularExpressions.MatchCollection =
        r.Matches(sText)

        For Each m As System.Text.RegularExpressions.Match In mc
            Dim sWk As String = m.Groups(0).Value
            lstResult.Add(sWk.Substring(sStart.Length, sWk.Length - sStart.Length - sEnd.Length))
        Next

        Return lstResult

    End Function


    Function Cut(ByRef sText As String, ByVal sStart As String, ByVal sEnd As String) As String

        Dim sWk As String = sText
        Dim nPos As Integer = 0

        While True
            Dim nPosS As Integer = sWk.IndexOf(sStart, nPos)
            If nPosS < 0 Then
                Return sWk
                Exit Function
            End If

            Dim nPosE As Integer = sWk.IndexOf(sEnd, nPosS + sStart.Length)
            If nPosE < 0 Then
                Return sWk
                Exit Function
            End If

            sWk = sWk.Substring(0, nPosS) + sWk.Substring(nPosE + 1, sWk.Length - nPosE - 1)
            nPos = nPosS + 1

        End While

        Return sWk
    End Function

    '=========================================================================================
    '
    '	関数名	 : SetFocus
    '	機能説明 : 
    '
    '=========================================================================================
    Public Shared Sub SetFocus(document As HtmlDocument, sName As String)
        On Error Resume Next

        Dim collection As HtmlElementCollection = Nothing
        Dim element As HtmlElement = Nothing

        collection = document.All
        element = collection(sName)
        element.Focus()

    End Sub

    Public Shared Function GetAttribute(document As HtmlDocument, sName As String, ByVal sAttr As String) As String
        On Error GoTo FUNC_ERR
        Dim collection As HtmlElementCollection = Nothing
        Dim element As HtmlElement = Nothing

        collection = document.All
        element = collection(sName)

        Return element.GetAttribute(sAttr)
FUNC_ERR:
        Return ""
    End Function


    '=========================================================================================
    '
    '	関数名	 : SetCheckByName
    '	機能説明 : 
    '
    '=========================================================================================
    Public Function SetCheckByName(ByVal sName As String, ByVal bCheck As Boolean) As Boolean
        On Error GoTo FUNC_ERR

        Dim collection As HtmlElementCollection = Nothing
        Dim element As HtmlElement = Nothing

        collection = Document.All
        element = collection(sName)

        element.SetAttribute("checked", bCheck)

        Return True

FUNC_ERR:
        Return False
    End Function


    '=========================================================================================
    '
    '	関数名	 : GetCheck
    '	機能説明 : 
    '
    '=========================================================================================
    Public Shared Function GetCheck(ByRef document As HtmlDocument, ByVal sName As String) As Object
        On Error GoTo FUNC_ERR
        Dim collection As HtmlElementCollection = Nothing
        Dim element As HtmlElement = Nothing

        collection = document.All
        element = collection(sName)

        Return element.GetAttribute("checked")

FUNC_ERR:
        Return Nothing
    End Function

End Class
