﻿' WebView2の参照設定追加が必要
' System.Text.Json の参照設定追加が必要

Public Class WebView2Ex
    Inherits Microsoft.Web.WebView2.WinForms.WebView2

    ' 初期化
    Sub Initialize()
        EnsureCoreWebView2Async(Nothing)

        ' 初期化完了まで待機する
        For i = 1 To 300
            If CoreWebView2 Is Nothing Then
                System.Windows.Forms.Application.DoEvents()
                System.Threading.Thread.Sleep(100)
            End If
        Next

    End Sub
    Public Function Url() As String
        Return CoreWebView2.Source
    End Function

    ' URL設定
    Sub Navigate(ByVal sUrl As String)
        CoreWebView2.Navigate(sUrl)
    End Sub

    ' テキスト設定(名前指定)
    Public Async Sub SetTextByName(ByVal sName As String, ByVal sText As String)
        Dim s As String = String.Format("document.getElementsByName('{0}')[0].value = '{1}';", sName, sText)
        Await (ExecuteScriptAsync(s))
    End Sub

    ' テキスト設定(Id指定)
    Public Async Sub SetTextById(ByVal sId As String, ByVal sText As String)
        Dim s As String = String.Format("document.getElementById('{0}').value = '{1}';", sId, sText)
        Await (ExecuteScriptAsync(s))
    End Sub

    ' テキスト取得(名前指定)
    Public Async Function GetTextByName(ByVal sName As String) As Task(Of String)
        Dim s = Await (ExecuteScriptAsync(String.Format("document.getElementsByName('{0}')[0].value", sName)))
        Return System.Text.Json.JsonSerializer.Deserialize(Of String)(s)
    End Function

    ' テキスト取得(Id指定)
    Public Async Function GetTextById(ByVal sId As String) As Task(Of String)
        Dim s = Await (ExecuteScriptAsync(String.Format("document.getElementById('{0}').value", sId)))
        Return System.Text.Json.JsonSerializer.Deserialize(Of String)(s)
    End Function

    ' テキスト取得(クラス指定)
    Public Async Function GetTextByClassName(ByVal sClassName As String, Optional ByVal nIndex As Integer = 0) As Task(Of String)
        Dim s = Await (ExecuteScriptAsync(String.Format("document.getElementsByClassName('{0}')[{1}].value", sClassName, nIndex)))
        Return System.Text.Json.JsonSerializer.Deserialize(Of String)(s)
    End Function

    ' テキスト取得(タグ指定)
    Public Async Function GetOuterHTML() As Task(Of String)
        Dim s = Await (ExecuteScriptAsync("document.documentElement.outerHTML"))
        s = System.Text.RegularExpressions.Regex.Unescape(s)
        s = s.Remove(0, 1)
        s = s.Remove(s.Length - 1, 1)
        Return s
    End Function

    ' ボタンクリック(名前指定)
    Sub ButtonClickByName(ByVal sName As String)
        Dim s As String = String.Format("document.getElementsByName('{0}')[0].click();", sName)
        ExecuteScriptAsync(s)
    End Sub

    ' ボタンクリック(Id指定)
    Sub ButtonClickById(ByVal sId As String)
        Dim s As String = String.Format("document.getElementById('{0}').click();", sId)
        ExecuteScriptAsync(s)
    End Sub


    ' ボタンクリック(クラス名指定)
    Sub ButtonClickByClassName(ByVal sClassName As String, Optional ByVal nIndex As Integer = 0)
        Dim s As String = String.Format("document.getElementsByClassName('{0}')[{1}].click();", sClassName, nIndex)
        ExecuteScriptAsync(s)
    End Sub

    Sub ButtonClickByValue(ByVal sFormName As String, ByVal sValue As String)

        Dim s As String

        If sFormName <> "" Then
            s = "  for (let i = 0; i < document.forms['■FORM_NAME■'].length; i++) {" &
            "    if (document.forms['■FORM_NAME■'][i].value == '■VALUE■') {" &
            "      document.forms['■FORM_NAME■'][i].click();" &
            "    }" &
            "  }"
            s = s.Replace("■FORM_NAME■", sFormName)
        Else
            s =
                "var elements = document.getElementsByTagName('*');" &
                "for (let i = 0; i < elements.length; i++) {" &
                "    if (elements[i].value == '■VALUE■') {" &
                "      elements[i].click();" &
                "    }" &
                "  }"

        End If
        s = s.Replace("■VALUE■", sValue)

        ExecuteScriptAsync(s)

    End Sub

    'Sub ButtonClickByName2(ByVal sFormName As String, ByVal sName As String)

    '    Dim s As String

    '    If sFormName <> "" Then
    '        s = "  for (let i = 0; i < document.forms['■FORM_NAME■'].length; i++) {" &
    '        "    if (document.forms['■FORM_NAME■'][i].name == '■NAME■') {" &
    '        "      document.forms['■FORM_NAME■'][i].click();" &
    '        "    }" &
    '        "  }"
    '        s = s.Replace("■FORM_NAME■", sFormName)
    '    Else
    '        s =
    '            "var elements = document.getElementsByTagName('*');" &
    '            "for (let i = 0; i < elements.length; i++) {" &
    '            "    if (elements[i].name == '■NAME■') {" &
    '            "      elements[i].click();" &
    '            "    }" &
    '            "  }"

    '    End If
    '    s = s.Replace("■NAME■", sName)

    '    ExecuteScriptAsync(s)

    'End Sub


    Sub CheckBoxSet(ByVal sName As String, ByVal bValue As Boolean)
        Dim s As String = String.Format("document.getElementsByName('{0}')[0].checked = {1};", sName, If(bValue, "true", "false"))
        ExecuteScriptAsync(s)
    End Sub

    Sub RadioClickByName(ByVal sName As String, ByVal nNo As Integer)
        Dim s As String = String.Format("document.getElementsByName('{0}')[{1}].click();", sName, nNo - 1)
        ExecuteScriptAsync(s)
    End Sub
    Sub CheckBoxClickById(ByVal sId As String)
        Dim s As String = String.Format("document.getElementById('{0}')[0].click();", sId)
        ExecuteScriptAsync(s)
    End Sub
    Sub CheckBoxClickByName(ByVal sName As String)
        Dim s As String = String.Format("document.getElementsByName('{0}')[0].click();", sName)
        ExecuteScriptAsync(s)
    End Sub

    Public Sub Exec(ByVal sCommand As String)
        ExecuteScriptAsync(sCommand)
    End Sub

    Public Sub ComboSelect(ByVal sName As String, ByVal nComboIndex As Integer, Optional ByVal bChangeEvent As Boolean = False)
        Dim s As String = String.Format("document.getElementsByName('{0}')[0].selectedIndex = {1};", sName, nComboIndex)
        ExecuteScriptAsync(s)
        If bChangeEvent Then
            'セレクトボックスにonchangeイベントを発生させる
            s = ""
            s &= ("var evt = document.createEvent('HTMLEvents');" & vbCrLf)
            s &= ("evt.initEvent('change', false, true);" & vbCrLf)
            s &= ("document.getElementsByName('" & sName & "')[0].dispatchEvent(evt);")
            's = String.Format("document.getElementsByName('{0}').trigger('change');", sName)
            ExecuteScriptAsync(s)
        End If
    End Sub

    Public Sub ComboSelect2(ByVal sName As String, ByVal sValue As String)
        Dim s As String = String.Format("document.getElementsByName('{0}').querySelector('{0}').prop('selected', true);", sName, sValue)
        ExecuteScriptAsync(s)
    End Sub

    Private Sub MessageReceived(sender As Object, args As Microsoft.Web.WebView2.Core.CoreWebView2WebMessageReceivedEventArgs) Handles Me.WebMessageReceived
        Dim text As String = args.TryGetWebMessageAsString()
        MsgBox(text)

        Dim arr() As String
        arr = text.Split(",")
        Dim s As String = String.Format("document.querySelector('{0}').value = '{1}';", arr(0), "value2")
        ExecuteScriptAsync(s)
    End Sub

    ''' <summary>
    ''' KeyDownイベントハンドラ
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub WebView2Ex_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        'キーイベントを親に通知する。
        '   CType(Me.Parent, MainForm).MainForm_KeyDown(sender, e)
    End Sub

End Class
