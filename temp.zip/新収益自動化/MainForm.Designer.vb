﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.m_Tab = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.m_WebMain = New 新収益自動化.WebView2Ex()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.m_WebSub = New 新収益自動化.WebView2Ex()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.m_WebIntra = New 新収益自動化.WebView2Ex()
        Me.CheckedListBox1 = New System.Windows.Forms.CheckedListBox()
        Me.m_Tab.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.m_WebMain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.m_WebSub, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        CType(Me.m_WebIntra, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'm_Tab
        '
        Me.m_Tab.Controls.Add(Me.TabPage1)
        Me.m_Tab.Controls.Add(Me.TabPage2)
        Me.m_Tab.Controls.Add(Me.TabPage3)
        Me.m_Tab.Dock = System.Windows.Forms.DockStyle.Left
        Me.m_Tab.Location = New System.Drawing.Point(0, 0)
        Me.m_Tab.Name = "m_Tab"
        Me.m_Tab.SelectedIndex = 0
        Me.m_Tab.Size = New System.Drawing.Size(828, 729)
        Me.m_Tab.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.m_WebMain)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(820, 703)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "新収益Main"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'm_WebMain
        '
        Me.m_WebMain.AllowExternalDrop = True
        Me.m_WebMain.CreationProperties = Nothing
        Me.m_WebMain.DefaultBackgroundColor = System.Drawing.Color.White
        Me.m_WebMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.m_WebMain.Location = New System.Drawing.Point(3, 3)
        Me.m_WebMain.Name = "m_WebMain"
        Me.m_WebMain.Size = New System.Drawing.Size(814, 697)
        Me.m_WebMain.TabIndex = 3
        Me.m_WebMain.ZoomFactor = 1.0R
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.m_WebSub)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(820, 703)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "新収益Sub"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'm_WebSub
        '
        Me.m_WebSub.AllowExternalDrop = True
        Me.m_WebSub.CreationProperties = Nothing
        Me.m_WebSub.DefaultBackgroundColor = System.Drawing.Color.White
        Me.m_WebSub.Dock = System.Windows.Forms.DockStyle.Fill
        Me.m_WebSub.Location = New System.Drawing.Point(3, 3)
        Me.m_WebSub.Name = "m_WebSub"
        Me.m_WebSub.Size = New System.Drawing.Size(814, 697)
        Me.m_WebSub.TabIndex = 7
        Me.m_WebSub.ZoomFactor = 1.0R
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.m_WebIntra)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(820, 703)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Intramart"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'm_WebIntra
        '
        Me.m_WebIntra.AllowExternalDrop = True
        Me.m_WebIntra.CreationProperties = Nothing
        Me.m_WebIntra.DefaultBackgroundColor = System.Drawing.Color.White
        Me.m_WebIntra.Dock = System.Windows.Forms.DockStyle.Fill
        Me.m_WebIntra.Location = New System.Drawing.Point(0, 0)
        Me.m_WebIntra.Name = "m_WebIntra"
        Me.m_WebIntra.Size = New System.Drawing.Size(820, 703)
        Me.m_WebIntra.TabIndex = 0
        Me.m_WebIntra.ZoomFactor = 1.0R
        '
        'CheckedListBox1
        '
        Me.CheckedListBox1.Dock = System.Windows.Forms.DockStyle.Right
        Me.CheckedListBox1.FormattingEnabled = True
        Me.CheckedListBox1.Location = New System.Drawing.Point(834, 0)
        Me.CheckedListBox1.Name = "CheckedListBox1"
        Me.CheckedListBox1.Size = New System.Drawing.Size(174, 729)
        Me.CheckedListBox1.TabIndex = 1
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1008, 729)
        Me.Controls.Add(Me.CheckedListBox1)
        Me.Controls.Add(Me.m_Tab)
        Me.Name = "MainForm"
        Me.Text = "Form1"
        Me.m_Tab.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.m_WebMain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        CType(Me.m_WebSub, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        CType(Me.m_WebIntra, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents m_Tab As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents CheckedListBox1 As CheckedListBox
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents m_WebMain As WebView2Ex
    Friend WithEvents m_WebSub As WebView2Ex
    Friend WithEvents m_WebIntra As WebView2Ex
End Class
