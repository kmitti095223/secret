﻿Imports Microsoft.Web.WebView2.WinForms
Imports Microsoft.Web.WebView2.Core

Public Class MainForm
    Private Sub MainForm_Load(sender As Object, e As EventArgs) Handles Me.Load

        m_WebMain.InitializeAsync()
        m_WebSub.InitializeAsync()
        m_WebIntra.InitializeAsync()

        ' ポップアップを許可する設定
        'm_Web.CoreWebView2.Settings.IsScriptEnabled = True
        m_WebMain.CoreWebView2.Settings.AreDefaultScriptDialogsEnabled = False
        'm_Web.CoreWebView2.Settings.IsStatusBarEnabled = True

        m_WebMain.Navigate("C:\Users\yuji\Desktop\JunkProgram\WebView2でヘッダの位置を変える(新就役自動化)\main.html")
        m_WebSub.Navigate("C:\Users\yuji\Desktop\JunkProgram\WebView2でヘッダの位置を変える(新就役自動化)\main.html")
        m_WebIntra.Navigate("C:\Users\yuji\Desktop\JunkProgram\WebView2でヘッダの位置を変える(新就役自動化)\main.html")

        AddHandler m_WebMain.CoreWebView2.NewWindowRequested, AddressOf OnNewWindowRequested

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)

        Dim script As String = "    const style = document.createElement('style'); " &
        "style.innerHTML = `" &
        "header { " &
        "position: fixed !important;" &
        "top: 0 !important;" &
        "z-index: 9999 !important;" &
        "}" &
        "`;" &
        "document.head.appendChild(style);"

        m_WebMain.CoreWebView2.ExecuteScriptAsync(script)

    End Sub
    Private Sub OnNewWindowRequested(sender As Object, e As CoreWebView2NewWindowRequestedEventArgs)
        '' 新しいウィンドウを作成
        'Dim newForm As New SubForm()

        '' WebView2をサブウィンドウに設定
        'newForm.Show()
        'newForm.InitializeWebView(e.Uri)

        m_WebSub.Navigate(e.Uri)
        m_Tab.SelectTab(1)

        ' イベントを処理済みとしてマーク
        e.Handled = True
    End Sub

End Class
