﻿Public Class WebView2Ex
    Inherits Microsoft.Web.WebView2.WinForms.WebView2

    Private ReadOnly condition As New System.Threading.CountdownEvent(1)
    Private m_Result As String

    Sub InitializeAsync()
        '  EnsureCoreWebView2Async(Nothing)
        EnsureCoreWebView2Async(Nothing)

        ' 初期化完了まで待機する
        For i = 1 To 300
            If CoreWebView2 Is Nothing Then
                System.Windows.Forms.Application.DoEvents()
                System.Threading.Thread.Sleep(100)
            End If
        Next

    End Sub
    Sub Navigate(ByVal sUrl As String)
        CoreWebView2.Navigate(sUrl)
    End Sub
    Public Async Sub SetText(ByVal sName As String, ByVal sText As String)
        Dim s As String = String.Format("document.getElementsByName('{0}')[0].value = '{1}';", sName, sText)
        Await (ExecuteScriptAsync(s))
    End Sub

    Public Function GetText(ByVal sName As String) As String
        GetTextSub(sName)
        Return m_Result
    End Function

    Public Async Sub GetTextSub(ByVal sName As String)
        Dim s As String = String.Format("document.getElementsByName('{0}')[0].value", sName)
        'ExecuteScriptAsync(s).Wait()
        Dim a = Await (ExecuteScriptAsync(s))
        'Task.ConfigureAwait(False).GetAwaiter().GetResult()

    End Sub

    Sub RadioClick(ByVal sName As String, ByVal nNo As Integer)
        Dim s As String = String.Format("document.getElementsByName('{0}')[{1}].click();", sName, nNo - 1)
        ExecuteScriptAsync(s)
    End Sub
    Sub CheckBoxClick(ByVal sName As String)
        Dim s As String = String.Format("document.getElementsByName('{0}')[0].click();", sName)
        ExecuteScriptAsync(s)
    End Sub

    Sub ButtunClick(ByVal sName As String)
        Dim s As String = String.Format("document.getElementById('{0}').click();", sName)
        ExecuteScriptAsync(s)
    End Sub

    Async Sub ComboSelect()

        Dim arr() As String
        arr = Text.Split(",")
        '        Dim s As String = String.Format("document.querySelector('{0}')[0].value = '{1}';", "selectname", "value2")
        Dim s As String = String.Format("document.getElementsByName('{0}')[1].selected = true';", "radioname")
        Await ExecuteScriptAsync(s)

        'Await (ExecuteScriptAsync(
        '    $"window.chrome.webview.postMessage(" +
        '    "document.activeElement.name + ',' + " +
        '    "document.activeElement.className );"))

    End Sub

    Private Sub MessageReceived(sender As Object, args As Microsoft.Web.WebView2.Core.CoreWebView2WebMessageReceivedEventArgs) Handles Me.WebMessageReceived
        Dim text As String = args.TryGetWebMessageAsString()
        MsgBox(text)

        Dim arr() As String
        arr = text.Split(",")
        Dim s As String = String.Format("document.querySelector('{0}').value = '{1}';", arr(0), "value2")
        ExecuteScriptAsync(s)
    End Sub

End Class
