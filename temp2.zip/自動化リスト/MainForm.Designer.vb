﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.m_ProcList = New 自動化リスト.ProcList()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'm_ProcList
        '
        Me.m_ProcList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.m_ProcList.FormattingEnabled = True
        Me.m_ProcList.Location = New System.Drawing.Point(0, 0)
        Me.m_ProcList.Name = "m_ProcList"
        Me.m_ProcList.Size = New System.Drawing.Size(361, 531)
        Me.m_ProcList.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(105, 268)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(202, 108)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(361, 531)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.m_ProcList)
        Me.Name = "MainForm"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents m_ProcList As ProcList
    Friend WithEvents Button1 As Button
End Class
