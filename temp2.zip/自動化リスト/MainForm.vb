﻿Public Class MainForm
    Private Sub MainForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        m_ProcList.Load(Application.StartupPath & "\test.txt")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        m_ProcList.Exec()

    End Sub

    Private Sub m_ProcList_TimerEvent(sender As Object) Handles m_ProcList.TimerEvent

        m_ProcList.Exec()

    End Sub
End Class
