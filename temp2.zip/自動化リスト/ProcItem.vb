﻿Public Class ProcItem

    Public Enum Proc
        Err
        Title
        Pause
        Wait
        MsgBox
        Navigate
        SetTextById
        SetTextByName
        ClickButtonById
        ClickButtonByName
        ClickButtonByCaption
    End Enum

    Private ProcItems As New Dictionary(Of Proc, (String, Integer)) From {
        {Proc.Title, ("Title", 0)},
        {Proc.Pause, ("Pause", 0)},
        {Proc.Wait, ("Wait", 1)},
        {Proc.MsgBox, ("MsgBox", 1)},
        {Proc.Navigate, ("Navigate", 1)},
        {Proc.SetTextById, ("SetTextById", 3)},
        {Proc.SetTextByName, ("SetTextByName", 3)},
        {Proc.ClickButtonById, ("ClickButtonById", 2)},
        {Proc.ClickButtonByName, ("ClickButtonByName", 2)},
        {Proc.ClickButtonByCaption, ("ClickButtonByCaption", 2)}
    }

    Private m_sName As String
    Private m_Proc As Proc
    Private m_arrParam As New List(Of String)
    Private m_bIsError As Boolean = True

    Public m_bTimerEnd As Boolean

    Public Sub New(ByVal sLine As String)

        sLine = sLine.Trim

        ' タイトル
        If sLine.StartsWith("■") Then
            m_sName = sLine
            m_bIsError = False
            Exit Sub
        End If

        Dim arr As String() = sLine.Split(",")
        If arr.Count < 2 Then
            Exit Sub
        End If

        m_Proc = GetProcFromString(arr(1))
        If m_Proc = Proc.Err Then
            Exit Sub
        End If

        ' パラメータ数チェック
        If (arr.Count - 2) <> ProcItems(m_Proc).Item2 Then
            Exit Sub
        End If

        m_sName = arr(0)
        For i As Integer = 2 To arr.Count - 1
            m_arrParam.Add(arr(i))
        Next

        m_bIsError = False
    End Sub

    Public Overrides Function ToString() As String
        Return "　" & m_sName
    End Function

    Private Function GetProcFromString(procName As String) As Proc

        ' ProcItemsでリバース検索
        For Each kvp In ProcItems
            If kvp.Value.Item1 = procName Then
                Return kvp.Key
            End If
        Next

        ' 該当なしの場合はNothingを返す
        Return Proc.Err

    End Function

    Public Function IsError()
        Return m_bIsError
    End Function

    Public Function GetProc() As Proc
        Return m_Proc
    End Function

    Public Function GetParam(ByVal nIndex As Integer) As String
        Return m_arrParam(nIndex)
    End Function


End Class
