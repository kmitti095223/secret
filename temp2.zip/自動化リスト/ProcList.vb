﻿Imports System.IO
Imports System.Windows.Forms

Public Class ProcList
    Inherits CheckedListBox

    Private m_Timer As Timer
    Public Event TimerEvent(ByVal sender As Object)

    Private m_Index As Integer = 0

    Public Sub New()
        ' タイマーの初期化
        m_Timer = New Timer()
        AddHandler m_Timer.Tick, AddressOf OnTimerTick
    End Sub


    Sub Load(ByVal sFilePath As String)

        Dim nLineNo As Integer

        If Not File.Exists(sFilePath) Then
            MsgBox("指定されたファイルが見つかりません。", vbExclamation)
            Exit Sub
        End If

        ' ファイルを1行ずつ読み込む
        For Each sLine As String In File.ReadLines(sFilePath)

            ' 行番号
            nLineNo += 1

            ' 前後の半角スペースを削除
            sLine = sLine.Trim()

            ' 空行または先頭が「#」の行を無視
            If String.IsNullOrEmpty(sLine) Or sLine.StartsWith("#") Then
                Continue For
            End If

            Dim item As ProcItem = New ProcItem(sLine)
            If item.IsError() Then
                MsgBox(nLineNo & "行目が不正です。", vbExclamation)
                Exit Sub
            End If

            Items.Add(item, True)

        Next

    End Sub
    Public Function Exec() As Boolean
        While ExecSub()
        End While
    End Function

    Public Function ExecSub() As Boolean

        Dim bFuncRc As Boolean = True

        Dim nIndex As Integer = GetFirstCheckedItemIndex()
        If nIndex < 0 Then
            bFuncRc = False
            GoTo FUNC_END
        End If

        Dim prc As ProcItem = CType(Items(nIndex), ProcItem)

        Select Case prc.GetProc
            Case ProcItem.Proc.Title
                ' 何もしない

            Case ProcItem.Proc.Pause
                bFuncRc = False
                SetItemChecked(nIndex, False)
                Application.DoEvents()

            Case ProcItem.Proc.Wait
                If prc.m_bTimerEnd = False Then
                    m_Timer.Interval = prc.GetParam(0)
                    m_Timer.Start()
                    bFuncRc = False
                Else
                    prc.m_bTimerEnd = False
                End If

            Case ProcItem.Proc.MsgBox
                MessageBox.Show(Me, prc.GetParam(0), "確認", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                '                MessageBox.Show(Me, prc.GetParam(0), ,, MessageBoxIcon.Exclamation)

        End Select

FUNC_END:
        If bFuncRc Then
            SetItemChecked(nIndex, False)
            Application.DoEvents()
            m_Index += 1
        End If

        Return bFuncRc
    End Function

    ' 最初にチェックされているアイテムのインデックスを取得
    Private Function GetFirstCheckedItemIndex() As Integer
        For i As Integer = 0 To Items.Count - 1
            If GetItemChecked(i) Then
                Return i
            End If
        Next
        Return -1
    End Function

    Private Sub OnTimerTick(sender As Object, e As EventArgs)

        Dim prc As ProcItem = CType(Items(m_Index), ProcItem)
        prc.m_bTimerEnd = True
        RaiseEvent TimerEvent(Me)

    End Sub

End Class
