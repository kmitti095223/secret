// サービスワーカーが起動したときにログを出力
console.log("Background script is running");

// メッセージを受信したときの処理
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "scrollDown") {
        console.log("Received scroll command");

        // 指定したページでスクロールを実行
        chrome.scripting.executeScript({
            target: { tabId: sender.tab.id },
            func: () => { window.scrollBy(0, 100); }
        });
    }
});
