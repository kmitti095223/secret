document.addEventListener("DOMContentLoaded", function () {
    console.log("popup.js loaded");
    // alert("popup.js loaded");

    document.getElementById("scrollButton").addEventListener("click", function () {
        console.log("Button clicked");
        // alert("Button clicked");

        // 現在のタブに対してスクロール命令を送る
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            if (tabs.length > 0) {
                chrome.scripting.executeScript({
                    target: { tabId: tabs[0].id },
                    func: () => {
                        // ページを100px下にスクロール
                        window.scrollBy(0, 300);
                    }
                });
            }
        });
    });
});
