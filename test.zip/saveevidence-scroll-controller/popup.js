document.addEventListener("DOMContentLoaded", function () {
    console.log("popup.js loaded");

    document.getElementById("scrollButton").addEventListener("click", function () {
        console.log("Button clicked");

        // 現在のタブにスクリプトを実行して、ページの内容を取得しExcelに保存
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            if (tabs.length > 0) {
                chrome.scripting.executeScript({
                    target: { tabId: tabs[0].id },
                    func: () => {
                        // SheetJS ライブラリを使ってページの内容を Excel に保存する処理

                        function extractData() {
                            const elements = document.querySelectorAll("body *");
                            const data = [];

                            elements.forEach(el => {
                                const tag = el.tagName.toLowerCase();
                                let value = "";

                                if (tag === "input") {
                                    if (el.type === "checkbox") {
                                        value = el.checked ? "✅" : "❌";
                                    } else {
                                        value = el.value;
                                    }
                                } else if (tag === "textarea") {
                                    value = el.value;
                                } else if (tag === "select") {
                                    value = el.options[el.selectedIndex]?.text || "";
                                } else {
                                    value = el.innerText.trim();
                                }

                                if (value) {
                                    data.push([tag, value]);
                                }
                            });

                            return data;
                        }

                        function saveToExcel(data) {
                            const sheet = XLSX.utils.aoa_to_sheet([["Tag", "Content"], ...data]);
                            const wb = XLSX.utils.book_new();
                            XLSX.utils.book_append_sheet(wb, sheet, "PageData");
                            XLSX.writeFile(wb, "page_data.xlsx");
                        }

                        // 外部スクリプトの読み込み（SheetJS）
                        const script = document.createElement("script");
                        script.src = "https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js";
                        script.onload = () => {
                            const data = extractData();
                            saveToExcel(data);
                        };
                        document.body.appendChild(script);
                    }
                });
            }
        });
    });
});
